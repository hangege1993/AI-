# AI 对话转 Word 助手（aisx）

把 AI 对话平台的**分享链接**，转成排版干净、**公式在 Word 里可以继续双击编辑**的文档。

同类工具（比如"DS随心转"）大多把公式**截图**贴进 Word——放大就糊、不能改、复制不出来。
本工具走的是另一条路：把 LaTeX 解析成 MathML，再翻译成 OMML（Office Math Markup Language），
也就是 Word 自己的公式格式。所以文档里的每一个公式都是**原生公式对象**，
不是图片、不是纯文本，不存在"乱码"。

---

## 目录

- [一、功能概览](#一功能概览)
- [二、快速开始](#二快速开始)
- [三、支持的平台](#三支持的平台)
- [四、公式为什么不会乱码](#四公式为什么不会乱码)
- [五、命令行用法](#五命令行用法)
- [六、当成库来用](#六当成库来用)
- [七、项目结构](#七项目结构)
- [八、测试](#八测试)
- [九、常见问题](#九常见问题)
- [十、已知限制](#十已知限制)

---

## 一、功能概览

| 能力 | 说明 |
| --- | --- |
| 输入 | 一行一个链接，也可以把**整段分享文案**直接粘进来（自动挑出链接） |
| 平台识别 | 按域名 + 路径自动判断平台，不需要手动选 |
| 抓取策略 | 三级兜底：官方接口 → HTTP 直取 / 内嵌 JSON → 浏览器渲染 + 接口嗅探 |
| 内容还原 | 标题、段落、列表、表格、引用、分隔线、代码块（带语言标记）、行内代码、粗体/斜体/删除线、超链接、图片占位 |
| 公式 | LaTeX → MathML → OMML，**行内公式 + 独立公式**都是 Word 原生对象 |
| 思维链 | 可选导出（DeepSeek 的 R1 思考过程、Claude 的 thinking 等） |
| 输出格式 | `docx`（主）、`md`、`html`、`txt`、`json` |
| 批量 | 一次给多个链接，单个失败不影响其它 |
| 界面 | 纯 stdlib `tkinter`，双击 `.bat` 即可运行，无需额外 GUI 依赖 |

输出格式各自的特点：

- **docx** —— 主输出。公式是原生对象；代码块有底纹和边框；列表自己画符号（不用 Word 自动编号，
  避免多级列表序号串号）；超链接是真的超链接；中文字体显式设置了 `w:eastAsia`，中英混排不掉字形。
- **md** —— 带 YAML 元信息的 Markdown，公式保持 LaTeX 原文，方便丢进 Obsidian / Typora。
- **html** —— 自带样式的单文件网页，内置 MathJax。**想要 PDF？** 浏览器里 `Ctrl+P` → 另存为 PDF
  即可（勾选"背景图形"效果更好），不需要装任何 Office 组件。
- **txt** —— 纯文本，公式退化为 LaTeX 原文。
- **json** —— 结构化数据，方便二次处理。

---

## 二、快速开始

### 1. 启动（推荐：双击就好）

**双击 `启动 AI对话转Word.bat`**，剩下的事它自己会做：

1. **找解释器** —— 依次尝试 环境变量 `AISX_PYTHON` → 项目里的 `.venv` → 系统 Python；
2. **建隔离环境** —— 首次运行会在项目目录里创建 `.venv`，
   **不会往你的系统 Python 里装东西**（想用现成解释器就把完整路径写进 `AISX_PYTHON`）；
3. **补依赖** —— 缺什么装什么，装完再验一次，失败了会给出可手动执行的命令；
4. **启动界面** —— 用 `pythonw.exe` 拉起，不留黑框。

界面流程三步：**① 粘贴链接 → ② 选格式和目录 → ③ 点「开始导出」**。
右边会显示"浏览器渲染：可用/未安装"。

> 只想直接开界面？双击 `aisx_gui.pyw` 也行，前提是依赖已经装好。

### 2. 手动安装（可选）

如果你想自己控制环境：

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt

# 可选但强烈建议：浏览器渲染兜底
python -m playwright install chromium
```

### 3. 命令行

```bash
python -m aisx.cli "https://chat.deepseek.com/share/xxxxxxxx" -o D:/导出
```

---

## 三、支持的平台

| 平台 | 抓取策略 | 说明 |
| --- | --- | --- |
| **DeepSeek** | 官方分享接口 | ✅ 最稳，无需登录 |
| **ChatGPT** | 直取 HTML / 内嵌 JSON | 分享页是服务端渲染 |
| **Claude** | 直取 HTML / 内嵌 JSON | 分享页是服务端渲染 |
| **Kimi** | 浏览器渲染 | 分享页是前端渲染的空壳 |
| **豆包** | 浏览器渲染 | |
| **通义千问 / Qwen** | 浏览器渲染 | |
| **腾讯元宝** | 浏览器渲染 | |
| **智谱清言** | 浏览器渲染 | |
| **文心一言** | 浏览器渲染 | |
| **讯飞星火** | 浏览器渲染 | |
| **Gemini** | 浏览器渲染 | 部分地区需网络可达 |
| **Microsoft Copilot** | 浏览器渲染 | |
| **Grok** | 浏览器渲染 | |
| **Perplexity** | 浏览器渲染 | |
| **Poe** | 浏览器渲染 | |
| 其它任意网页 | 通用正文提取 | 未识别的域名走通用逻辑 |

> ⚠️ **关于"浏览器渲染"**：这类站点打开时会请求一个返回对话数据的接口。
> 本工具不需要针对每家网站逆向接口——它让 Playwright 真跑一遍 JS，
> **同时挂网络监听把那个 JSON 响应截下来**。这是"万能兜底"。
> 但前提是 `playwright` 和 chromium 已安装。

> ⚠️ **实测状态**：本机网络环境下，DeepSeek / Kimi / 豆包 / 通义 / 元宝 / Qwen 可达；
> ChatGPT / Claude / Grok / Gemini / Copilot / Poe / Perplexity 属于**区域受限或需要代理**，
> 代码路径已就绪但未能在本机用真实链接跑通。用这些平台时请自行确认网络可达。

平台识别是**可扩展**的：在 `aisx/platforms.py` 的 `PLATFORMS` 列表里加一条就行，
不用动抓取和导出逻辑。

---

## 四、公式为什么不会乱码

这是整个项目最核心、也最容易踩坑的部分。完整链路：

```
页面上的 KaTeX / MathJax 渲染结果
   ↓
   ├─ ① 标签属性通道   从 copy-text 等属性里取「未渲染的 LaTeX 原文」   ← 优先级最高
   ├─ ② MathML 通道    从 <annotation> / <math> 里取语义结构
   └─ ③ KaTeX 兜底     只取可见文本，★ 绝不把它当 LaTeX
   ↓  protect_math()      命中公式就换成占位符（避免 DOM 转文本时被拆成 <mrow> 乱码）
   ↓                     属性值里若含零宽字符 → 判废（那是渲染过的字形）
   ↓  restore_math()      还原成 $...$ / $$...$$；纯 MathML 的打上 MATHML 哨兵
Markdown（公式 = LaTeX 原文 或 MathML）
   ↓  mdparse._protect()  逐字符扫描，跳过代码块和行内代码，把公式抽成占位符
   ↓  absorb()            闸门：零宽字符拒收；MATHML 哨兵 → 标记为 mathml 分支
   ↓  sanitize_latex()    清洗 + 去零宽 + 定界符升格（见下）
   ↓  latex2mathml        LaTeX → MathML          ┐
   ↓  (或直接)             MathML → OMML          ┘ 视来源走其中一条
   ↓  mathml2omml         MathML → OMML
   ↓  normalize_omml()    ★ OMML 规范化（见下）
   ↓  repair_omml()       修补已知 bug
   ↓  omml_is_balanced()  标签配对校验，不合法就降级为文本，绝不写出坏文档
docx 里的原生 Word 公式对象（m:oMath / m:oMathPara）
```

### 4.1 三个真实踩过的坑

1. **`mathml2omml` 的 groupChr bug**
   `\vec` / `\bar` / `\overbrace` 这类"重音/花括号"结构，库会生成**闭合标签写错**的 XML
   （`<m:groupChrPr>` 用 `</m:groupChr>` 闭合）。Word 打开时会报"文档已损坏"。
   `repair_omml()` 用正则修正，`omml_is_balanced()` 兜底校验。

2. **`latex2mathml` 的 aligned bug**
   对 `\begin{aligned}` / `\begin{split}` 会吐出非法的裸 `&`。
   `sanitize_latex()` 把它们重写成 `\begin{array}{...}`。

3. **KaTeX 嵌套 span 被重复计数**
   页面上 `.katex-display` 里还嵌着 `.katex`，直接按选择器抓会**抓到两遍**。
   `_only_outermost()` 只保留最外层节点。

### 4.2 ★ 最凶的一个坑：把"渲染后的字形"当成了 LaTeX

豆包这类平台的 KaTeX 是 **HTML-only 输出**——它把公式渲染成 `<span>` 里的字形，
**不带** `<annotation encoding="application/x-tex">`。旧代码按 KaTeX 惯例去找 annotation，
找不到就退化成"取可见文本"，拿到的是 `β 1 `（末尾还挂着零宽字符 U+200B），
却被当成 LaTeX 硬喂进 `latex2mathml`。结果就是**一堆散字公式**。

为什么零宽字符这么阴险：`'\u200b'.isspace()` 是 `False`，`\s` 正则也匹配不到它，
所以它**穿透了所有基于"空白"的判空逻辑**，让"这是渲染残渣"看起来像"这是一段正常文本"。

现在三道防线：

- **属性通道优先**：`copy-text` 属性里存着未渲染的 LaTeX 原文，直接取走
- **零宽字符判废**：`_INVISIBLE_RE` 命中即认定"这是渲染过的字形"
- **不再伪造 LaTeX**：KaTeX 兜底分支只保留可见文本并计入 `math_failed`，**不包 `$…$`**

顺带修掉一个更隐蔽的 bug：`_UNICODE_MATH_RE` 原本写成 `\u1d400`，
Python 会解析成 `\u1d40` + 字面字符 `0`，于是造出一个 `0-\u1d7f` 的**非法区间**，
把整段 ASCII 都吞了进去（`x`、`abc` 都会被误判成数学符号）。
必须写 6 位的 `\U0001d400`。

### 4.3 ★ OMML 规范化：不用装 pandoc，也能得到"干净 OMML"

`mathml2omml` 产出的 OMML 和 pandoc(texmath) 的方言有几处系统性差异，
`normalize_omml()` 在树层面统一（幂等，可重复调用）：

| 改写器 | 解决什么 |
|---|---|
| `_tx_box` | `mathml2omml` 给**每个 `<mrow>` 都套一个 `<m:box>`**，导致公式全是"盒子装字符串"，没有真正的下标/分式结构。删掉无属性的 box |
| `_tx_sty` | `mathml2omml` 会显式写 `m:sty="i"`，但 OMML 默认就是斜体，冗余 |
| `_tx_delims` | 给 `m:d` 补 `sepChr=""` / `m:grow`，让括号能随内容伸缩 |
| `_tx_accents` | `\vec`/`\bar`/`\hat` 被渲染成 `m:groupChr`/`m:limUpp`，改写成标准的 `m:acc` + 组合字符（`\vec`→U+20D7） |
| `_tx_nary` | 给 `m:nary`（∑ ∫）补 `subHide`/`supHide` |

**定界符升格**：`mathml2omml` 只对 `\left(...\right)` 生成 `m:d`。
`sanitize_latex()` 里的 `_autosize_delims()` 会**在 LaTeX 源码层**把裸 `()` `[]` `{}`
升格为 `\left…\right`，于是括号也能成对变成 `m:d` 对象
（跳过 `\text{}` 内部、已带定界符的、以及跨表格 `&`/`\\` 的括号）。

这一层做完，产出的结构和 pandoc 方言**逐项对齐**，而且两处更正确：

- `\|`（KL 散度里的 `‖`）：pandoc 会渲染成一个**内容为空的** `m:e` 定界符；
  本实现保留字符本体，可复制、可编辑
- `\boldsymbol{\alpha}`：pandoc 给 `m:sty="b"`（粗体·正体）；
  LaTeX 的 `\boldsymbol` 对希腊字母给的是**粗斜体**，本实现的 `bi` 才是对的

**降级策略**：万一某个公式确实转换不出来（比如用了一个没人支持的宏），
它会被写成一段红色等宽字体的原文，同时记进文档末尾的"导出说明"里。
**宁可看见原文，也不会写出让 Word 打不开的文档。**

> 详细的取证过程、逐项差异表、pandoc 交叉验证和修复验证，见
> `公式格式对比分析_QREAL63_vs_aisx.md`（第七节是修复实施与验证）。

### 4.4 ★ 大纲组织：对话树（导航窗格折叠）+ 书签锚点 + 可选目录页

导出后的 Word 文档要能像正式报告一样**导航**，关键在三件事，本实现已对照
参考程序（豆包思维导图那份导出）逐项对齐：

1. **对话树大纲（每条消息 = 一个一级节点）**
   默认 `outline_mode="auto"`：两条以上用户消息即进入 **dialogue** 模式——
   每条消息本身是一个一级标题节点（`我：<提问>` / `豆包：`），消息内部
   的 Markdown 标题被抬到 **2 级起步**（二级/三级子目录）。折叠 Word/WPS
   的"导航窗格"后，顶层只显示各条消息，展开任一消息才露出其细节。这与
   参考程序"顶层干净、细节内嵌、可收缩"的组织完全一致。
   - `user_label`（默认 `我`）、`assistant_label`（默认用平台名，如 `豆包`）
     控制节点前缀；助手节点默认只放标签，正文随后展开（不重复）。
   - 单条消息、或显式 `outline_mode="document"` 时退回"普通文档"模式：按每条
     消息把最浅标题归一为 1 级。
   - 旧键 `group_by_turn=True` 现等价于 `outline_mode="dialogue"`。

2. **书签锚点（每个标题一个）**
   参考程序会在每个标题处放置 `w:bookmarkStart/End` 书签。本实现在
   `_blk_heading()` 里对每个标题调用 `add_bookmark()`，书签名 `Sec1…SecN`
   （唯一、合法），使文档具备可跳转的章节锚点。

3. **可见目录页（可选，默认关闭）**
   `toc=True` 时 `build_toc()` 在正文前插入一个"目录"页：列出各级标题，
   每条都是指向对应书签的**内部超链接**（`w:hyperlink w:anchor=…`），离线
   也能点跳。默认 `toc=False`——对话/文档层级完全靠导航窗格收缩即可，
   不需要在正文体里再塞一页目录。

```python
# 对话树（默认）：每条消息=一级节点，靠导航窗格收缩，无可见目录页
DocxBuilder(conv, options={"outline_mode": "dialogue"})
# 退回普通文档：每条消息最浅标题归一为 1 级
DocxBuilder(conv, options={"outline_mode": "document"})
# 想点跳时再开可见目录页
DocxBuilder(conv, options={"toc": True, "toc_depth": 3})
```

> 实测：同一份豆包对话（39 条消息）默认导出后，一级节点 = **39**（19 个
> `我：` + 20 个 `豆包：`），内部子标题落在 H2/H3/H4，全文档 355 个标题各
> 带书签、**0 条可见目录链接**（正文无目录页）；806 处公式转为可编辑对象。
> 回归见 `tests/test_toc.py`（dialogue 默认 / document 归一化 / toc 可选 /
> depth 限制）与 `tests/test_toc_group.py`（dialogue + depth 限制 + `toc=False`）。

---

## 五、命令行用法

```bash
# 单个链接，导出 docx
python -m aisx.cli "https://chat.deepseek.com/share/xxxx" -o D:/导出

# 一次导出多种格式
python -m aisx.cli "https://chat.deepseek.com/share/xxxx" -o D:/导出 -f docx,md,html

# 一次给多个链接
python -m aisx.cli URL1 URL2 URL3 -o D:/导出

# 从文件读链接（每行一个，也可以是一整段分享文案）
python -m aisx.cli --file links.txt -o D:/导出

# 指定输出文件名
python -m aisx.cli URL -o D:/导出 --name 我的笔记

# 导出思维链
python -m aisx.cli URL -o D:/导出 --thinking

# 不输出头部元信息
python -m aisx.cli URL -o D:/导出 --no-meta

# 关掉浏览器渲染（更快，但前端渲染的站点可能抓不到）
python -m aisx.cli URL -o D:/导出 --no-render

# 排查问题：把浏览器窗口显示出来，看看实际打开了什么页面
python -m aisx.cli URL -o D:/导出 --show-browser

# 网慢，渲染后多等一会儿
python -m aisx.cli URL -o D:/导出 --wait 12000

# 安静模式，只输出结果文件路径（方便脚本里用）
python -m aisx.cli URL -o D:/导出 -q
```

全部参数：

| 参数 | 默认值 | 说明 |
| --- | --- | --- |
| `urls` | — | 一个或多个分享链接 |
| `-o, --out` | `.` | 输出目录 |
| `-f, --formats` | `docx` | 逗号分隔，可选 `docx,md,html,txt,json` |
| `--file` | — | 从文本文件读链接 |
| `--name` | — | 指定输出文件名（仅单链接有效） |
| `--no-render` | 关 | 禁用浏览器渲染 |
| `--show-browser` | 关 | 渲染时显示浏览器窗口 |
| `--wait` | `6000` | 渲染后再等待的毫秒数 |
| `--timeout` | `30` | HTTP 超时秒数 |
| `--thinking` | 关 | 导出思维链 |
| `--no-meta` | 关 | 不输出头部元信息 |
| `-q, --quiet` | 关 | 安静模式 |
| `-v, --version` | — | 版本号 |

---

## 六、当成库来用

```python
from aisx import convert_url, urls_from_text

# 从一段分享文案里挑链接
urls = urls_from_text("我刚问了个问题 https://chat.deepseek.com/share/xxxx 你看看")
print(urls)

r = convert_url(
    "https://chat.deepseek.com/share/xxxx",
    out_dir="D:/导出",
    formats=("docx", "md"),
    options={"include_thinking": True},
    progress=lambda m: print("  ", m),
)
print(r.ok, r.files)
print(r.summary())     # "12 条消息，公式 37 处已转为可编辑对象"
```

`Result` 对象：`url` / `ok` / `files` / `conv`（`Conversation`）/ `error` / `stats`。

数据结构就两个，所有导出格式都只认这一层，所以新增平台只要写"怎么拿到原始数据"：

```python
Conversation(title, url, platform, platform_name, model, created,
             fetched_at, messages, source, notes)
Message(role, content, thinking, model, timestamp, files)
# role 会被 normalize_role() 归一成 user / assistant / system / tool
```

---

## 七、项目结构

```
ai_share_export/
├── 启动 AI对话转Word.bat      # 双击启动（自动建 .venv + 检查依赖）
├── aisx_gui.pyw               # 图形界面（纯 stdlib tkinter）
├── requirements.txt
├── README.md
├── .venv/                     # 独立运行环境（首次双击 .bat 时自动创建）
├── aisx_settings.json         # 界面设置（首次运行后自动生成）
├── aisx/
│   ├── __init__.py            # 对外导出
│   ├── platforms.py           # 平台识别表（想加平台改这里）
│   ├── models.py              # Conversation / Message（统一数据层）
│   ├── fetch.py               # 三级抓取：接口 → HTTP/内嵌JSON → 浏览器渲染+嗅探
│   ├── extract.py             # 从 HTML / JSON / DOM 里把对话抠出来（含豆包内嵌 JSON 适配器）
│   ├── htmlmd.py              # HTML → Markdown（公式三级优先通道、噪声清理）
│   ├── mathfix.py             # 公式核心：LaTeX/MathML → OMML + 规范化 + 修补 + 校验
│   ├── mdparse.py             # Markdown → 中间表示 IR
│   ├── docxwriter.py          # IR → docx（公式、代码块、列表、表格、超链接）
│   ├── exporters.py           # md / html / txt / json 导出
│   ├── convert.py             # 对外总入口 convert_url / convert_many
│   └── cli.py                 # 命令行
├── _tools/                    # 取证/对比脚本（compare_omml.py 等，非运行时依赖）
└── tests/
    ├── test_all.py            # 一键回归
    ├── test_latex_coverage.py # 79 个公式用例的转换覆盖率
    ├── test_smoke.py          # docx 生成 + OOXML 结构合法性
    ├── test_dom.py            # KaTeX 还原 + DOM 消息切分
    ├── test_pw.py             # Playwright 渲染通路
    ├── test_ds2.py            # DeepSeek 双通路（需联网）
    ├── katex_fixture.py       # 用真 KaTeX（Node）渲染公式 DOM
    ├── fixture_page.py        # 拼仿真对话页
    └── _out/                  # 测试产物
```

> 🔧 **维护提示（改 `.bat` 前必读）**：`启动 AI对话转Word.bat` 是 **GBK(CP936) 编码 + CRLF 行尾**。
> 中文 Windows 的 ANSI 代码页就是 936，批处理必须与之匹配；而 `cmd.exe` 解析**纯 LF 行尾**的批处理
> 会把语句切碎（表现为 `'xxx' 不是内部或外部命令`、`!VAR!` 不展开）。
> 如果你用 VS Code / 记事本改它，**务必另存为 ANSI(GBK) 且保留 CRLF**，否则一定出问题。

> ⚠️ **playwright 版本是锁死的（`==1.59.0`）**，别随手升级。
> playwright 每个版本绑定**特定的 chromium 构建号**（1.59 → `chromium-1217`，1.63 → `chromium-1243`）。
> 升级 python 包但没重新 `playwright install chromium`，就会报
> `Executable doesn't exist at ...chromium_headless_shell-XXXX...`，
> 前端渲染的站点全部抓不到，而且**离线测试 `test_pw.py` 会直接失败**。
> 真要升级：改 `requirements.txt` 后必须跟着执行一次 `playwright install chromium`（约 150 MB）。


设计上有一条主线：**抓取层只负责"拿到 Conversation"，导出层只负责"把 Conversation 画出来"**，
中间用 `models.py` 隔开。所以加一个平台不用碰导出，
加一种输出格式（比如 PDF/EPUB）不用碰抓取——只要写一个新的渲染器。

---

## 八、测试

```bash
python tests/test_all.py
```

依次跑五项，除最后一项需要联网外全部离线可跑：

| 测试 | 内容 |
| --- | --- |
| `test_latex_coverage.py` | **79 个公式用例**（物理、ML、矩阵、对齐环境、中文混排、`\vec`/`\bar` 等重音……）全部走真实管线，要求 100% 产出合法 OMML |
| `test_smoke.py` | 生成含公式/代码/表格/列表/引用的 docx，解压 `word/document.xml` 做 OOXML 体检 |
| `test_dom.py` | 用**真 KaTeX 渲染出的 DOM** 拼仿真对话页，验证公式还原、消息切分、噪声清理 |
| `test_pw.py` | Playwright 渲染通路（离线本地页） |
| `test_ds2.py` | DeepSeek 双通路端到端（需联网） |

`test_smoke.py` 做的结构校验比"能生成文件"严格得多，它会：

1. 解压 docx，确认 `[Content_Types].xml` / `word/document.xml` / `_rels/.rels` 都在；
2. 用 `ElementTree` 解析 `document.xml`，确认是**合法 XML**；
3. 逐个 `<w:p>`、`<w:r>`、`<w:body>` 检查直接子元素是否都在 **OOXML 白名单**内
   （塞进非法子元素，Word 打开时会报"文档已损坏"）；
4. 数 `m:oMath` / `m:oMathPara`，要求**等于** IR 里的公式节点数——
   一个都不能少，也不能出现"降级成红色文本"（`math_failed` 必须为 0）；
5. 确认每个 `m:oMath` 都挂在 `w:p` 底下、每个 `oMathPara` 都正确包裹了 `oMath`；
6. 扫描正文，确认没有 `$$` / `\begin{` / `\frac{` 这类**原始 LaTeX 泄漏**；
7. 确认关键文案、思维链、超链接（URL 应在 `document.xml.rels` 里）都在；
8. 用 `python-docx` 把生成的文件**再读一遍**，排除"能生成但打不开"。

当前状态：**全部通过**（79/79 公式用例，docx 16/16 原生公式对象，36 项结构断言全部 PASS）。

---

## 九、常见问题

**Q：导出的 Word 里公式还是红的、显示成 `\frac{...}` 怎么办？**
说明这个公式转换失败了，属于降级。请翻到文档末尾的"导出说明"，那里列了失败原因。
把那个公式发我，我加一条 `sanitize_latex()` 规则或者补个修补。

**Q：提示"没有抓到任何对话内容"。**
按顺序排查：
1. 确认用的是**分享链接**，不是浏览器地址栏里需要登录的会话地址；
2. 加 `--show-browser` 再跑一次，看浏览器里实际打开了什么页面
   （经常是要登录、或者地区限制、或者是个验证码页）；
3. 前端渲染的站点必须装浏览器组件：
   `python -m pip install playwright && python -m playwright install chromium`；
4. 网慢就把 `--wait` 调大（比如 `--wait 12000`）。

**Q：抓到了内容但缺了一段。**
可能是那个平台把内容分页/折叠了。加 `--show-browser` 观察，
或者把链接发我看看页面结构。

**Q：能批量吗？**
能。一行一个链接，或者 `--file links.txt`。单个失败不影响其它。

**Q：中文变成方块/问号？**
docx 里已经显式设了 `w:eastAsia` 字体（默认微软雅黑）。
如果你机器上没这个字体，改 `aisx/docxwriter.py` 顶部的 `EA_FONT` 就行。

**Q：想要 PDF？**
用 `-f html` 导出，浏览器打开后 `Ctrl+P` → 另存为 PDF。

**Q：会不会把危险内容写进文档？**
不会。公式转换失败时是降级成红色文本 + 记入尾注，
`omml_is_balanced()` 会拦住标签不配对的输出。宁可看得见原文，也不会让 Word 打不开。

---

## 十、已知限制

- **登录墙 / 区域限制**：需要登录才能看的会话、地区受限的平台（ChatGPT、Claude、Gemini 等），
  本工具抓不到。这不是 bug，是访问权限问题。
- **区域受限平台未实测**：见[第三节](#三支持的平台)的说明，代码路径就绪但本机网络未能验证。
- **图片不下载**：文档里只保留图片的替代文字和原图链接，不做下载嵌入。
- **超长对话**：几千条消息的会话，浏览器渲染会比较慢（`--wait` 可能要调大）。
- **公式宏**：KaTeX 私有宏（`\ce`、`\genfrac` 等）会被清洗掉，
  极冷门的宏可能转换失败并降级为文本。
- **公式方言**：与 pandoc 参考实现相比，还有 3 处**非实质**差异
  （`\|` 的表示、`\boldsymbol` 的 `b`/`bi`、相邻 run 的合并粒度），
  见 [4.3](#43--omml-规范化不用装-pandoc-也能得到干净-omml)，不影响显示与编辑。
- **`txt` / `json` 不含公式渲染**：公式保持 LaTeX 原文（这是设计意图，方便给别的工具吃）。

---

## 许可

自用工具，随意修改。
