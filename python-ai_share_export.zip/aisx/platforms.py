# -*- coding: utf-8 -*-
"""平台识别表。

只做一件事：给定一个分享链接，判断它属于哪个平台、叫什么名字、
以及优先用哪条抓取策略。抓取逻辑本身不在这里。
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlparse


# 每个平台：
#   key          内部标识
#   name         中文名（写进文档）
#   domains      域名匹配（用 endswith 判断，避免 evil-chat.deepseek.com 之类误判）
#   paths        路径前缀（可选，用于同域多产品的区分，如 kimi 的 /share/）
#   strategy     首选策略：
#                  "api"       官方 JSON 接口
#                  "html"      直接抓 HTML（SSR 或内嵌 JSON）
#                  "render"    需要浏览器渲染
#   note         给用户的提示
PLATFORMS: List[Dict] = [
    {
        "key": "deepseek",
        "name": "DeepSeek",
        "domains": ["chat.deepseek.com", "deepseek.com"],
        "paths": ["/share/", "/a/chat/s/"],
        "strategy": "api",
        "note": "使用 DeepSeek 官方分享接口，无需登录，最稳定。",
    },
    {
        "key": "chatgpt",
        "name": "ChatGPT",
        "domains": ["chatgpt.com", "chat.openai.com"],
        "paths": ["/share/"],
        "strategy": "html",
        "note": "ChatGPT 分享页为服务端渲染，优先直取；失败时自动改用浏览器渲染。",
    },
    {
        "key": "claude",
        "name": "Claude",
        "domains": ["claude.ai"],
        "paths": ["/share/"],
        "strategy": "html",
        "note": "Claude 分享页为服务端渲染；部分地区需网络可达。",
    },
    {
        "key": "kimi",
        "name": "Kimi",
        "domains": ["kimi.com", "kimi.moonshot.cn", "moonshot.cn"],
        "paths": ["/share/"],
        "strategy": "render",
        "note": "Kimi 分享页是前端渲染的空壳，需要浏览器渲染抓取。",
    },
    {
        "key": "doubao",
        "name": "豆包",
        "domains": ["doubao.com", "www.doubao.com"],
        "paths": ["/s/", "/thread/", "/share/"],
        "strategy": "render",
        "note": "豆包分享链接需要浏览器渲染抓取。",
    },
    {
        "key": "tongyi",
        "name": "通义千问",
        "domains": ["tongyi.com", "tongyi.aliyun.com", "qwen.ai", "chat.qwen.ai", "share.tongyi.aliyun.com"],
        "paths": [],
        "strategy": "render",
        "note": "通义/千问分享页需要浏览器渲染抓取。",
    },
    {
        "key": "yuanbao",
        "name": "腾讯元宝",
        "domains": ["yuanbao.tencent.com"],
        "paths": [],
        "strategy": "render",
        "note": "元宝分享页需要浏览器渲染抓取。",
    },
    {
        "key": "zhipu",
        "name": "智谱清言",
        "domains": ["chatglm.cn", "chatglm.com"],
        "paths": [],
        "strategy": "render",
        "note": "智谱清言分享页需要浏览器渲染抓取。",
    },
    {
        "key": "yiyan",
        "name": "文心一言",
        "domains": ["yiyan.baidu.com", "wenxin.baidu.com"],
        "paths": [],
        "strategy": "render",
        "note": "文心一言分享页需要浏览器渲染抓取。",
    },
    {
        "key": "xinghuo",
        "name": "讯飞星火",
        "domains": ["xinghuo.xfyun.cn", "xfyun.cn"],
        "paths": [],
        "strategy": "render",
        "note": "讯飞星火分享页需要浏览器渲染抓取。",
    },
    {
        "key": "gemini",
        "name": "Gemini",
        "domains": ["gemini.google.com", "g.co", "bard.google.com"],
        "paths": [],
        "strategy": "render",
        "note": "Gemini 分享页需要浏览器渲染抓取，且部分区域需要网络可达。",
    },
    {
        "key": "copilot",
        "name": "Microsoft Copilot",
        "domains": ["copilot.microsoft.com"],
        "paths": ["/shares/"],
        "strategy": "render",
        "note": "",
    },
    {
        "key": "grok",
        "name": "Grok",
        "domains": ["grok.com", "x.com", "twitter.com"],
        "paths": ["/share/", "/i/grok"],
        "strategy": "render",
        "note": "",
    },
    {
        "key": "perplexity",
        "name": "Perplexity",
        "domains": ["perplexity.ai", "www.perplexity.ai"],
        "paths": ["/search/"],
        "strategy": "render",
        "note": "",
    },
    {
        "key": "poe",
        "name": "Poe",
        "domains": ["poe.com"],
        "paths": ["/s/"],
        "strategy": "render",
        "note": "",
    },
]

_BY_KEY = {p["key"]: p for p in PLATFORMS}
_GENERIC = {
    "key": "generic",
    "name": "通用网页",
    "domains": [],
    "paths": [],
    "strategy": "html",
    "note": "未识别的站点，按通用网页正文提取处理。",
}


def _host_matches(host: str, domain: str) -> bool:
    host = (host or "").lower().strip(".")
    domain = domain.lower().strip(".")
    return host == domain or host.endswith("." + domain)


def detect(url: str) -> Dict:
    """根据 URL 返回平台信息字典（未识别时返回通用配置）。"""
    try:
        parsed = urlparse(url if "://" in url else "https://" + url)
    except Exception:
        return dict(_GENERIC)
    host = parsed.netloc.split("@")[-1].split(":")[0]
    path = parsed.path or "/"

    best: Optional[Dict] = None
    best_score = -1
    for p in PLATFORMS:
        if not any(_host_matches(host, d) for d in p["domains"]):
            continue
        score = 1
        if p.get("paths"):
            if any(path.startswith(pp) for pp in p["paths"]):
                score = 3
            else:
                score = 1  # 域名对上了但路径不像分享链接，仍然接受但降级
        # 域名越长匹配得越精确
        score += max(len(d) for d in p["domains"] if _host_matches(host, d)) / 1000.0
        if score > best_score:
            best_score = score
            best = p
    if best is None:
        return dict(_GENERIC)
    return dict(best)


def by_key(key: str) -> Dict:
    return dict(_BY_KEY.get(key, _GENERIC))


def display_name(key: str) -> str:
    return by_key(key).get("name", key or "未知平台")


# 从任意一串文本里抽出 URL（用户经常把一整段分享文案粘进来）
_URL_RE = re.compile(r"https?://[^\s'\"<>（）()【】,，。；;]+", re.I)


def extract_urls(text: str) -> List[str]:
    """从一段文本中提取所有 http(s) 链接，保持出现顺序、去掉重复。

    同时处理"分享文案里链接被中文字符紧贴"的常见情况。
    """
    if not text:
        return []
    found = _URL_RE.findall(text)
    out: List[str] = []
    for u in found:
        u = u.rstrip(".,;:!?)]}>\"'")
        if u and u not in out:
            out.append(u)
    return out
