# -*- coding: utf-8 -*-
"""命令行入口。

用法示例
--------
    # 单个链接，导出 docx
    python -m aisx.cli "https://chat.deepseek.com/share/xxxx" -o D:/导出

    # 一次导出多种格式
    python -m aisx.cli "https://chat.deepseek.com/share/xxxx" -o D:/导出 -f docx,md,html

    # 一次给多个链接
    python -m aisx.cli URL1 URL2 URL3 -o D:/导出

    # 从文件里读链接（每行一个，或一整段分享文案都行）
    python -m aisx.cli --file links.txt -o D:/导出

    # 关掉浏览器渲染（更快，但前端渲染的站点可能抓不到）
    python -m aisx.cli URL -o out --no-render

    # 导出思维链
    python -m aisx.cli URL -o out --thinking
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import List

# 允许 `python aisx/cli.py` 直接跑
if __package__ in (None, ""):
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from aisx import __version__  # noqa: E402
from aisx import convert as cv  # noqa: E402
from aisx.exporters import SUPPORTED_FORMATS, normalize_format  # noqa: E402


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="aisx",
        description="把 AI 对话分享链接导出成 Word / Markdown / HTML（公式为可编辑对象）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("urls", nargs="*", help="一个或多个分享链接")
    p.add_argument("-o", "--out", default=".", help="输出目录（默认当前目录）")
    p.add_argument("-f", "--formats", default="docx",
                   help="导出格式，逗号分隔，可选：%s（默认 docx）" % ",".join(SUPPORTED_FORMATS))
    p.add_argument("--file", help="从文本文件读取链接（每行一个，也可以是一整段分享文案）")
    p.add_argument("--name", help="指定输出文件名（不含扩展名，仅单个链接时有效）")
    p.add_argument("--no-render", action="store_true", help="禁用浏览器渲染")
    p.add_argument("--show-browser", action="store_true", help="渲染时显示浏览器窗口（排查问题时用）")
    p.add_argument("--wait", type=int, default=6000, help="渲染后再等待的毫秒数（默认 6000）")
    p.add_argument("--timeout", type=int, default=30, help="HTTP 超时秒数（默认 30）")
    p.add_argument("--thinking", action="store_true", help="导出 AI 的思维链/推理过程")
    p.add_argument("--no-meta", action="store_true", help="不输出头部元信息（平台/模型/链接等）")
    p.add_argument("--document", action="store_true",
                   help="普通文档大纲（每条消息最浅标题归一为 1 级）；默认是对话树（每条消息=一级节点）")
    p.add_argument("--toc", action="store_true",
                   help="在正文前插入可见目录页（默认不插，靠 Word 导航窗格收缩）")
    p.add_argument("-q", "--quiet", action="store_true", help="安静模式，只输出结果路径")
    p.add_argument("-v", "--version", action="version", version="aisx %s" % __version__)
    return p


def collect_urls(args: argparse.Namespace) -> List[str]:
    raw: List[str] = []
    raw.extend(args.urls or [])
    if args.file:
        with open(args.file, "r", encoding="utf-8", errors="ignore") as f:
            raw.append(f.read())
    text = "\n".join(raw)
    urls = cv.urls_from_text(text)
    # 用户可能直接给的是不带协议的裸域名，这里不做猜测，只提示
    return urls


def main(argv: List[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    urls = collect_urls(args)
    if not urls:
        print("没有找到任何 http(s) 链接。请把分享链接直接贴在命令后面，或用 --file 指定文件。")
        return 2

    formats = [normalize_format(x) for x in (args.formats or "docx").split(",") if x.strip()]
    bad = [f for f in formats if f not in SUPPORTED_FORMATS]
    if bad:
        print("不支持的格式：%s（可选：%s）" % (",".join(bad), ",".join(SUPPORTED_FORMATS)))
        return 2

    options = {
        "include_thinking": bool(args.thinking),
        "include_meta": not args.no_meta,
        "outline_mode": "document" if args.document else "dialogue",
        "toc": bool(args.toc),
    }

    def progress(msg: str) -> None:
        if not args.quiet:
            print("  " + msg, flush=True)

    if not args.quiet:
        print("共 %d 个链接，导出格式：%s" % (len(urls), ", ".join(formats)))

    results = cv.convert_many(
        urls,
        out_dir=args.out,
        formats=formats,
        filename=args.name if len(urls) == 1 else None,
        allow_render=not args.no_render,
        headless=not args.show_browser,
        wait_ms=args.wait,
        timeout=args.timeout,
        options=options,
        progress=progress,
    )

    ok = 0
    if not args.quiet:
        print("\n" + "=" * 62)
    for r in results:
        if r.ok:
            ok += 1
            if args.quiet:
                for f in r.files:
                    print(f)
            else:
                print("✔ %s" % r.title)
                for f in r.files:
                    print("    %s" % f)
                print("    %s" % r.summary())
        else:
            print("✘ %s" % r.url)
            print("    %s" % r.error)

    if not args.quiet:
        print("=" * 62)
        print("完成：成功 %d / 共 %d" % (ok, len(results)))
        if ok == 0:
            print("\n排查建议：")
            print("  1) 确认链接是「分享链接」而不是需要登录的会话地址")
            print("  2) 加上 --show-browser 看看浏览器里实际打开了什么页面")
            print("  3) 确认已安装浏览器组件：playwright install chromium")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
