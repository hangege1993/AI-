# -*- coding: utf-8 -*-
"""把各种形态的原始数据归一成"一问一答"的消息列表。

要对付的原始数据有三种形态：

1. **规整的官方接口**（DeepSeek 分享接口）—— 直接有 messages 数组。
2. **平台自己的内部结构**（ChatGPT 的 mapping 树、Claude 的 chat_messages）—— 写专门适配器。
3. **完全未知的 JSON / 渲染后的 DOM** —— 用通用启发式：
   递归扫描整棵 JSON 树，找"看起来像消息列表"的数组；
   扫 DOM，找"看起来像消息气泡"的节点。

原则：宁可多收几个候选再挑最好的，也不要漏掉内容。
"""

from __future__ import annotations

import html as _htmlescape
import json
import re
from typing import Any, Dict, Iterable, List, Optional, Tuple

from bs4 import BeautifulSoup
from bs4.element import Tag

from .htmlmd import html_to_markdown, protect_math, restore_math, strip_chrome, find_conversation_root, _AIExportConverter, _tidy_markdown
from .models import Message, normalize_role

# 可能承载"消息正文"的字段名
_CONTENT_KEYS = (
    "content", "text", "message", "answer", "response", "reply", "body",
    "markdown", "md", "output", "value", "prompt", "question", "completion",
    "html", "raw", "segments",
)
_ROLE_KEYS = ("role", "sender", "author", "from", "type", "who", "speaker", "participant")
_THINK_KEYS = ("thinking", "reasoning", "reasoning_content", "thinking_content", "cot", "chain_of_thought", "thoughts")
_TIME_KEYS = ("created_at", "createdAt", "timestamp", "time", "inserted_at", "create_time", "date", "updated_at")
_MODEL_KEYS = ("model", "model_name", "model_type", "modelName", "engine")

_ROLE_ISH = {
    "user", "assistant", "system", "human", "ai", "bot", "model", "tool",
    "function", "prompt", "response", "answer", "question", "completion",
}


# --------------------------------------------------------------------------
# 一、通用 JSON 提取
# --------------------------------------------------------------------------

def _iter_dicts(obj: Any) -> Iterable[Dict[str, Any]]:
    """深度遍历，产出所有 dict。"""
    stack = [obj]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            yield cur
            stack.extend(cur.values())
        elif isinstance(cur, (list, tuple)):
            stack.extend(cur)


def _iter_lists(obj: Any) -> Iterable[List[Any]]:
    stack = [obj]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            stack.extend(cur.values())
        elif isinstance(cur, (list, tuple)):
            if cur:
                yield list(cur)
            stack.extend(cur)


def _first_str(d: Dict[str, Any], keys: Iterable[str]) -> str:
    for k in keys:
        if k in d:
            v = d[k]
            if isinstance(v, str) and v.strip():
                return v
            if isinstance(v, (int, float)):
                return v
    # 大小写不敏感再试一次
    low = {str(k).lower(): k for k in d.keys()}
    for k in keys:
        lk = k.lower()
        if lk in low:
            v = d[low[lk]]
            if isinstance(v, str) and v.strip():
                return v
    return ""


def _coerce_content(value: Any, thinking_out: Optional[List[str]] = None) -> str:
    """把千奇百怪的 content 字段压成一个 Markdown 字符串。

    thinking_out 不为空时，把思维链/推理类的内容塞进去，而不是混进正文。
    """
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (int, float, bool)):
        return str(value)

    if isinstance(value, (list, tuple)):
        chunks: List[str] = []
        for item in value:
            piece = _coerce_content(item, thinking_out)
            if piece and piece.strip():
                chunks.append(piece.strip())
        return "\n\n".join(chunks)

    if isinstance(value, dict):
        # 显式的类型标签
        btype = str(value.get("type") or value.get("kind") or "").lower()
        if thinking_out is not None and btype in ("thinking", "reasoning", "thought", "analysis", "summary_text"):
            piece = _coerce_content(value.get("text") or value.get("thinking") or value.get("content"), None)
            if piece.strip():
                thinking_out.append(piece.strip())
            return ""
        if btype in ("tool_use", "tool_result", "function_call", "code_interpreter", "server_tool_use"):
            name = value.get("name") or value.get("tool_name") or "工具调用"
            return "\n> [%s 调用已省略]\n" % name
        if btype in ("image", "image_url"):
            return "\n> [图片]\n"
        # 递归找正文
        for k in _CONTENT_KEYS:
            if k in value and value[k] not in (None, "", [], {}):
                got = _coerce_content(value[k], thinking_out)
                if got.strip():
                    return got
        if "parts" in value:
            return _coerce_content(value["parts"], thinking_out)
        # 兜底：把所有字符串拼起来（但避免把角色名也拼进去）
        bits = [str(v) for k, v in value.items()
                if isinstance(v, str) and k.lower() not in _ROLE_KEYS and len(str(v)) > 0]
        return "\n\n".join(bits)
    return str(value)


def _looks_like_message(d: Dict[str, Any]) -> Tuple[bool, Dict[str, Any]]:
    """判断一个 dict 是不是一条消息，返回 (是否, 打分信息)。"""
    info: Dict[str, Any] = {}
    role_raw = None
    for k in _ROLE_KEYS:
        if k in d and isinstance(d[k], str) and d[k].strip():
            role_raw = d[k].strip()
            break
    info["role_raw"] = role_raw

    content_len = 0
    content_key = None
    for k in _CONTENT_KEYS:
        if k in d and d[k] not in (None, "", [], {}):
            v = d[k]
            if isinstance(v, str):
                content_len = len(v)
            elif isinstance(v, (list, dict)):
                content_len = len(json.dumps(v, ensure_ascii=False, default=str))
            if content_len > 0:
                content_key = k
                break
    info["content_len"] = content_len
    info["content_key"] = content_key

    has_role_attr = role_raw is not None and role_raw.lower() in _ROLE_ISH
    if content_key is None:
        return False, info
    if not has_role_attr and _first_str(d, _THINK_KEYS) == "":
        # 没有明确的角色字段，也没有 thinking 字段 → 不太像
        return False, info
    return True, info


def score_message_array(arr: List[Any]) -> float:
    """给一个候选数组打分，分越高越像主对话。"""
    dicts = [x for x in arr if isinstance(x, dict)]
    if not dicts:
        return -1.0
    ratio = len(dicts) / float(len(arr))
    hits = 0
    total_len = 0
    roles = set()
    for d in dicts:
        ok, info = _looks_like_message(d)
        if ok:
            hits += 1
            total_len += info.get("content_len") or 0
            rr = info.get("role_raw")
            if rr:
                roles.add(normalize_role(rr))
    if hits == 0:
        return -1.0
    score = 0.0
    score += hits * 12.0
    score += min(total_len, 20000) / 100.0
    score += ratio * 20.0
    # 同时出现 user 和 assistant 是强信号
    if "user" in roles and "assistant" in roles:
        score += 60.0
    # 数组太短且没有对话结构，扣分
    if hits == 1 and "user" not in roles:
        score -= 25.0
    return score


def extract_from_json(obj: Any) -> Tuple[List[Message], List[str]]:
    """从任意 JSON 结构里挖出消息列表。"""
    notes: List[str] = []
    best_arr: Optional[List[Any]] = None
    best_score = 0.0
    for arr in _iter_lists(obj):
        s = score_message_array(arr)
        if s > best_score:
            best_score, best_arr = s, arr
    if best_arr is None or best_score <= 0:
        return [], notes

    messages = _array_to_messages(best_arr)
    # 如果挑出来的数组里没有任何"问答配对"，可能挑错了，再试第二名不划算，直接提示
    if messages and not any(m.role == "user" for m in messages):
        notes.append("未在数据中识别出明确的用户提问，请核对抓取结果。")
    return messages, notes


def _array_to_messages(arr: List[Any]) -> List[Message]:
    out: List[Message] = []
    for item in arr:
        if not isinstance(item, dict):
            continue
        ok, _ = _looks_like_message(item)
        if not ok:
            continue
        out.append(_dict_to_message(item))
    return _fix_roles(out)


def _dict_to_message(d: Dict[str, Any]) -> Message:
    thinking: List[str] = []
    content = ""
    for k in _CONTENT_KEYS:
        if k in d and d[k] not in (None, "", [], {}):
            content = _coerce_content(d[k], thinking)
            if content.strip():
                break
    if not content.strip():
        content = _coerce_content(d, thinking)

    think_txt = _first_str(d, _THINK_KEYS)
    if think_txt and thinking is not None:
        thinking.insert(0, think_txt)

    role_raw = _first_str(d, _ROLE_KEYS)
    return Message(
        role=normalize_role(role_raw) if role_raw else "assistant",
        content=content.strip(),
        thinking="\n\n".join(t for t in thinking if t.strip()),
        model=_first_str(d, _MODEL_KEYS),
        timestamp=str(_first_str(d, _TIME_KEYS) or ""),
    )


def _fix_roles(msgs: List[Message]) -> List[Message]:
    """有些平台不给角色，只有顺序。按"用户先开口"的常识交替补齐。"""
    if not msgs:
        return msgs
    if all(m.role == "assistant" for m in msgs) and len(msgs) > 1:
        for i, m in enumerate(msgs):
            m.role = "user" if i % 2 == 0 else "assistant"
    return msgs


# --------------------------------------------------------------------------
# 二、平台专属适配器
# --------------------------------------------------------------------------

# DeepSeek 新版接口不再给 content，而是给 fragments 列表，
# 每个 fragment 用 type 区分：REQUEST（用户提问）/ THINK（思维链）/ RESPONSE（正式回答）...
_FRAG_THINK = {"THINK", "THINKING", "REASONING", "COT", "ANALYSIS", "THOUGHT"}
_FRAG_ANSWER = {"RESPONSE", "ANSWER", "CONTENT", "TEXT", "MESSAGE", "COMPLETION"}
_FRAG_REF = {"SEARCH", "WEB_SEARCH", "REFERENCE", "REFERENCES", "TOOL", "TOOL_CALL", "CITATION"}
_FRAG_QUERY = {"REQUEST", "QUERY", "PROMPT", "QUESTION", "USER"}


def _split_fragments(frags: Any) -> Tuple[str, str]:
    """把 fragments 列表拆成 (正文, 思维链)。返回正文在前。"""
    if not isinstance(frags, (list, tuple)):
        return "", ""
    answer: List[str] = []
    think: List[str] = []
    for fr in frags:
        if isinstance(fr, str):
            answer.append(fr)
            continue
        if not isinstance(fr, dict):
            continue
        ftype = str(fr.get("type") or fr.get("kind") or "").strip().upper()
        txt = fr.get("content") or fr.get("text") or fr.get("value") or ""
        if isinstance(txt, (list, dict)):
            txt = _coerce_content(txt, None)
        txt = str(txt or "").strip()
        if not txt:
            continue
        if ftype in _FRAG_THINK:
            think.append(txt)
        elif ftype in _FRAG_REF:
            answer.append("> [联网检索] %s" % txt.replace("\n", " ")[:400])
        elif ftype in _FRAG_QUERY or ftype in _FRAG_ANSWER:
            answer.append(txt)
        else:
            # 未知类型：有内容就留下，不丢
            answer.append(txt)
    return "\n\n".join(answer).strip(), "\n\n".join(think).strip()


def parse_deepseek_share(payload: Dict[str, Any]) -> Tuple[str, str, List[Message], List[str]]:
    """DeepSeek 官方分享接口 /api/v0/share/content 的返回体。

    接口有两个版本的消息格式：
      * 旧版：message.content 直接是字符串
      * 新版：message.fragments = [{type, content}, ...]，用 type 区分
              提问 / 思维链 / 正式回答（**没有 content 字段**）
    两种都要支持，否则新接口会导出空文档。
    """
    notes: List[str] = []
    title, model = "", ""
    messages: List[Message] = []
    biz = (((payload or {}).get("data") or {}).get("biz_data") or {})
    if not biz:
        return title, model, messages, ["DeepSeek 返回体结构异常，未找到 biz_data。"]

    title = str(biz.get("title") or "").strip()
    model = str(biz.get("model_type") or biz.get("model") or "").strip()
    raw_msgs = biz.get("messages") or biz.get("chat_messages") or biz.get("message_list") or []

    used_fragments = False
    for m in raw_msgs:
        if not isinstance(m, dict):
            continue

        content = str(m.get("content") or "").strip()
        thinking = str(m.get("thinking_content") or m.get("reasoning_content") or "").strip()

        frags = m.get("fragments")
        if frags:
            used_fragments = True
            frag_text, frag_think = _split_fragments(frags)
            role = normalize_role(m.get("role"))
            # 提问的 fragment 就是正文；回答的 fragment 拆成正文+思维链
            if frag_text:
                content = frag_text if not content else (content + "\n\n" + frag_text)
            if frag_think:
                thinking = frag_think if not thinking else (thinking + "\n\n" + frag_think)

        msg = Message(
            role=normalize_role(m.get("role")),
            content=content,
            thinking=thinking,
            model=str(m.get("model") or model or ""),
            timestamp=str(m.get("inserted_at") or m.get("created_at") or ""),
        )
        if m.get("files"):
            try:
                msg.files = list(m["files"])
            except Exception:  # noqa: BLE001
                pass
        if not msg.is_empty:
            messages.append(msg)

    if used_fragments:
        notes.append("DeepSeek 使用了 fragments 格式，已按 REQUEST/THINK/RESPONSE 自动归类。")
    if not messages:
        notes.append("DeepSeek 接口返回成功但没有解析出消息。")
    return title, model, messages, notes


def _walk_chatgpt_mapping(mapping: Dict[str, Any]) -> List[Dict[str, Any]]:
    """ChatGPT 的分享数据是一棵树（mapping），按父子关系还原成线性顺序。"""
    if not isinstance(mapping, dict) or not mapping:
        return []
    # 找根节点
    roots = [k for k, v in mapping.items() if isinstance(v, dict) and not v.get("parent")]
    if not roots:
        child_ids = set()
        for v in mapping.values():
            if isinstance(v, dict):
                child_ids.update(v.get("children") or [])
        roots = [k for k in mapping.keys() if k not in child_ids] or list(mapping.keys())[:1]

    ordered: List[Dict[str, Any]] = []
    visited = set()
    stack = list(roots)
    while stack:
        nid = stack.pop(0)
        if nid in visited or nid not in mapping:
            continue
        visited.add(nid)
        node = mapping[nid]
        if not isinstance(node, dict):
            continue
        msg = node.get("message")
        if isinstance(msg, dict):
            ordered.append(msg)
        children = node.get("children") or []
        stack = list(children) + stack
    return ordered


def parse_chatgpt_payload(payload: Dict[str, Any]) -> Tuple[str, str, List[Message], List[str]]:
    """兼容 ChatGPT 分享接口/内嵌 JSON 的几种形态。"""
    notes: List[str] = []
    title, model = "", ""
    raw_msgs: List[Dict[str, Any]] = []

    # 形态 A：{mapping: {...}}
    mapping = payload.get("mapping") if isinstance(payload, dict) else None
    if isinstance(mapping, dict):
        raw_msgs = _walk_chatgpt_mapping(mapping)
    if not raw_msgs:
        for key in ("linear_conversation", "conversation", "messages", "chat_messages"):
            v = payload.get(key) if isinstance(payload, dict) else None
            if isinstance(v, list) and v:
                raw_msgs = [x for x in v if isinstance(x, dict)]
                break

    title = str(payload.get("title") or "").strip()
    model = str(payload.get("default_model_slug") or payload.get("model") or "").strip()

    messages: List[Message] = []
    for m in raw_msgs:
        author = m.get("author") or {}
        role = normalize_role(author.get("role") if isinstance(author, dict) else m.get("role"))
        if role in ("system", "tool"):
            continue
        meta = m.get("metadata") or {}
        content_obj = m.get("content") or {}
        thinking: List[str] = []
        text = _coerce_content(content_obj, thinking)
        msg = Message(
            role=role,
            content=text.strip(),
            thinking="\n\n".join(thinking).strip(),
            model=str(meta.get("model_slug") or model or ""),
            timestamp=str(m.get("create_time") or ""),
        )
        if not msg.is_empty:
            messages.append(msg)
    if not messages:
        notes.append("未能从 ChatGPT 数据中解析出消息。")
    return title, model, messages, notes


# --------------------------------------------------------------------------
# 豆包（doubao）
# --------------------------------------------------------------------------
# 豆包的分享数据藏在 <script data-script-src="modern-run-window-fn"
# data-fn-name="mergeLoaderData" data-fn-args="[...]"> 的**属性**里，
# 而不是 <script> 的正文里 —— 这也就是为什么按 <script> 扫的通用提取会一个
# blob 都找不到。属性值是 HTML 转义的 JSON，其字符串字段里**又套了一层
# 转义 JSON**，所以要连解两次。
#
# 关键结构：
#   data.message_snapshot.message_list[i] = {
#       message_id, user_type(1=用户,2=助手), create_time, index_in_conv,
#       thinking_content,
#       content: "[{\"block_type\":10000,\"content\":{\"text_block\":{\"text\":\"...markdown...\"}}}]"
#   }
# `text_block.text` 是**未经渲染的原始 Markdown**，`$...$` / `$$...$$` 都在，
# 这是拿公式的最优来源（比 DOM 里的 copy-text 还完整：copy-text 会把显示公式
# 也标准化成 \(...\)，丢掉"行内 / 独立"的区别）。

_DOUBAO_TEXT_BLOCK = 10000      # 正文文本块
_DOUBAO_THINK_BLOCK = 10040     # 思考块
_DOUBAO_USER_ROLE = {"1": "user", "2": "assistant", "3": "assistant"}


def _doubao_blocks(content: Any) -> Tuple[str, str]:
    """把豆包的 message.content 折成 (正文 Markdown, 思维链 Markdown)。

    content 通常是"JSON 字符串"，里面是 block 列表；但也可能是纯 Markdown 字符串。
    """
    blocks = content
    if isinstance(blocks, str):
        s = blocks.strip()
        if not s:
            return "", ""
        try:
            blocks = json.loads(s)
        except Exception:  # noqa: BLE001
            return s, ""          # 本来就是 Markdown
    if not isinstance(blocks, list):
        return "", ""

    body: List[str] = []
    think: List[str] = []
    for b in blocks:
        if not isinstance(b, dict):
            continue
        btype = b.get("block_type")
        cont = b.get("content")
        if not isinstance(cont, dict):
            continue
        tb = cont.get("text_block")
        if not isinstance(tb, dict):
            tb = {}
        t = tb.get("text")
        if not isinstance(t, str) or not t.strip():
            # 没正文的块（elapsed_block / 只有 summary 的思考块）跳过
            continue
        if btype == _DOUBAO_THINK_BLOCK:
            think.append(t.strip())
        else:
            body.append(t.strip())
    return "\n\n".join(body).strip(), "\n\n".join(think).strip()


def _find_message_list(payload: Any) -> List[Dict[str, Any]]:
    """在豆包返回体里定位消息数组（不依赖固定路径）。"""
    best: List[Any] = []
    for d in _iter_dicts(payload):
        v = d.get("message_list")
        if isinstance(v, list) and v and all(isinstance(x, dict) for x in v):
            if len(v) > len(best):
                best = list(v)
    if best:
        return best
    # 退化：任何"多条都带 message_id"的数组
    for arr in _iter_lists(payload):
        hits = [x for x in arr if isinstance(x, dict) and "message_id" in x]
        if len(hits) >= 2 and len(hits) > len(best):
            best = list(arr)
    return best


def parse_doubao_payload(payload: Dict[str, Any]) -> Tuple[str, str, List[Message], List[str]]:
    """豆包分享页内嵌数据 → 消息列表。"""
    notes: List[str] = []
    title, model = "", ""

    for d in _iter_dicts(payload):
        si = d.get("share_info")
        if isinstance(si, dict):
            nm = si.get("share_name") or si.get("title")
            if isinstance(nm, str) and nm.strip():
                title = nm.strip()
                break

    raw = _find_message_list(payload)
    if not raw:
        return title, model, [], ["豆包返回体里没有找到 message_list。"]

    ordered: List[Tuple[Any, Message]] = []
    for i, m in enumerate(raw):
        if not isinstance(m, dict):
            continue
        ut = m.get("user_type")
        if ut is None:
            ut = m.get("sender_type")
        role = _DOUBAO_USER_ROLE.get(str(ut)) or normalize_role(ut)

        body, think = _doubao_blocks(m.get("content"))
        tc = m.get("thinking_content")
        if isinstance(tc, str) and tc.strip():
            think = (tc.strip() + ("\n\n" + think if think else "")).strip()

        if not body.strip() and not think.strip():
            continue

        msg = Message(
            role=role,
            content=body.strip(),
            thinking=think.strip(),
            model=str(m.get("model") or model or ""),
            timestamp=str(m.get("create_time") or m.get("update_time") or ""),
        )
        # message_list 是**倒序**的（助手回答在前）；index_in_conv 才是真实顺序
        try:
            key = int(m.get("index_in_conv"))
        except Exception:  # noqa: BLE001
            key = None
        ordered.append(((0, key) if key is not None else (1, i), msg))

    ordered.sort(key=lambda x: x[0])
    messages = [m for _, m in ordered]

    if messages and not any(m.role == "user" for m in messages):
        notes.append("豆包消息里没有识别出用户提问，请核对。")
    if messages:
        notes.append("豆包数据取自页面内嵌 JSON，公式来自未渲染的 Markdown 源码。")
    return title, model, messages, notes


def parse_claude_payload(payload: Dict[str, Any]) -> Tuple[str, str, List[Message], List[str]]:
    """兼容 Claude 分享页内嵌数据。"""
    notes: List[str] = []
    title = str(payload.get("title") or payload.get("name") or "").strip()
    model = str(payload.get("model") or "").strip()
    raw = payload.get("chat_messages") or payload.get("messages") or []
    messages: List[Message] = []
    for m in raw:
        if not isinstance(m, dict):
            continue
        role = normalize_role(m.get("sender") or m.get("role"))
        if role in ("system", "tool"):
            continue
        thinking: List[str] = []
        text = _coerce_content(m.get("content") or m.get("text"), thinking)
        if m.get("attachments"):
            text = _prepend_files(text, m["attachments"])
        msg = Message(
            role=role,
            content=text.strip(),
            thinking="\n\n".join(thinking).strip(),
            model=model,
            timestamp=str(m.get("created_at") or ""),
        )
        if not msg.is_empty:
            messages.append(msg)
    if not messages:
        notes.append("未能从 Claude 数据中解析出消息。")
    return title, model, messages, notes


def _prepend_files(text: str, files: Any) -> str:
    try:
        names = []
        for f in files or []:
            if isinstance(f, dict):
                names.append(str(f.get("file_name") or f.get("name") or "附件"))
        if names:
            return "\n".join("> [附件] %s" % n for n in names) + "\n\n" + text
    except Exception:  # noqa: BLE001
        pass
    return text


# 平台 → 适配器
ADAPTERS = {
    "deepseek": parse_deepseek_share,
    "chatgpt": parse_chatgpt_payload,
    "claude": parse_claude_payload,
    "doubao": parse_doubao_payload,
}


# --------------------------------------------------------------------------
# 三、DOM 提取（浏览器渲染后的兜底）
# --------------------------------------------------------------------------

DOM_SELECTORS: Dict[str, List[str]] = {
    "chatgpt": [
        "[data-message-author-role]",
        "article[data-testid^='conversation-turn']",
        "div[data-testid^='conversation-turn']",
    ],
    "claude": [
        "div[data-testid='user-message']",
        "div.font-claude-message",
        "div[data-testid*='message']",
    ],
    "deepseek": [
        "[data-virtual-list-item-key]",
        "[class*='ds-message']",
        "[class*='message']",
    ],
    "kimi": [
        "[class*='segment-content']",
        "[class*='chat-item']",
        "[class*='virtual-list-item']",
        "[class*='message']",
    ],
    "doubao": [
        "[data-virtual-list-item-key]",
        "[class*='message-block']",
        "[class*='message']",
    ],
    "tongyi": [
        "[class*='questionItem']",
        "[class*='answerItem']",
        "[class*='virtual-list-item']",
        "[class*='message']",
    ],
    "yiyan": [
        "[class*='virtual-list-item']",
        "[class*='message']",
    ],
    "zhipu": [
        "[class*='virtual-list-item']",
        "[class*='message']",
    ],
    "generic": [],
}

_GENERIC_DOM_SELECTORS = [
    "[data-message-author-role]",
    "[data-role][data-message-id]",
    # 虚拟滚动列表：DeepSeek / 豆包 / 通义 这类长对话页面常用
    "[data-virtual-list-item-key]",
    "[class*='virtual-list-item']",
    "[class*='virtualListItem']",
    "[class*='message-item']",
    "[class*='messageItem']",
    "[class*='chat-item']",
    "[class*='chatItem']",
    "[class*='conversation-turn']",
    "[class*='turn-item']",
    "[class*='bubble']",
    "[class*='message-bubble']",
    "[data-testid*='message']",
]

_USER_HINTS = ("user", "human", "question", "ask", "query", "sender-user", "prompt", "me-", "-me")
_AI_HINTS = ("assistant", "answer", "response", "reply", "bot", "ai-", "-ai", "gpt", "claude",
             "deepseek", "model", "receive", "left")
_THINK_HINTS = ("think-content", "thinking", "reasoning", "cot-content", "chain-of-thought",
                "ds-think", "thought")


def _classify_class_string(cid: str) -> Optional[str]:
    if not cid.strip():
        return None
    for h in _USER_HINTS:
        if h in cid:
            return "user"
    for h in _AI_HINTS:
        if h in cid:
            return "assistant"
    return None


def _role_from_node(node: Tag) -> Optional[str]:
    # 1) 最强证据：显式属性
    for attr in ("data-message-author-role", "data-role", "data-sender", "data-author-role"):
        v = node.get(attr)
        if isinstance(v, str) and v.strip():
            return normalize_role(v)
    for anc in list(node.parents)[:3]:
        if not isinstance(anc, Tag):
            continue
        for attr in ("data-message-author-role", "data-role", "data-sender"):
            v = anc.get(attr)
            if isinstance(v, str) and v.strip():
                return normalize_role(v)

    # 2) 自身 class / id
    classes = node.get("class") or []
    if isinstance(classes, str):
        classes = classes.split()
    got = _classify_class_string((" ".join(classes) + " " + (node.get("id") or "")).lower())
    if got:
        return got

    # 3) 祖先 class（DeepSeek 这类把角色类挂在包装层上）
    for anc in list(node.parents)[:4]:
        if not isinstance(anc, Tag):
            continue
        cls = anc.get("class") or []
        if isinstance(cls, str):
            cls = cls.split()
        got = _classify_class_string((" ".join(cls) + " " + (anc.get("id") or "")).lower())
        if got:
            return got

    # 4) 子孙 class（例如助手消息里嵌了 .ds-assistant-message-main-content）
    for sel, role in (("[class*='assistant']", "assistant"), ("[class*='user']", "user"),
                      ("[class*='human']", "user"), ("[class*='answer']", "assistant")):
        try:
            if node.select_one(sel) is not None:
                return role
        except Exception:  # noqa: BLE001
            continue
    return None


def _pull_thinking(node: Tag) -> Tuple[str, str]:
    """把消息节点里的"思维链"区域单独摘出来。

    返回 (正文 HTML, 思维链 HTML)。摘不出来就返回 (原 HTML, "")。
    """
    sub = BeautifulSoup(str(node), "lxml")
    body = sub.body or sub
    th_nodes = []
    for hint in _THINK_HINTS:
        try:
            th_nodes.extend(body.select("[class*='%s']" % hint))
        except Exception:  # noqa: BLE001
            continue
    th_nodes = _top_level([n for n in th_nodes if isinstance(n, Tag)])
    if not th_nodes:
        return str(node), ""
    think_html = "\n".join(str(n) for n in th_nodes)
    for n in th_nodes:
        n.decompose()
    return str(body), think_html


def _top_level(nodes: List[Tag]) -> List[Tag]:
    """去掉嵌套在其它候选里的候选，只留最外层。"""
    nodeset = set(id(n) for n in nodes)
    out = []
    for n in nodes:
        if any(id(p) in nodeset for p in n.parents):
            continue
        out.append(n)
    return out


def _repeated_sibling_blocks(root: Tag, min_len: int = 30, max_items: int = 60) -> List[Tag]:
    """找不到已知选择器时的兜底：找一组"结构相似、都带正文"的兄弟节点。

    虚拟滚动列表、自研消息列表往往没有语义化 class，
    但它们在 DOM 上一定是同层并列的一串节点，这就是它们的共同特征。
    """
    best: List[Tag] = []
    parents = [root] + root.find_all(["div", "section", "article", "ul", "ol"], limit=600)
    for parent in parents:
        # 表格、正文列表里的 li 不是消息，跳过
        if parent.name in ("ul", "ol") and parent.find_parent("table") is None:
            continue
        kids = [c for c in parent.find_all(recursive=False) if isinstance(c, Tag)]
        if len(kids) < 2 or len(kids) > max_items:
            continue
        good = [k for k in kids if len(k.get_text(strip=True)) >= min_len]
        if len(good) < 2 or len(good) < len(kids) - 1:
            continue
        # 兄弟节点要有共同的结构特征（同名标签 + 有交集的首个 class）
        sigs = []
        for k in good:
            cls = k.get("class") or []
            sigs.append((k.name, cls[0] if cls else ""))
        common = set(s for s in sigs if sigs.count(s) >= 2)
        if not common and len(set(sigs)) > 2:
            continue
        if len(good) > len(best):
            best = good
    return best


def _collect_containers(scope: Tag, selectors: List[str], min_chars: int = 1) -> Tuple[List[Tag], str]:
    """按选择器逐个尝试，返回第一个能切出 >=2 个内容的候选集。"""
    for sel in selectors:
        try:
            hits = [n for n in scope.select(sel) if isinstance(n, Tag)]
        except Exception:  # noqa: BLE001
            continue
        hits = _top_level(hits)
        hits = [h for h in hits if len(h.get_text(strip=True)) >= min_chars]
        hits = [h for h in hits if not _is_chrome_node(h)]
        if len(hits) >= 2:
            return hits, sel
    return [], ""


# 页面上的提示条/免责声明/操作引导，长得像消息但不是消息
_CHROME_TEXT = re.compile(
    r"(由\s*AI\s*生成|内容由\s*AI|AI\s*生成，?请|来自分享|请仔细甄别|仅供参考|"
    r"登录后|登录以|复制链接|复制代码|已复制|重新生成|继续追问|检测到|"
    r"本回答由|回答由|Generated by AI|AI-generated|Sign in|Log in)"
)


# 思维链区域被摘走之后，正文顶部往往会残留一个"已思考（用时 1 秒）"之类的标签
_THINK_HEADER = re.compile(
    r"^\s*(?:已(?:深度)?思考|思考了?|正在思考|深度思考|展开|收起|"
    r"Thought for[^\n]*|Thinking|Reasoning|Show thinking)[^\n]{0,40}\n+",
)


def _strip_think_header(md: str) -> str:
    if not md:
        return md
    prev = None
    out = md.lstrip("\n")
    while out != prev:
        prev = out
        out = _THINK_HEADER.sub("", out, count=1)
    return out.strip()


def _is_chrome_node(node: Tag, max_len: int = 120) -> bool:
    """判断一个候选节点是不是页面的提示条而非对话内容。"""
    try:
        text = node.get_text(" ", strip=True)
    except Exception:  # noqa: BLE001
        return False
    if len(text) > max_len:
        return False
    if _CHROME_TEXT.search(text):
        return True
    return False


def extract_from_dom(html: str, platform_key: str = "generic", base_url: str = "") -> Tuple[str, List[Message], List[str]]:
    """从渲染后的 HTML 里按"消息气泡"切分出问答。

    搜索顺序（从准到糙）：
      1. 全页按已知选择器找消息容器
      2. 缩到"对话主容器"里再找一遍
      3. 找结构相似的重复兄弟块（自研渲染的通用特征）
      4. 都失败 → 整页正文当一条消息导出，并明确提示
    """
    notes: List[str] = []
    soup = BeautifulSoup(html, "lxml")

    selectors = list(DOM_SELECTORS.get(platform_key) or []) + _GENERIC_DOM_SELECTORS

    # 1) 全页找
    picked, used_selector = _collect_containers(soup, selectors)

    # 2) 缩到对话主容器里找
    if not picked:
        root = find_conversation_root(soup, platform_key)
        strip_chrome(root)
        picked, used_selector = _collect_containers(root, selectors)

    # 3) 重复兄弟块启发式（在整页范围找，因为它本来就是"猜结构"）
    if not picked:
        root = find_conversation_root(soup, platform_key)
        picked = _repeated_sibling_blocks(root) or _repeated_sibling_blocks(soup)
        if picked:
            used_selector = "重复兄弟块启发式"
            notes.append("没能识别出平台专属的消息容器，改用「结构相似兄弟块」推断，"
                         "建议核对导出结果是否完整。")

    if not picked:
        notes.append("网页里没有找到可切分的消息节点，已把整页正文作为单条内容导出。")
        md, _, _, md_notes = html_to_markdown(html, platform_key, base_url)
        notes.extend(md_notes)
        return md, [], notes

    conv = _AIExportConverter(
        heading_style="ATX", bullets="-", autolinks=False,
        escape_asterisks=False, escape_underscores=False, escape_misc=False,
    )

    messages: List[Message] = []
    unknown = 0
    for node in picked:
        role = _role_from_node(node)
        if role is None:
            unknown += 1
        # 把思维链区域先摘出去，剩下的才是正文
        content_html, think_html = _pull_thinking(node)

        def _to_md(fragment_html: str) -> str:
            if not fragment_html:
                return ""
            sub = BeautifulSoup(fragment_html, "lxml")
            table, _ = protect_math(sub)
            body = sub.body or sub
            strip_chrome(body)
            out = conv.convert_soup(body)
            out = restore_math(out, table)
            return _tidy_markdown(out)

        md = _to_md(content_html)
        think_md = _to_md(think_html)
        md = _strip_think_header(md)
        if not md.strip() and not think_md.strip():
            continue
        messages.append(Message(role=role or "assistant", content=md.strip(), thinking=think_md.strip()))

    if unknown and len(messages) > 1:
        # 角色未知的按前后交替补齐
        for i, m in enumerate(messages):
            pass
        if all(m.role == "assistant" for m in messages):
            for i, m in enumerate(messages):
                m.role = "user" if i % 2 == 0 else "assistant"
        notes.append("有 %d 条消息未能识别发言者，已按顺序推断（上一条为提问、下一条为回答）。" % unknown)

    if used_selector:
        notes.append("DOM 切分使用的选择器：%s" % used_selector)
    return "", messages, notes


# --------------------------------------------------------------------------
# 四、从内嵌 JSON 里挖
# --------------------------------------------------------------------------

def _parse_json_blobs(html: str) -> List[Any]:
    """把页面里可能藏对话的 JSON 全部抠出来。"""
    blobs: List[Any] = []
    soup = BeautifulSoup(html, "lxml")
    for sc in soup.find_all("script"):
        stype = (sc.get("type") or "").lower()
        sid = (sc.get("id") or "").lower()
        raw = sc.string or sc.get_text() or ""
        if not raw or len(raw) < 100:
            continue
        if stype in ("application/json", "application/ld+json") or sid in (
            "__next_data__", "__remixcontext", "__nuxt_data__", "server-app-state",
        ) or "self.__next_f" in raw or "__NEXT_DATA__" in raw or "window.__" in raw:
            txt = raw.strip()
            # Next.js 的 self.__next_f.push([1,"...json..."]) 形态
            if "self.__next_f" in txt:
                for m in re.finditer(r'self\.__next_f\.push\(\[1,\s*("(?:[^"\\]|\\.)*")\s*\]\)', txt):
                    try:
                        frag = json.loads(m.group(1))
                        blobs.extend(_deep_json_scan(frag))
                    except Exception:  # noqa: BLE001
                        continue
                continue
            try:
                blobs.append(json.loads(txt))
            except Exception:  # noqa: BLE001
                # 可能是 JS 赋值语句，抠出第一个 JSON 对象
                m = re.search(r"(\{.*\})\s*;?\s*$", txt, re.S)
                if m:
                    try:
                        blobs.append(json.loads(m.group(1)))
                    except Exception:  # noqa: BLE001
                        pass

    # 标签属性里的 JSON。
    # 字节系站点（豆包）把整份对话塞在
    # `<script data-fn-name="mergeLoaderData" data-fn-args="[...]">` 的**属性**上，
    # script 正文里什么都没有 —— 只扫 script 正文会一个 blob 都拿不到。
    blobs.extend(_blobs_from_attributes(soup))

    # 把"字符串里还套着 JSON"的字段展开（豆包是两层转义）
    return [_expand_json_strings(b) for b in blobs]


# 只对"够长、首尾是 JSON 括号"的字符串做再解析，
# 避免把回答里的短 JSON 代码片段（{"a": 1}）误当结构数据展开。
_JSON_STR_MIN = 200


def _expand_json_strings(obj: Any, depth: int = 8) -> Any:
    """有界递归：把值本身是 JSON 文本的字符串字段展开成对象。

    平台把数据打包成"JSON 里放 JSON 字符串"很常见（豆包套了两层）。
    只在字符串够长、且首尾就是 [ ] / { } 时才尝试，且长度上限兜底。
    """
    if depth <= 0:
        return obj
    if isinstance(obj, dict):
        return {k: _expand_json_strings(v, depth - 1) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_expand_json_strings(v, depth - 1) for v in obj]
    if isinstance(obj, str):
        s = obj.strip()
        if len(s) < _JSON_STR_MIN or len(s) > 4_000_000:
            return obj
        if s[0] not in "[{" or s[-1] not in "]}":
            return obj
        try:
            sub = json.loads(s)
        except Exception:  # noqa: BLE001
            return obj
        if isinstance(sub, (dict, list)):
            return _expand_json_strings(sub, depth - 1)
        return obj
    return obj


def _blobs_from_attributes(soup: BeautifulSoup) -> List[Any]:
    """扫所有标签属性，把里面像 JSON 的值解析出来。

    属性值通常是 HTML 转义过的（`&quot;` → `"`），要先反转义。
    """
    out: List[Any] = []
    try:
        for tag in soup.find_all(True):
            attrs = getattr(tag, "attrs", None)
            if not attrs:
                continue
            for _name, val in attrs.items():
                if not isinstance(val, str) or len(val) < 200:
                    continue
                s = _htmlescape.unescape(val).strip()
                if not s or s[0] not in "[{":
                    continue
                try:
                    out.append(json.loads(s))
                except Exception:  # noqa: BLE001
                    continue
    except Exception:  # noqa: BLE001
        pass
    return out


def _deep_json_scan(frag: str) -> List[Any]:
    """从一段可能是 JSON 也可能夹着 JSON 的字符串里挖出 JSON 对象。"""
    gets: List[Any] = []
    frag = frag.strip()
    if not frag:
        return gets
    try:
        gets.append(json.loads(frag))
        return gets
    except Exception:  # noqa: BLE001
        pass
    # 逐个找平衡的 {...}
    depth = 0
    start = -1
    in_str = False
    esc = False
    for i, ch in enumerate(frag):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start >= 0:
                try:
                    gets.append(json.loads(frag[start:i + 1]))
                except Exception:  # noqa: BLE001
                    pass
                start = -1
    return gets


def extract_from_embedded_json(html: str, platform_key: str) -> Tuple[str, str, List[Message], List[str]]:
    """尝试从页面内嵌 JSON 里直接还原对话。"""
    notes: List[str] = []
    blobs = _parse_json_blobs(html)

    # 先试平台专属适配器
    adapter = ADAPTERS.get(platform_key)
    if adapter:
        for b in blobs:
            # 适配器通常要的是某层嵌套对象，这里把它可能关心的子树都喂一遍
            cands = [b]
            for d in _iter_dicts(b):
                for key in ("props", "pageProps", "conversation", "data", "biz_data", "serverResponse", "initialState"):
                    if key in d and isinstance(d[key], (dict, list)):
                        cands.append(d[key])
            for c in cands[:400]:
                if not isinstance(c, dict):
                    continue
                try:
                    title, model, msgs, ad_notes = adapter(c)
                except Exception:  # noqa: BLE001
                    continue
                if msgs:
                    notes.extend(ad_notes)
                    return title, model, msgs, notes

    # 通用扫描
    for b in blobs:
        msgs, gen_notes = extract_from_json(b)
        if msgs:
            title = ""
            for d in _iter_dicts(b):
                for k in ("title", "name", "subject"):
                    if isinstance(d.get(k), str) and d[k].strip() and len(d[k]) < 200:
                        title = d[k].strip()
                        break
                if title:
                    break
            notes.extend(gen_notes)
            return title, "", msgs, notes
    return "", "", [], notes


def extract_from_html(html: str, platform_key: str, base_url: str = "") -> Tuple[str, str, List[Message], List[str], str]:
    """网页抓取的总入口。

    先试内嵌 JSON（最准），失败再走 DOM 切分（最兜底）。
    返回 (title, model, messages, notes, 采用的通路名)。
    """
    title, model, msgs, notes = extract_from_embedded_json(html, platform_key)
    if msgs:
        return title, model, msgs, notes, "embedded-json"

    md, dom_msgs, dom_notes = extract_from_dom(html, platform_key, base_url)
    notes.extend(dom_notes)
    if dom_msgs:
        return "", "", dom_msgs, notes, "dom"
    if md.strip():
        return "", "", [Message(role="assistant", content=md)], notes, "dom-fulltext"
    return "", "", [], notes + ["页面里没有提取到任何对话内容。"], "none"
