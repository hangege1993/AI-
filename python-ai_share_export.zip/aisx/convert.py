# -*- coding: utf-8 -*-
"""对外总入口：一个链接进去，一堆文档出来。

    from aisx import convert_url
    r = convert_url("https://chat.deepseek.com/share/xxxx", out_dir="D:/导出")

也支持一次给多个链接、一段带链接的分享文案。
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence

from . import exporters as ex
from . import fetch as fetcher
from . import platforms as pf
from .models import Conversation

Progress = Optional[Callable[[str], None]]


@dataclass
class Result:
    url: str
    ok: bool = False
    files: List[str] = field(default_factory=list)
    conv: Optional[Conversation] = None
    error: str = ""
    stats: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def title(self) -> str:
        return (self.conv.title if self.conv else "") or "(未命名)"

    def summary(self) -> str:
        if not self.ok:
            return "失败：%s" % self.error
        bits = ["%d 条消息" % len(self.conv.messages)] if self.conv else []
        m_ok = sum(s.get("math_rendered", 0) for s in self.stats)
        m_bad = sum(s.get("math_failed", 0) for s in self.stats)
        if m_ok:
            bits.append("公式 %d 处已转为可编辑对象" % m_ok)
        if m_bad:
            bits.append("%d 处公式降级为文本" % m_bad)
        return "，".join(bits) if bits else "完成"


def convert_url(
    url: str,
    out_dir: str = ".",
    formats: Sequence[str] = ("docx",),
    *,
    filename: Optional[str] = None,
    allow_render: bool = True,
    headless: bool = True,
    wait_ms: int = 6000,
    timeout: int = 30,
    options: Optional[Dict[str, Any]] = None,
    progress: Progress = None,
    conv: Optional[Conversation] = None,
) -> Result:
    """抓取单个链接并导出。"""
    url = (url or "").strip()
    res = Result(url=url)
    if not url:
        res.error = "链接为空"
        return res

    def say(msg: str) -> None:
        if progress:
            try:
                progress(msg)
            except Exception:  # noqa: BLE001
                pass

    try:
        if conv is None:
            conv = fetcher.fetch_conversation(
                url,
                allow_render=allow_render,
                headless=headless,
                wait_ms=wait_ms,
                timeout=timeout,
                progress=progress,
            )
    except fetcher.FetchError as e:
        res.error = str(e)
        return res
    except Exception as e:  # noqa: BLE001
        res.error = "%s: %s" % (type(e).__name__, str(e)[:300])
        return res

    res.conv = conv
    if not conv.messages:
        res.error = "没有抓到任何对话内容。" + ("（%s）" % "；".join(conv.notes[:2]) if conv.notes else "")
        return res

    base = filename or build_filename(conv)
    os.makedirs(out_dir, exist_ok=True)

    for fmt in formats:
        f = ex.normalize_format(fmt)
        if f not in ex.SUPPORTED_FORMATS:
            res.stats.append({"path": "", "error": "不支持的格式：%s" % fmt})
            continue
        path = _unique_path(os.path.join(out_dir, base + ex.FORMAT_EXT[f]))
        say("正在生成 %s …" % f.upper())
        try:
            st = ex.write_format(conv, f, path, options)
            st["format"] = f
            res.stats.append(st)
            res.files.append(path)
        except Exception as e:  # noqa: BLE001
            res.stats.append({"format": f, "path": path,
                              "error": "%s: %s" % (type(e).__name__, str(e)[:200])})

    res.ok = bool(res.files)
    if not res.ok and not res.error:
        res.error = "所有格式都写盘失败了。"
    return res


def convert_many(
    urls: Sequence[str],
    out_dir: str = ".",
    formats: Sequence[str] = ("docx",),
    *,
    progress: Progress = None,
    on_result: Optional[Callable[[Result], None]] = None,
    **kw: Any,
) -> List[Result]:
    """批量转换。单个链接失败不影响其它。"""
    results: List[Result] = []
    total = len(urls)
    for i, u in enumerate(urls, 1):
        pre = "[%d/%d] " % (i, total) if total > 1 else ""
        if progress:
            try:
                progress("%s开始处理 %s" % (pre, u))
            except Exception:  # noqa: BLE001
                pass
        r = convert_url(u, out_dir, formats, progress=progress, **kw)
        results.append(r)
        if on_result:
            try:
                on_result(r)
            except Exception:  # noqa: BLE001
                pass
    return results


# --------------------------------------------------------------------------
# 文件名
# --------------------------------------------------------------------------

def build_filename(conv: Conversation, with_date: bool = True) -> str:
    """标题 + 平台 + 日期，方便日后在文件夹里认出来。"""
    title = ex.safe_filename(conv.title, max_len=60)
    plat = conv.platform_name or ""
    bits = [title]
    if plat and plat not in title:
        bits.append(plat)
    if with_date:
        d = (conv.fetched_at or datetime.now().strftime("%Y-%m-%d"))[:10]
        bits.append(d)
    return ex.safe_filename("_".join(bits), max_len=110)


def _unique_path(path: str) -> str:
    """同名文件不覆盖，自动加序号。"""
    if not os.path.exists(path):
        return path
    root, ext = os.path.splitext(path)
    for i in range(2, 1000):
        cand = "%s(%d)%s" % (root, i, ext)
        if not os.path.exists(cand):
            return cand
    return "%s(%s)%s" % (root, datetime.now().strftime("%H%M%S"), ext)


# --------------------------------------------------------------------------
# 从文本里挖链接
# --------------------------------------------------------------------------

def urls_from_text(text: str) -> List[str]:
    """从用户粘贴的一大段内容里把链接挑出来。"""
    return pf.extract_urls(text)
