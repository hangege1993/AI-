# -*- coding: utf-8 -*-
"""统一数据模型：把各家 AI 平台的分享链接归一成 Conversation / Message。

设计要点
--------
不管上游拿到的是官方 JSON 接口、页面内嵌 JSON，还是渲染后的 DOM，
最终都收敛到本模块定义的两个结构，后续的 Markdown 化、DOCX 导出只认这一层。
这样新增平台时只需要写"怎么拿到原始数据"，不用碰导出管线。
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


# 角色归一化表：不同平台用的字符串五花八门，这里一次性收口。
ROLE_MAP = {
    "user": "user",
    "human": "user",
    "human_turn": "user",
    "user_turn": "user",
    "prompt": "user",
    "me": "user",
    "USER": "user",
    "assistant": "assistant",
    "ai": "assistant",
    "bot": "assistant",
    "gpt": "assistant",
    "model": "assistant",
    "claude": "assistant",
    "answer": "assistant",
    "completion": "assistant",
    "ASSISTANT": "assistant",
    "system": "system",
    "SYSTEM": "system",
    "tool": "tool",
    "function": "tool",
    "search": "tool",
}

ROLE_ZH = {
    "user": "用户",
    "assistant": "AI",
    "system": "系统",
    "tool": "工具",
}


def normalize_role(raw: Any) -> str:
    """把平台自定义的角色字符串映射成 user / assistant / system / tool。"""
    if raw is None:
        return "assistant"
    s = str(raw).strip()
    if s in ROLE_MAP:
        return ROLE_MAP[s]
    low = s.lower()
    if low in ROLE_MAP:
        return ROLE_MAP[low]
    # 兜底：含有关键词就猜一下
    if "user" in low or "human" in low:
        return "user"
    if "system" in low:
        return "system"
    if "tool" in low or "function" in low:
        return "tool"
    return "assistant"


def _fmt_ts(value: Any) -> str:
    """把秒 / 毫秒时间戳、ISO 串统一成可读的本地时间字符串。"""
    if value in (None, "", 0):
        return ""
    try:
        if isinstance(value, (int, float)) or (
            isinstance(value, str) and re.fullmatch(r"\d{9,16}(\.\d+)?", value.strip())
        ):
            num = float(value)
            if num > 1e11:  # 毫秒
                num /= 1000.0
            return datetime.fromtimestamp(num).strftime("%Y-%m-%d %H:%M:%S")
        if isinstance(value, str):
            txt = value.strip().replace("Z", "+00:00")
            dt = datetime.fromisoformat(txt)
            if dt.tzinfo is not None:
                dt = dt.astimezone()
            return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return ""
    return ""


@dataclass
class Message:
    """一条对话消息。content 统一为 Markdown（公式保持 LaTeX 原文）。"""

    role: str = "assistant"
    content: str = ""
    thinking: str = ""          # 思维链 / 推理过程，单独存，导出时可选择是否包含
    model: str = ""
    timestamp: str = ""
    files: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def role_zh(self) -> str:
        return ROLE_ZH.get(self.role, self.role)

    @property
    def is_empty(self) -> bool:
        return not (self.content or "").strip() and not (self.thinking or "").strip()


@dataclass
class Conversation:
    """一次完整的分享对话。"""

    title: str = "AI 对话记录"
    url: str = ""
    platform: str = ""          # 平台标识，如 deepseek / chatgpt / claude
    platform_name: str = ""     # 平台中文名，用于封面
    model: str = ""             # 模型名（可能为空）
    created: str = ""           # 对话创建时间（可能为空）
    fetched_at: str = ""        # 抓取时间
    messages: List[Message] = field(default_factory=list)
    source: str = ""            # 数据来自哪条通路：api / embedded-json / dom / playwright
    notes: List[str] = field(default_factory=list)  # 抓取过程中的提示，写进文档尾注

    # ---- 便捷统计 ----
    @property
    def n_user(self) -> int:
        return sum(1 for m in self.messages if m.role == "user")

    @property
    def n_assistant(self) -> int:
        return sum(1 for m in self.messages if m.role == "assistant")

    def clean(self) -> "Conversation":
        """去掉空消息、去掉相邻重复消息，并补上抓取时间。"""
        out: List[Message] = []
        seen = set()
        for m in self.messages:
            if m.is_empty:
                continue
            key = (m.role, m.content.strip()[:400])
            if key in seen:
                continue
            seen.add(key)
            # 相邻两条同角色同内容（有的平台 DOM 里会有隐藏的重复节点）
            if out and out[-1].role == m.role and out[-1].content.strip() == m.content.strip():
                continue
            out.append(m)
        self.messages = out
        if not self.fetched_at:
            self.fetched_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if not self.title or self.title.strip() in ("Shared Conversation", "分享的对话", "Untitled"):
            # 用第一条用户提问兜底生成标题
            for m in out:
                if m.role == "user" and m.content.strip():
                    head = re.sub(r"\s+", " ", m.content.strip())[:40]
                    self.title = head + ("…" if len(m.content.strip()) > 40 else "")
                    break
        return self

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["stats"] = {"user": self.n_user, "assistant": self.n_assistant, "total": len(self.messages)}
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)
