# -*- coding: utf-8 -*-
"""IR → Word (.docx)。

关键点：
* **公式**用 OMML 原生对象塞进段落，Word/WPS 里可以双击继续编辑，
  不是图片、不是文本，不存在"乱码"。
* **代码块**用等宽字体 + 底纹 + 细边框，保留缩进与换行。
* **列表**自己画符号和层级缩进，不依赖 Word 的自动编号
  （自动编号在 python-docx 里会全文档共用计数器，序号会串）。
* **中文字体**显式设置 `w:eastAsia`，否则中英文混排会掉字形。
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from .models import Conversation, Message

# ---- 外观常量（想换风格改这里就够了）----
EA_FONT = "微软雅黑"          # 中文正文
LATIN_FONT = "Calibri"        # 西文正文
CODE_FONT = "Consolas"        # 代码
EA_CODE_FONT = "微软雅黑"

CLR_TEXT = RGBColor(0x22, 0x22, 0x22)
CLR_MUTED = RGBColor(0x7A, 0x7A, 0x7A)
CLR_USER = RGBColor(0x0F, 0x4C, 0x81)      # 用户：深蓝
CLR_AI = RGBColor(0x0B, 0x66, 0x4B)        # AI：深绿
CLR_CODE = RGBColor(0x24, 0x29, 0x2E)
CLR_LINK = RGBColor(0x05, 0x63, 0xC1)
CLR_QUOTE = RGBColor(0x55, 0x5B, 0x66)

SHADE_USER = "EAF1F9"
SHADE_AI = "EDF7F1"
SHADE_CODE = "F5F7F9"
SHADE_INLINE_CODE = "F0F2F4"
SHADE_META = "F7F7F7"

BODY_SIZE = Pt(10.5)
CODE_SIZE = Pt(9)
META_SIZE = Pt(9)


# --------------------------------------------------------------------------
# 低层工具
# --------------------------------------------------------------------------

def _style(doc: Document, name: str) -> Optional[Any]:
    try:
        return doc.styles[name]
    except Exception:  # noqa: BLE001
        return None


def set_run_font(run, *, latin: str = LATIN_FONT, ea: str = EA_FONT,
                 size: Optional[Pt] = None, bold: Optional[bool] = None,
                 italic: Optional[bool] = None, color: Optional[RGBColor] = None) -> None:
    """设置字体，含中文字体。"""
    run.font.name = latin
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    rfonts.set(qn("w:ascii"), latin)
    rfonts.set(qn("w:hAnsi"), latin)
    rfonts.set(qn("w:eastAsia"), ea)
    rfonts.set(qn("w:cs"), latin)
    if size is not None:
        run.font.size = size
    if bold is not None:
        run.font.bold = bold
    if italic is not None:
        run.font.italic = italic
    if color is not None:
        run.font.color.rgb = color


def shade(element, fill: str) -> None:
    """给段落或 run 加底纹。element 是 <w:p> 或 <w:pPr>/<w:rPr> 的容器。"""
    if element.tag.endswith("}p"):
        pr = element.get_or_add_pPr()
    elif element.tag.endswith("}r"):
        pr = element.get_or_add_rPr()
    else:
        pr = element
    old = pr.find(qn("w:shd"))
    if old is not None:
        pr.remove(old)
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    pr.append(shd)


def para_border(p, *, left: Optional[Dict[str, str]] = None,
                bottom: Optional[Dict[str, str]] = None,
                box: Optional[Dict[str, str]] = None) -> None:
    """给段落加边框。颜色是 6 位十六进制（不带 #）。"""
    pPr = p._p.get_or_add_pPr()
    old = pPr.find(qn("w:pBdr"))
    if old is not None:
        pPr.remove(old)
    bdr = OxmlElement("w:pBdr")

    def mk(tag: str, spec: Dict[str, str]):
        el = OxmlElement("w:" + tag)
        el.set(qn("w:val"), spec.get("val", "single"))
        el.set(qn("w:sz"), spec.get("sz", "6"))
        el.set(qn("w:space"), spec.get("space", "4"))
        el.set(qn("w:color"), spec.get("color", "BBBBBB"))
        return el

    if box:
        for tag in ("top", "left", "bottom", "right"):
            bdr.append(mk(tag, box))
    if left:
        bdr.append(mk("left", left))
    if bottom:
        bdr.append(mk("bottom", bottom))
    pPr.append(bdr)


def para_spacing(p, *, before: int = 0, after: int = 0, line: Optional[float] = None,
                 indent_left: Optional[float] = None, first_line: Optional[float] = None) -> None:
    pf = p.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    if line is not None:
        pf.line_spacing = line
        pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    if indent_left is not None:
        pf.left_indent = Cm(indent_left)
    if first_line is not None:
        pf.first_line_indent = Cm(first_line)


def add_hyperlink(paragraph, url: str, text: str, color: RGBColor = CLR_LINK,
                  underline: bool = True) -> Any:
    """插入真正的超链接（python-docx 没有直接 API，这里用关系 ID 实现）。"""
    try:
        part = paragraph.part
        r_id = part.relate_to(
            url,
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
            is_external=True,
        )
        hyperlink = OxmlElement("w:hyperlink")
        hyperlink.set(qn("r:id"), r_id)
        new_run = OxmlElement("w:r")
        rPr = OxmlElement("w:rPr")
        c = OxmlElement("w:color")
        c.set(qn("w:val"), "%02X%02X%02X" % (color[0], color[1], color[2]))
        rPr.append(c)
        if underline:
            u = OxmlElement("w:u")
            u.set(qn("w:val"), "single")
            rPr.append(u)
        rf = OxmlElement("w:rFonts")
        rf.set(qn("w:ascii"), LATIN_FONT)
        rf.set(qn("w:hAnsi"), LATIN_FONT)
        rf.set(qn("w:eastAsia"), EA_FONT)
        rPr.append(rf)
        new_run.append(rPr)
        t = OxmlElement("w:t")
        t.set(qn("xml:space"), "preserve")
        t.text = text
        new_run.append(t)
        hyperlink.append(new_run)
        paragraph._p.append(hyperlink)
        return hyperlink
    except Exception:  # noqa: BLE001
        r = paragraph.add_run(text)
        set_run_font(r, color=color, size=BODY_SIZE)
        return r


def add_bookmark(paragraph, name: str, bm_id: int) -> None:
    """在段落首尾插入书签（章节目录的跳转锚点）。

    参考程序（pandoc 系）会在每个标题处放置书签，使文档具备可跳转的
    章节锚点；这里复刻同样的组织方式。书签名须以字母开头且仅含字母/数字/下划线。
    """
    try:
        p = paragraph._p
        b_start = OxmlElement("w:bookmarkStart")
        b_start.set(qn("w:name"), name)
        b_start.set(qn("w:id"), str(bm_id))
        b_end = OxmlElement("w:bookmarkEnd")
        b_end.set(qn("w:id"), str(bm_id))
        p_pr = p.find(qn("w:pPr"))
        if p_pr is not None:
            p_pr.addnext(b_start)        # 必须紧随 pPr 之后
        else:
            p.insert(0, b_start)
        p.append(b_end)                  # 段落末尾闭合
    except Exception:  # noqa: BLE001
        pass


def add_internal_link(paragraph, anchor: str, text: str,
                      color=CLR_LINK, size=BODY_SIZE, bold: bool = False) -> Any:
    """插入指向文档内书签的内部超链接（章节目录条目，点击即跳转）。

    与 add_hyperlink（外部 URL）不同：内部链接用 w:anchor 引用书签，
    无需建立 relationship，离线文档也能正常跳转。
    """
    try:
        hyperlink = OxmlElement("w:hyperlink")
        hyperlink.set(qn("w:anchor"), anchor)
        new_run = OxmlElement("w:r")
        r_pr = OxmlElement("w:rPr")
        c = OxmlElement("w:color")
        c.set(qn("w:val"), "%02X%02X%02X" % (int(color[0]), int(color[1]), int(color[2])))
        r_pr.append(c)
        u = OxmlElement("w:u")
        u.set(qn("w:val"), "single")
        r_pr.append(u)
        if bold:
            r_pr.append(OxmlElement("w:b"))
        rf = OxmlElement("w:rFonts")
        rf.set(qn("w:ascii"), LATIN_FONT)
        rf.set(qn("w:hAnsi"), LATIN_FONT)
        rf.set(qn("w:eastAsia"), EA_FONT)
        r_pr.append(rf)
        new_run.append(r_pr)
        t = OxmlElement("w:t")
        t.set(qn("xml:space"), "preserve")
        t.text = text
        new_run.append(t)
        hyperlink.append(new_run)
        paragraph._p.append(hyperlink)
        return hyperlink
    except Exception:  # noqa: BLE001
        r = paragraph.add_run(text)
        set_run_font(r, color=color, size=size)
        return r


def add_page_number_footer(section) -> None:
    """页脚居中页码。"""
    try:
        footer = section.footer
        p = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.text = ""
        run = p.add_run()
        set_run_font(run, size=Pt(8), color=CLR_MUTED)
        fld_begin = OxmlElement("w:fldChar")
        fld_begin.set(qn("w:fldCharType"), "begin")
        instr = OxmlElement("w:instrText")
        instr.set(qn("xml:space"), "preserve")
        instr.text = "PAGE"
        fld_end = OxmlElement("w:fldChar")
        fld_end.set(qn("w:fldCharType"), "end")
        run._r.append(fld_begin)
        run._r.append(instr)
        run._r.append(fld_end)
    except Exception:  # noqa: BLE001
        pass


# --------------------------------------------------------------------------
# 导出器
# --------------------------------------------------------------------------

class DocxBuilder:
    """把 Conversation 渲染成 docx。"""

    def __init__(self, conv: Conversation, options: Optional[Dict[str, Any]] = None) -> None:
        self.conv = conv
        self.opt = {
            "include_thinking": False,   # 是否导出思维链
            "include_meta": True,        # 是否导出头部元信息
            "show_role_label": True,     # 是否显示"用户/AI"标签条（文档模式用）
            "page_numbers": True,
            "title": "",
            "notes_max": 6,
            # 大纲 / 导航组织
            "outline_mode": "auto",      # "auto"|"dialogue"|"document"
                                        #   dialogue：每条消息=一级节点（我：/豆包：），内部标题抬到 2 级，
                                        #             折叠后导航窗格顶层只显示各消息，靠 Word 导航窗格收缩
                                        #   document：按普通文档，把每条消息最浅标题归一为 1 级
            "user_label": "我",          # 对话模式用户节点前缀
            "assistant_label": "",       # 空=用平台名（豆包/Kimi/…）；对话模式助手节点只放标签
            "toc": False,                # 是否在"正文前"插入可见目录页（默认关：用导航窗格即可收缩）
            "toc_depth": 3,              # 可见目录页包含的层级
            # 兼容旧键：group_by_turn=True 等价于 outline_mode="dialogue"
            "group_by_turn": False,
        }
        if options:
            self.opt.update(options)
        self.doc = Document()
        self.notes_extra: List[str] = []
        self._math_ok = 0
        self._math_failed = 0
        # 章节目录相关状态
        self._toc: List[Dict[str, Any]] = []
        self._toc_i = 0
        self._bm_counter = 0
        self._bm_id = 0
        self._setup()

    # ---- 基础设置 ----
    def _setup(self) -> None:
        doc = self.doc
        sec = doc.sections[0]
        sec.top_margin = Cm(2.2)
        sec.bottom_margin = Cm(2.2)
        sec.left_margin = Cm(2.4)
        sec.right_margin = Cm(2.4)

        normal = _style(doc, "Normal")
        if normal is not None:
            normal.font.name = LATIN_FONT
            normal.font.size = BODY_SIZE
            rpr = normal.element.get_or_add_rPr()
            rf = rpr.find(qn("w:rFonts"))
            if rf is None:
                rf = OxmlElement("w:rFonts")
                rpr.append(rf)
            rf.set(qn("w:ascii"), LATIN_FONT)
            rf.set(qn("w:hAnsi"), LATIN_FONT)
            rf.set(qn("w:eastAsia"), EA_FONT)

        # 标题样式配中文字体（覆盖到 9 级，章节目录归一化后可能用到深层标题）
        for i in range(1, 10):
            st = _style(doc, "Heading %d" % i)
            if st is None:
                continue
            rpr = st.element.get_or_add_rPr()
            rf = rpr.find(qn("w:rFonts"))
            if rf is None:
                rf = OxmlElement("w:rFonts")
                rpr.append(rf)
            rf.set(qn("w:ascii"), LATIN_FONT)
            rf.set(qn("w:hAnsi"), LATIN_FONT)
            rf.set(qn("w:eastAsia"), EA_FONT)
            st.font.color.rgb = RGBColor(0x1A, 0x1A, 0x1A)
            st.font.bold = True

        if self.opt["page_numbers"]:
            add_page_number_footer(sec)

    # ---- 大纲 / 对话树助手 ----
    def _outline_mode(self) -> str:
        om = self.opt.get("outline_mode")
        if om in ("dialogue", "document"):
            return om
        if self.opt.get("group_by_turn"):
            return "dialogue"
        # auto：>=2 条用户消息按"对话树"组织，否则按普通文档
        return "dialogue" if self.conv.n_user >= 2 else "document"

    def _labels(self):
        user = self.opt.get("user_label") or "我"
        asst = self.opt.get("assistant_label")
        if not asst:
            asst = (self.conv.platform_name or self.conv.platform or "AI")
        return user, asst

    def _message_parts(self, m: Message):
        """对话模式：把一条消息拆成 (节点首行, 正文块列表)。

        * 用户消息：取首个段落的首行作为"我：<首行>"节点文本；该行从正文中移除，
          其余内容（含其它段、内部标题）作为正文，避免重复。
        * 助手消息：节点只放标签（豆包：），全文作为正文展开。
        返回的"正文块"与 _prescan 内部标题归一化共用，保证一一对应。
        """
        blocks = _get_blocks(m.content)
        if m.role == "user":
            if not blocks:
                return "", []
            b0 = blocks[0]
            if b0.get("t") == "para":
                ft = _flatten_text(b0.get("inlines", [])).strip()
                if ft:
                    lines = ft.split("\n")
                    head = lines[0].strip()
                    if len(lines) > 1:
                        rest = "\n".join(lines[1:]).strip()
                        rest_block = {"t": "para",
                                     "inlines": [{"t": "text", "text": rest}]}
                        return head, [rest_block] + blocks[1:]
                    return head, blocks[1:]
                # 首段为空
                return "", blocks[1:]
            # 首个块不是段落（如标题/代码）：节点无首行，整体作为正文
            return "", blocks
        # 助手 / 系统：节点只放标签，正文=全部块
        return "", blocks

    # ---- 段落小工厂 ----
    def _p(self, *, style: Optional[str] = None, align=None,
           before: int = 0, after: int = 4, line: float = 1.32,
           indent_left: Optional[float] = None):
        p = self.doc.add_paragraph()
        if style:
            st = _style(self.doc, style)
            if st is not None:
                p.style = st
        if align is not None:
            p.alignment = align
        para_spacing(p, before=before, after=after, line=line, indent_left=indent_left)
        return p

    def _run(self, p, text: str, **kw):
        r = p.add_run(text)
        opts = {"size": BODY_SIZE, "color": CLR_TEXT}
        opts.update(kw)
        set_run_font(r, **opts)
        return r

    # ---- 头部 ----
    def build_header(self) -> None:
        conv = self.conv
        title = self.opt.get("title") or conv.title or "AI 对话记录"
        p = self._p(align=WD_ALIGN_PARAGRAPH.LEFT, before=0, after=2, line=1.15)
        self._run(p, title, size=Pt(19), bold=True, color=RGBColor(0x11, 0x11, 0x11))

        line = self._p(before=0, after=10, line=1.0)
        para_border(line, bottom={"sz": "10", "color": "C9CDD4", "space": "6"})
        self._run(line, "")

        if not self.opt["include_meta"]:
            return

        meta_pairs = [
            ("来源平台", conv.platform_name or conv.platform or "未识别"),
            ("模型", conv.model or "—"),
            ("消息数", "共 %d 条（提问 %d / 回答 %d）" % (len(conv.messages), conv.n_user, conv.n_assistant)),
            ("抓取时间", conv.fetched_at or "—"),
        ]
        if conv.created:
            meta_pairs.insert(3, ("对话时间", conv.created))

        tbl = self.doc.add_table(rows=0, cols=2)
        tbl.alignment = WD_TABLE_ALIGNMENT.LEFT
        for k, v in meta_pairs:
            row = tbl.add_row().cells
            pk = row[0].paragraphs[0]
            para_spacing(pk, before=1, after=1, line=1.1)
            self._run(pk, k, size=META_SIZE, bold=True, color=CLR_MUTED)
            pv = row[1].paragraphs[0]
            para_spacing(pv, before=1, after=1, line=1.1)
            self._run(pv, str(v), size=META_SIZE, color=RGBColor(0x44, 0x44, 0x44))
        # 收掉表格边框（三无表格看起来更像元信息块）
        _table_no_border(tbl)

        if conv.url:
            pu = self._p(before=4, after=10, line=1.1)
            self._run(pu, "原始链接：", size=META_SIZE, bold=True, color=CLR_MUTED)
            add_hyperlink(pu, conv.url, conv.url)

    # ---- 单条消息 ----
    def build_message(self, idx: int, msg: Message) -> None:
        if self.opt["show_role_label"]:
            self._role_label(idx, msg)
        blocks = _get_blocks(msg.content)
        if not blocks and msg.content.strip():
            blocks = [{"t": "para", "inlines": [{"t": "text", "text": msg.content.strip()}]}]
        for b in blocks:
            self.build_block(b, base_indent=0.0)
        if self.opt.get("include_thinking") and msg.thinking.strip():
            self._thinking(msg.thinking)

    def _role_label(self, idx: int, msg: Message) -> None:
        is_user = msg.role == "user"
        label = "用户" if is_user else ("系统" if msg.role == "system" else "AI 回答")
        p = self._p(before=12 if idx else 6, after=6, line=1.0, indent_left=0.0)
        shade(p._p, SHADE_USER if is_user else SHADE_AI)
        para_border(p, left={"sz": "18", "color": "4A7EBB" if is_user else "4E9A78", "space": "6"})
        self._run(p, label, size=Pt(10), bold=True, color=CLR_USER if is_user else CLR_AI)

    def _thinking(self, text: str) -> None:
        p = self._p(before=4, after=4, line=1.2, indent_left=0.3)
        shade(p._p, "FAF7EE")
        para_border(p, left={"sz": "12", "color": "D8C88A", "space": "6"})
        self._run(p, "思考过程", size=Pt(9), bold=True, color=RGBColor(0x8A, 0x74, 0x1E))
        for line in text.split("\n"):
            if not line.strip():
                continue
            pp = self._p(before=0, after=2, line=1.25, indent_left=0.3)
            self._run(pp, line, size=Pt(9.5), color=RGBColor(0x66, 0x5C, 0x3A))

    # ---- 块级渲染 ----
    def build_block(self, block: Dict[str, Any], base_indent: float = 0.0) -> None:
        t = block.get("t")
        handler = getattr(self, "_blk_" + str(t), None)
        if handler is not None:
            handler(block, base_indent)
        elif t:
            self.notes_extra.append("未识别的块类型：%s" % t)

    def _blk_heading(self, b: Dict[str, Any], indent: float) -> None:
        entry = self._next_toc_entry()
        if entry is not None:
            level = entry["level"]
            bm = entry["bm"]
        else:
            # 兜底：预扫描未覆盖时仍按原始层级渲染，不让导出中断
            try:
                level = max(1, min(6, int(b.get("level") or 1)))
            except (TypeError, ValueError):
                level = 1
            bm = None
        p = self._p(style="Heading %d" % level, before=10, after=4, line=1.25,
                    indent_left=indent or None)
        if bm:
            self._bm_id += 1
            add_bookmark(p, bm, self._bm_id)
        for inline in b.get("inlines", []):
            self._render_inline(p, inline, size=Pt(max(12, 17 - level * 1.5)))

    def _blk_para(self, b: Dict[str, Any], indent: float) -> None:
        p = self._p(before=0, after=6, line=1.35, indent_left=indent or None)
        for inline in b.get("inlines", []):
            self._render_inline(p, inline)

    def _blk_math(self, b: Dict[str, Any], indent: float) -> None:
        self._add_math_paragraph(b.get("latex", ""), display=True, indent=indent,
                                 mathml=b.get("mathml", ""))

    def _blk_hr(self, b: Dict[str, Any], indent: float) -> None:
        p = self._p(before=6, after=6, line=1.0)
        para_border(p, bottom={"sz": "6", "color": "D0D3D9", "space": "1"})
        self._run(p, "")

    def _blk_code(self, b: Dict[str, Any], indent: float) -> None:
        lang = (b.get("lang") or "").strip()
        text = b.get("text") or ""
        p = self._p(before=4, after=8, line=1.15, indent_left=(indent or 0) + 0.3)
        shade(p._p, SHADE_CODE)
        para_border(p, box={"sz": "4", "color": "DCE0E5", "space": "6"})
        if lang:
            lr = p.add_run("[%s]\n" % lang)
            set_run_font(lr, latin=CODE_FONT, ea=EA_CODE_FONT, size=Pt(8.5),
                         bold=True, color=RGBColor(0x88, 0x8C, 0x92))
        lines = text.split("\n")
        for i, line in enumerate(lines):
            if i:
                p.add_run().add_break()
            r = p.add_run(line)
            set_run_font(r, latin=CODE_FONT, ea=EA_CODE_FONT, size=CODE_SIZE, color=CLR_CODE)

    def _blk_quote(self, b: Dict[str, Any], indent: float) -> None:
        for inner in b.get("blocks", []):
            if inner.get("t") == "para":
                p = self._p(before=2, after=4, line=1.3, indent_left=(indent or 0) + 0.5)
                para_border(p, left={"sz": "14", "color": "C2C7CF", "space": "8"})
                for inline in inner.get("inlines", []):
                    self._render_inline(p, inline, color=CLR_QUOTE, italic=True)
            else:
                self.build_block(inner, (indent or 0) + 0.5)

    def _blk_list(self, b: Dict[str, Any], indent: float) -> None:
        ordered = bool(b.get("ordered"))
        try:
            counter = int(b.get("start") or 1)
        except Exception:  # noqa: BLE001
            counter = 1
        for item in b.get("items", []):
            first = True
            for inner in item:
                it = inner.get("t")
                if it == "para":
                    marker = ("%d. " % counter) if (ordered and first) else ("• " if first else "")
                    p = self._p(before=0, after=3, line=1.32,
                                indent_left=(indent or 0) + 0.75)
                    p.paragraph_format.first_line_indent = Cm(-0.5)
                    self._run(p, marker)
                    for inline in inner.get("inlines", []):
                        self._render_inline(p, inline)
                    first = False
                elif it == "list":
                    self._blk_list(inner, (indent or 0) + 0.75)
                else:
                    self.build_block(inner, (indent or 0) + 0.75)
            if ordered:
                counter += 1

    def _blk_table(self, b: Dict[str, Any], indent: float) -> None:
        header = b.get("header") or []
        rows = b.get("rows") or []
        ncols = max([len(header)] + [len(r) for r in rows] + [1])
        if not rows and not header:
            return
        tbl = self.doc.add_table(rows=0, cols=ncols)
        tbl.style = _style(self.doc, "Table Grid") or tbl.style
        tbl.autofit = True

        def fill(cells, values, bold=False, fill_hex=None):
            for i in range(ncols):
                cell = cells[i] if i < len(cells) else cells[-1]
                p = cell.paragraphs[0]
                para_spacing(p, before=2, after=2, line=1.2)
                if i < len(values):
                    for inline in values[i]:
                        self._render_inline(p, inline, size=Pt(9.5), bold=bold or None)
                if fill_hex:
                    _cell_shade(cell, fill_hex)

        if header:
            fill(tbl.add_row().cells, header, bold=True, fill_hex="F1F4F7")
        for r in rows:
            fill(tbl.add_row().cells, r)
        # 表格后补一个空段，避免表格贴住下文
        self._p(before=0, after=6, line=1.0)

    # ---- 行内渲染 ----
    def _render_inline(self, p, inline: Dict[str, Any], *, size: Optional[Pt] = None,
                       color: Optional[RGBColor] = None, italic: bool = False,
                       bold: Optional[bool] = None) -> None:
        t = inline.get("t")
        sz = size or BODY_SIZE
        col = color or CLR_TEXT

        if t == "text":
            txt = inline.get("text", "")
            # 文本里如果有换行（软换行），拆成换行显示
            parts = txt.split("\n")
            for i, part in enumerate(parts):
                if i:
                    p.add_run().add_break()
                if part:
                    self._run(p, part, size=sz, color=col, italic=italic or None, bold=bold)
            return

        if t == "br":
            p.add_run().add_break()
            return

        if t == "code":
            r = p.add_run(inline.get("text", ""))
            set_run_font(r, latin=CODE_FONT, ea=EA_CODE_FONT, size=Pt(sz.pt - 0.5), color=RGBColor(0xB0, 0x30, 0x60))
            shade(r._element, SHADE_INLINE_CODE)
            return

        if t == "math":
            self._add_inline_math(p, inline.get("latex", ""), size=sz,
                                  mathml=inline.get("mathml", ""))
            return

        if t in ("strong", "em", "s", "link"):
            children = inline.get("children", [])
            if t == "strong":
                for c in children:
                    self._render_inline(p, c, size=sz, color=col, italic=italic, bold=True)
            elif t == "em":
                for c in children:
                    self._render_inline(p, c, size=sz, color=col, italic=True, bold=bold)
            elif t == "s":
                for c in children:
                    self._render_inline(p, c, size=sz, color=CLR_MUTED, italic=italic)
            elif t == "link":
                href = inline.get("href", "")
                label = _flatten_text(children) or href
                if href.startswith("http"):
                    add_hyperlink(p, href, label)
                else:
                    for c in children:
                        self._render_inline(p, c, size=sz, color=col, italic=italic, bold=bold)
            return

        if t == "image":
            alt = inline.get("alt") or "图片"
            src = inline.get("src") or ""
            r = p.add_run("[图片：%s]" % alt)
            set_run_font(r, size=Pt(sz.pt - 0.5), italic=True, color=CLR_MUTED)
            if src.startswith("http"):
                p.add_run(" ")
                add_hyperlink(p, src, "链接", color=CLR_MUTED)
            return

    # ---- 公式 ----
    def _omml_of(self, latex: str, mathml: str, display: bool):
        """把公式节点转成 OMML。有 LaTeX 走 LaTeX，只有 MathML 就走 MathML。"""
        from . import mathfix

        if mathml:
            omml, notes = mathfix.mathml_to_omml(mathml)
            for n in notes:
                self.notes_extra.append(n)
            return omml
        omml, notes = mathfix.latex_to_omml(latex, display=display)
        for n in notes:
            self.notes_extra.append(n)
        return omml

    def _fallback_text(self, latex: str, mathml: str) -> str:
        """公式转不出来时，退化成"能看见的原文"，而不是留空。"""
        if latex.strip():
            return latex.strip()
        # 只有 MathML 时，抓 <m:t>/文本内容当原文
        import re as _re

        txt = " ".join(_re.findall(r">([^<>]+)<", mathml or ""))
        return _re.sub(r"\s+", " ", txt).strip()[:200] or "（公式）"

    def _add_math_paragraph(self, latex: str, display: bool, indent: float = 0.0,
                            mathml: str = "") -> None:
        from . import mathfix

        if not latex.strip() and not mathml.strip():
            return
        omml = self._omml_of(latex, mathml, True)
        p = self._p(before=6, after=6, line=1.2, indent_left=None)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if omml is None:
            self._math_failed += 1
            self._run(p, self._fallback_text(latex, mathml), latin=CODE_FONT, ea=EA_CODE_FONT,
                      size=Pt(10), color=RGBColor(0x99, 0x33, 0x33))
            return
        try:
            xml = mathfix.wrap_omml(omml, display=True)
            p._p.append(parse_xml(xml))
            self._math_ok += 1
        except Exception as e:  # noqa: BLE001
            self._math_failed += 1
            self.notes_extra.append("公式插入失败：%s: %s" % (type(e).__name__, str(e)[:100]))
            self._run(p, self._fallback_text(latex, mathml), latin=CODE_FONT,
                      ea=EA_CODE_FONT, size=Pt(10))

    def _add_inline_math(self, p, latex: str, size: Pt, mathml: str = "") -> None:
        from . import mathfix

        if not latex.strip() and not mathml.strip():
            return
        omml = self._omml_of(latex, mathml, False)
        if omml is None:
            self._math_failed += 1
            r = p.add_run(self._fallback_text(latex, mathml))
            set_run_font(r, latin=CODE_FONT, ea=EA_CODE_FONT, size=Pt(size.pt - 0.5),
                         color=RGBColor(0x99, 0x33, 0x33))
            return
        try:
            xml = mathfix.wrap_omml(omml, display=False)
            p._p.append(parse_xml(xml))
            self._math_ok += 1
        except Exception as e:  # noqa: BLE001
            self._math_failed += 1
            self.notes_extra.append("行内公式插入失败：%s: %s" % (type(e).__name__, str(e)[:100]))
            r = p.add_run(self._fallback_text(latex, mathml))
            set_run_font(r, latin=CODE_FONT, size=Pt(size.pt - 0.5))

    # ---- 章节目录（对话树 / 文档模式：标题层级归一化 + 书签锚点）----

    def _prescan(self) -> None:
        """预扫描，构建章节目录条目（文档顺序）与书签。

        对话模式（dialogue，与参考程序一致）：
          每条消息本身是一个一级节点（"我：提问" / "豆包："），折叠后导航窗格
          顶层只显示各消息；消息内部的 Markdown 标题被抬到 2 级起步（成为
          二级/三级子目录）。不插入可见目录页，靠 Word 导航窗格收缩。
        文档模式（document）：按普通文档，把每条消息最浅标题归一为 1 级。
        """
        self._toc = []
        self._bm_counter = 0
        if self._outline_mode() == "dialogue":
            user, asst = self._labels()
            for m in self.conv.messages:
                head, body_blocks = self._message_parts(m)
                self._bm_counter += 1
                node_bm = "Sec%d" % self._bm_counter
                if m.role == "user":
                    node_text = ("%s\uff1a%s" % (user, head)) if head else ("%s\uff1a" % user)
                else:
                    node_text = "%s\uff1a" % asst
                self._toc.append({"level": 1, "bm": node_bm, "text": node_text})
                # 内部标题归一：最浅层 -> 2 级
                raw = []
                for b in body_blocks:
                    if b.get("t") == "heading":
                        try:
                            raw.append(max(1, min(6, int(b.get("level") or 1))))
                        except (TypeError, ValueError):
                            raw.append(1)
                if not raw:
                    continue
                shift = 2 - min(raw)
                for b in body_blocks:
                    if b.get("t") != "heading":
                        continue
                    try:
                        rl = max(1, min(6, int(b.get("level") or 1)))
                    except (TypeError, ValueError):
                        rl = 1
                    rebased = max(2, min(9, rl + shift))
                    self._bm_counter += 1
                    self._toc.append({"level": rebased,
                                      "bm": "Sec%d" % self._bm_counter,
                                      "text": _flatten_text(b.get("inlines", [])).strip()})
            self._toc_i = 0
            return
        # ---- 文档模式：按消息把最浅标题归一化为 1 级 ----
        for m in self.conv.messages:
            blocks = _get_blocks(m.content)
            raw_levels = []
            for b in blocks:
                if b.get("t") == "heading":
                    try:
                        raw_levels.append(max(1, min(6, int(b.get("level") or 1))))
                    except (TypeError, ValueError):
                        raw_levels.append(1)
            if not raw_levels:
                continue
            shift = 1 - min(raw_levels)               # 把本消息最浅层抬到 1 级
            for b in blocks:
                if b.get("t") != "heading":
                    continue
                try:
                    raw = max(1, min(6, int(b.get("level") or 1)))
                except (TypeError, ValueError):
                    raw = 1
                rebased = max(1, min(9, raw + shift))
                self._bm_counter += 1
                name = "Sec%d" % self._bm_counter
                text = _flatten_text(b.get("inlines", [])).strip()
                self._toc.append({"level": rebased, "text": text, "bm": name})
        self._toc_i = 0

    def _next_toc_entry(self):
        if self._toc_i < len(self._toc):
            e = self._toc[self._toc_i]
            self._toc_i += 1
            return e
        return None

    def build_toc(self) -> None:
        """在正文前插入可见的章节目录（点击条目即跳转到对应书签）。

        默认关闭：对话/文档的层级靠 Word/WPS 的「导航窗格」收缩即可，
        不需要在正文体里塞一页目录。
        """
        if not self.opt.get("toc", False):
            return
        depth = int(self.opt.get("toc_depth", 2))
        entries = [e for e in self._toc if 1 <= e["level"] <= depth]
        if not entries:
            return
        tp = self._p(before=8, after=8, line=1.2)
        self._run(tp, "目录", size=Pt(15), bold=True, color=RGBColor(0x1A, 0x1A, 0x1A))
        para_border(tp, bottom={"sz": "6", "color": "D0D3D9", "space": "4"})
        for e in entries:
            indent = 0.4 * (e["level"] - 1)
            p = self._p(before=0, after=2, line=1.25, indent_left=indent)
            add_internal_link(p, e["bm"], e["text"] or "（未命名章节）",
                              color=CLR_LINK, size=Pt(10.5))

    # ---- 尾部 ----
    def build_footer_notes(self) -> None:
        notes = list(self.conv.notes) + self.notes_extra
        notes = [n for n in notes if n and n.strip()]
        if not notes:
            return
        p = self._p(before=14, after=4, line=1.0)
        para_border(p, bottom={"sz": "6", "color": "D0D3D9", "space": "4"})
        self._run(p, "导出说明", size=Pt(9.5), bold=True, color=CLR_MUTED)
        shown = notes[: self.opt.get("notes_max", 6)]
        for n in shown:
            pp = self._p(before=0, after=2, line=1.2, indent_left=0.3)
            self._run(pp, "• " + n, size=Pt(8.5), color=CLR_MUTED)
        extra = len(notes) - len(shown)
        if extra > 0:
            pp = self._p(before=0, after=2, line=1.2, indent_left=0.3)
            self._run(pp, "• 另有 %d 条提示未显示。" % extra, size=Pt(8.5), color=CLR_MUTED)

    # ---- 对话模式：每条消息一个一级节点 ----
    def _build_node(self, m: Message) -> None:
        """把一条消息写成一个一级节点（我：/豆包：），正文随后展开。"""
        entry = self._next_toc_entry()
        is_user = m.role == "user"
        if entry is None:
            user, asst = self._labels()
            entry = {"level": 1, "bm": "Sec0",
                     "text": ("%s\uff1a" % user) if is_user else ("%s\uff1a" % asst)}
        color = CLR_USER if is_user else CLR_AI
        p = self._p(style="Heading 1", before=14, after=6, line=1.25, indent_left=None)
        if entry.get("bm"):
            self._bm_id += 1
            add_bookmark(p, entry["bm"], self._bm_id)
        self._run(p, entry.get("text") or "", color=color)
        # 正文（内部标题已被 _prescan 抬到 2 级起步，由 _blk_heading 消费）
        _, body_blocks = self._message_parts(m)
        if not body_blocks and m.content.strip():
            body_blocks = [{"t": "para",
                            "inlines": [{"t": "text", "text": m.content.strip()}]}]
        for b in body_blocks:
            self.build_block(b, base_indent=0.0)
        if self.opt.get("include_thinking") and getattr(m, "thinking", "").strip():
            self._thinking(m.thinking)

    # ---- 主流程 ----
    def build(self) -> Document:
        self._bm_id = 0
        self._prescan()                 # 先扫描，确定层级归一化与书签名
        self.build_header()
        self.build_toc()                 # 目录页放在正文（含消息）之前
        if not self.conv.messages:
            p = self._p(before=10, after=6)
            self._run(p, "没有抓取到任何对话内容。", color=RGBColor(0x99, 0x33, 0x33))
        elif self._outline_mode() == "dialogue":
            for m in self.conv.messages:
                self._build_node(m)
        else:
            for idx, m in enumerate(self.conv.messages):
                self.build_message(idx, m)
        self.build_footer_notes()
        return self.doc

    def stats(self) -> Dict[str, Any]:
        return {
            "math_rendered": self._math_ok,
            "math_failed": self._math_failed,
            "notes": list(self.notes_extra),
        }


# --------------------------------------------------------------------------
# 小工具
# --------------------------------------------------------------------------

_BLOCK_CACHE: Dict[str, List[Dict[str, Any]]] = {}


def _get_blocks(md: str) -> List[Dict[str, Any]]:
    from .mdparse import parse_markdown

    key = md[:4000] + "|%d" % len(md)
    if key in _BLOCK_CACHE:
        return _BLOCK_CACHE[key]
    blocks, _ = parse_markdown(md)
    if len(_BLOCK_CACHE) > 400:
        _BLOCK_CACHE.clear()
    _BLOCK_CACHE[key] = blocks
    return blocks


def _flatten_text(inlines: List[Dict[str, Any]]) -> str:
    out: List[str] = []
    for i in inlines:
        t = i.get("t")
        if t == "text":
            out.append(i.get("text", ""))
        elif t == "code":
            out.append(i.get("text", ""))
        elif t == "math":
            out.append("$%s$" % i.get("latex", ""))
        elif t in ("strong", "em", "s", "link"):
            out.append(_flatten_text(i.get("children", [])))
    return "".join(out)


def _table_no_border(tbl) -> None:
    """去掉表格所有边框。"""
    try:
        tblPr = tbl._tbl.tblPr
        borders = OxmlElement("w:tblBorders")
        for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
            el = OxmlElement("w:" + edge)
            el.set(qn("w:val"), "none")
            el.set(qn("w:sz"), "0")
            el.set(qn("w:space"), "0")
            el.set(qn("w:color"), "auto")
            borders.append(el)
        tblPr.append(borders)
    except Exception:  # noqa: BLE001
        pass


def _cell_shade(cell, fill: str) -> None:
    try:
        tcPr = cell._tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), fill)
        tcPr.append(shd)
    except Exception:  # noqa: BLE001
        pass


def render_docx(conv: Conversation, out_path: str, options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """把 Conversation 写成 docx 文件，返回统计信息。"""
    b = DocxBuilder(conv, options)
    doc = b.build()
    doc.save(out_path)
    st = b.stats()
    st["path"] = out_path
    return st
