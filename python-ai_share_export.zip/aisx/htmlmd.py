# -*- coding: utf-8 -*-
"""HTML → Markdown，重点保证**公式不丢、不糊**。

AI 对话页里的公式，浏览器上看到的是 KaTeX / MathJax 渲染出来的漂亮排版。
如果直接抓 DOM 文本，你会得到一堆 `<mrow>`、重复的上下标字符、
或者干脆是空字符串 —— 这就是"公式乱码"的根源。

本模块的做法：在转 Markdown **之前**，先把 KaTeX / MathJax 节点整体替换成
占位符，并把它们内部的 LaTeX 源码（藏在 annotation 里）单独存起来；
转完 Markdown 之后再还原成 `$...$` / `$$...$$`。

顺带处理：
- 去掉网页上的按钮、导航、侧栏等噪声
- 定位到真正的对话容器（而不是整页）
- 代码块语言识别
"""

from __future__ import annotations

import html as _htmlesc
import re
from typing import Dict, List, Optional, Tuple

from bs4 import BeautifulSoup
from bs4.element import Tag
from markdownify import MarkdownConverter

# 占位符只用字母数字，避免被 markdownify 转义
_TOK = "AISXMATHTK%dZZ"
_TOK_RE = re.compile(r"AISXMATHTK(\d+)ZZ")

# 只有 MathML、没有 LaTeX 源码时的哨兵。mdparse 靠它区分"这是 MathML 片段"，
# 从而走 mathml_to_omml 而不是 latex2mathml。
MATHML_SENTINEL = "\x01MATHML\x01"

# 零宽/格式控制字符。KaTeX 的 `<span class="vlist-s">` 撑高元素里就装着 U+200B，
# 而它连 `\s` 都匹配不到，会让所有"按空白判断"的逻辑失效。见 mathfix 同名常量。
_ZW_RE = re.compile("[\u200b\u200c\u200d\u2060\ufeff\u00ad]")

# 承载"未渲染 LaTeX 源码"的属性名，按优先级排列。
# 豆包把 `\(\beta_1\)` 放在 `copy-text` 里；KaTeX 的 HTML-only 输出则完全没有
# `<annotation>`，只剩一堆套版的字形 span —— 此时属性就是唯一的真源码来源。
_LATEX_ATTRS = (
    "copy-text", "data-copy-text", "data-raw-text", "data-latex", "data-tex",
    "data-original", "data-formula", "data-math", "data-source-text",
)

# 属性值里可能带 TeX 分隔符
_TEX_DELIMS = (
    (r"\[", r"\]", True),
    (r"\(", r"\)", False),
    ("$$", "$$", True),
)

# 属性值必须至少满足一条，才认作真 LaTeX：
#   1) 自带 TeX 分隔符（\(..\) / \[..\] / $$..$$）；
#   2) 含 LaTeX 控制符或上下标语法。
# 这样能挡掉把普通文案塞进 data-* 的情况。
_TEX_SIGNAL_RE = re.compile(r"[\\^_{}]")

# 页面上必然与对话无关的标签
_DROP_TAGS = [
    "script", "style", "noscript", "iframe", "canvas", "form", "button",
    "nav", "header", "footer", "aside", "svg", "select", "option", "input",
    "textarea", "template", "dialog", "audio", "video", "meta", "link",
]

# 含这些关键词的 class/id 基本是交互外壳，不是对话正文
_JUNK_HINTS = (
    "toolbar", "tool-bar", "menu", "dropdown", "modal", "popover", "tooltip",
    "sidebar", "side-bar", "banner", "toast", "avatar", "rating", "feedback",
    "share-", "copy-", "footer", "header", "nav", "breadcrumb", "scroll-to",
    "back-to-top", "cookie", "advert", "ad-", "promo",
)

# 各平台的对话容器候选选择器（命中即用，按优先级排列）
CONTAINER_SELECTORS: Dict[str, List[str]] = {
    "chatgpt": [
        "main div[class*='react-scroll-to-bottom']",
        "main",
        "div[class*='conversation']",
    ],
    "claude": [
        "div[class*='Conversation']",
        "div[class*='conversation']",
        "main",
    ],
    "deepseek": [
        "div[class*='_4f9bf79']",
        "div[class*='chat-message']",
        "main",
    ],
    "kimi": [
        "div[class*='chat-content']",
        "div[class*='segment']",
        "main",
    ],
    "doubao": [
        "div[class*='message-list']",
        "div[class*='chat']",
        "main",
    ],
    "tongyi": [
        "div[class*='conversation']",
        "div[class*='chat']",
        "main",
    ],
    "yuanbao": [
        "div[class*='agent-chat']",
        "div[class*='chat']",
        "main",
    ],
    "generic": ["main", "article", "div[role='main']", "body"],
}


# --------------------------------------------------------------------------
# 一、KaTeX / MathJax 还原
# --------------------------------------------------------------------------

def _tex_from_annotation(node: Tag) -> str:
    """从 MathML 的 <annotation encoding="application/x-tex"> 里取 LaTeX 源码。"""
    ann = node.find("annotation", attrs={"encoding": re.compile("tex", re.I)})
    if ann is not None:
        return ann.get_text() or ""
    # 有的实现用 <annotation-xml>
    ann = node.find("annotation-xml")
    if ann is not None:
        return ann.get_text() or ""
    return ""


def _mathml_of(node: Tag) -> str:
    m = node.find("math")
    if m is None:
        return ""
    if not m.get("xmlns"):
        m["xmlns"] = "http://www.w3.org/1998/Math/MathML"
    return str(m)


def _is_display(node: Tag) -> bool:
    """判断这段公式是独立成行还是行内。"""
    for parent in [node] + list(node.parents)[:4]:
        if getattr(parent, "attrs", None) is None:
            continue
        classes = " ".join(parent.get("class") or [])
        if "katex-display" in classes or "math-display" in classes:
            return True
        style = (parent.get("style") or "").replace(" ", "")
        if "display:block" in style:
            return True
    return False


def _latex_from_attrs(node: Tag) -> Optional[Tuple[str, bool]]:
    """从节点的 HTML 属性里取"未渲染的 LaTeX 源码"。

    这是抓取公式最重要的一条通道：豆包的分享页把 KaTeX 渲染成了纯 HTML
    （`katex-html` 有、`annotation` 一个都没有），DOM 里看得见的只有一坨
    排版好的字形 span。真正的源码只留在 `copy-text="\\(\\beta_1\\)"` 这类属性上。
    早期版本只认 `<annotation>`，取不到就退而取"可见文字"，于是把 `β 1 \u200b`
    这种字形串当成 LaTeX 硬喂进转换器 —— 导出的公式因此全是散字。

    返回 (latex, 是否独立公式)；没找到返回 None。
    """
    for attr in _LATEX_ATTRS:
        raw = node.get(attr)
        if not isinstance(raw, str):
            continue
        s = _htmlesc.unescape(raw).strip()
        if not s or _ZW_RE.search(s):
            continue
        disp = False
        had_delim = False
        for op, cl, d in _TEX_DELIMS:
            if len(s) > len(op) + len(cl) and s.startswith(op) and s.endswith(cl):
                s = s[len(op):-len(cl)].strip()
                disp = d
                had_delim = True
                break
        if not s or _ZW_RE.search(s):
            continue
        # 没有自带分隔符的属性，必须有 LaTeX 语法特征才认（挡掉普通文案）
        if not had_delim and not _TEX_SIGNAL_RE.search(s):
            continue
        if len(s) > 4000:
            continue
        if not disp:
            disp = _is_display(node)
        return s, disp
    return None


def _only_outermost(nodes: List[Tag]) -> List[Tag]:
    """同一段公式可能被多层包装（外层 katex-display 套内层 katex），
    选择器会把内外层都选出来。只保留最外层，避免同一个公式被收两遍。"""
    ids = set(id(n) for n in nodes)
    out: List[Tag] = []
    for n in nodes:
        if any(id(p) in ids for p in n.parents):
            continue
        out.append(n)
    return out


def protect_math(soup: BeautifulSoup) -> Tuple[Dict[str, Tuple[str, bool, str]], int]:
    """把 KaTeX / MathJax 节点换成占位符。

    返回 (映射表, 还原失败的公式数)。
    映射：token -> (latex 源码, 是否独立公式, 原始 MathML)
    """
    table: Dict[str, Tuple[str, bool, str]] = {}
    idx = 0
    failed = 0

    # --- 0. 属性里的未渲染 LaTeX 源码（最高优先级）---
    # 必须排在最前面：豆包这类站点的公式外层容器（带 copy-text 的 span）
    # 恰好把内层 .katex 包住，先处理外层就等于把整个公式一次性拿干净，
    # 也顺带避免了"内外两层各收一遍"的重复计数。
    try:
        attr_sels = ",".join("[%s]" % a for a in _LATEX_ATTRS)
        for node in _only_outermost([n for n in soup.select(attr_sels) if isinstance(n, Tag)]):
            got = _latex_from_attrs(node)
            if not got:
                continue
            tex, disp = got
            tok = _TOK % idx
            idx += 1
            table[tok] = (tex, disp, "")
            node.replace_with(soup.new_string(tok))
    except Exception:  # noqa: BLE001
        pass

    # --- 1. KaTeX ---
    for node in _only_outermost(soup.select("span.katex, span.katex-display, .katex-display")):
        try:
            tex = _tex_from_annotation(node)
            mm = _mathml_of(node)
            disp = _is_display(node)
            if not tex and not mm:
                # 拿不到源码，也没有 MathML —— 说明这处只有渲染结果。
                # 早期版本会把它包成 `$...$` 交给下游当 LaTeX 处理，
                # 结果生出一个"结构合法、内容全是散字形"的公式对象，
                # 比不转换更糟。这里改为**只保留可见文字、不加任何数学标记**，
                # 让它老老实实当正文，用户看得见也删得掉。
                txt = _ZW_RE.sub("", node.get_text(" ", strip=True)).strip()
                failed += 1
                if txt:
                    node.replace_with(soup.new_string(txt))
                else:
                    node.decompose()
                continue
            tok = _TOK % idx
            idx += 1
            table[tok] = (tex, disp, mm)
            node.replace_with(soup.new_string(tok))
        except Exception:  # noqa: BLE001
            failed += 1
            txt = _ZW_RE.sub("", node.get_text(" ", strip=True))
            node.replace_with(soup.new_string(txt))

    # --- 2. MathJax 3 (mjx-container) ---
    for node in _only_outermost(soup.select("mjx-container, mjx-assistive-mml")):
        try:
            tex = _tex_from_annotation(node)
            mm = _mathml_of(node)
            disp = _is_display(node) or (node.get("display") == "true")
            if not tex and not mm:
                failed += 1
                node.decompose()
                continue
            tok = _TOK % idx
            idx += 1
            table[tok] = (tex, disp, mm)
            node.replace_with(soup.new_string(tok))
        except Exception:  # noqa: BLE001
            failed += 1
            node.replace_with(soup.new_string(node.get_text(" ", strip=True)))

    # --- 3. MathJax 2 的 <script type="math/tex"> ---
    for node in soup.select('script[type^="math/tex"]'):
        try:
            tex = node.string or node.get_text() or ""
            disp = "mode=display" in (node.get("type") or "")
            if not tex.strip():
                node.decompose()
                continue
            tok = _TOK % idx
            idx += 1
            table[tok] = (tex, disp, "")
            node.replace_with(soup.new_string(tok))
        except Exception:  # noqa: BLE001
            node.decompose()

    # --- 4. 纯 MathML（没有 annotation 的，只能直接用 MathML→OMML） ---
    # 注意跳过 KaTeX/MathJax 残留的辅助 MathML（它们已经有 LaTeX 源码了）
    for node in _only_outermost(soup.find_all("math")):
        try:
            if node.find_parent(["annotation"]) is not None:
                continue
            p = node.find_parent(True)
            skip = False
            while p is not None:
                cls = " ".join(p.get("class") or []) if hasattr(p, "get") else ""
                if "katex" in cls or p.name == "mjx-container":
                    skip = True
                    break
                p = p.find_parent(True)
            if skip:
                continue
            mm = _mathml_of(node)
            if not mm:
                node.decompose()
                continue
            disp = (node.get("display") or "").strip() == "block"
            tok = _TOK % idx
            idx += 1
            table[tok] = ("", disp, mm)
            node.replace_with(soup.new_string(tok))
        except Exception:  # noqa: BLE001
            failed += 1
            node.decompose()

    return table, failed


def restore_math(md: str, table: Dict[str, Tuple[str, bool, str]]) -> str:
    """把占位符换回 $...$ / $$...$$。"""
    if not table:
        return md

    def repl(m: "re.Match[str]") -> str:
        tok = m.group(0)
        item = table.get(tok)
        if not item:
            return ""
        tex, disp, mm = item
        if tex:
            body = tex.strip()
        else:
            # 没有 LaTeX 源码，用 MathML 兜底：打上哨兵，交给 mdparse 识别，
            # 由 docxwriter 走 mathml_to_omml —— 不能当 LaTeX 喂下去。
            body = MATHML_SENTINEL + mm
        if disp:
            return "\n\n$$\n%s\n$$\n\n" % body
        return "$%s$" % body

    return _TOK_RE.sub(repl, md)


# --------------------------------------------------------------------------
# 二、噪声清理与容器定位
# --------------------------------------------------------------------------

def _cls_id(node: Tag) -> str:
    c = node.get("class") or []
    if isinstance(c, str):
        c = [c]
    return (" ".join(c) + " " + (node.get("id") or "")).lower()


def strip_chrome(root: Tag) -> None:
    """就地删除对话正文之外的交互元素。"""
    for tag in _DROP_TAGS:
        for node in root.find_all(tag):
            node.decompose()

    # 明显的 UI 外壳
    for node in root.find_all(["div", "section", "span", "ul", "ol", "p", "a"]):
        if not isinstance(node, Tag) or node.decomposed:
            continue
        hint = _cls_id(node)
        if not hint.strip():
            continue
        if any(k in hint for k in _JUNK_HINTS):
            # 只有当它本身很短、或它包含大量按钮时才删，避免误删正文容器
            txt = node.get_text(" ", strip=True)
            nbtn = len(node.find_all(["button", "svg", "a"]))
            if len(txt) < 120 or nbtn >= 2:
                node.decompose()

    # aria-hidden 的纯装饰层
    for node in root.find_all(attrs={"aria-hidden": "true"}):
        if isinstance(node, Tag) and not node.decomposed:
            node.decompose()


def _score_container(node: Tag) -> float:
    """给候选容器打分：正文越多越好，链接/按钮/导航越密越差。"""
    text = node.get_text(" ", strip=True)
    n = len(text)
    if n < 80:
        return -1.0
    score = float(n)
    nlinks = len(node.find_all("a"))
    score -= nlinks * 30
    nctrl = len(node.find_all(["button", "svg", "input"]))
    score -= nctrl * 25
    # 段落数量是"正文感"的强信号
    score += len(node.find_all(["p", "pre", "li", "h1", "h2", "h3"])) * 8
    # 带导航/页脚的往往是整页外壳，不是对话容器，重罚
    for chrome in ("nav", "header", "footer", "aside"):
        score -= len(node.find_all(chrome)) * 300
    return score


def find_conversation_root(soup: BeautifulSoup, platform_key: str = "generic") -> Tag:
    """在整页里定位对话正文容器。

    关键点：必须把**所有**候选选择器的结果放在一起比分数，取全局最优。
    早期版本"某个选择器一命中就直接返回"，结果在 DeepSeek 上选中了
    单条消息的小 div（因为它排在选择器列表第一个），后面自然切不出消息。
    """
    selectors = list(CONTAINER_SELECTORS.get(platform_key) or []) + [
        "main", "article", "div[role='main']",
        "div[class*='conversation']", "div[class*='chat-container']",
        "div[class*='virtual-list-items']", "div[class*='message-list']",
    ]

    cands: List[Tag] = []
    seen = set()
    for sel in selectors:
        try:
            found = soup.select(sel)
        except Exception:  # noqa: BLE001
            continue
        for node in found:
            if id(node) in seen:
                continue
            seen.add(id(node))
            cands.append(node)

    if cands:
        scored = [(n, _score_container(n)) for n in cands]
        best, best_score = max(scored, key=lambda x: x[1])
        if best_score > 0:
            return best

    body = soup.body or soup
    # 全页扫描，挑分最高的区块
    best_node, best_score = body, 0.0
    for node in body.find_all(["div", "section", "article", "main"]):
        if not isinstance(node, Tag):
            continue
        s = _score_container(node)
        if s > best_score:
            best_score, best_node = s, node
    return best_node


# --------------------------------------------------------------------------
# 三、HTML → Markdown
# --------------------------------------------------------------------------

def _code_lang(el: Tag) -> str:
    """从 <pre>/<code> 的 class 里猜语言。"""
    for cand in [el] + el.find_all("code")[:1] + el.find_all(True)[:3]:
        classes = cand.get("class") or []
        if isinstance(classes, str):
            classes = classes.split()
        for c in classes:
            m = re.match(r"^(?:language|lang|highlight|hljs)-([\w+#.-]+)$", c, re.I)
            if m and m.group(1).lower() not in ("source", "text", "plain", "highlight"):
                return m.group(1).lower()
    return ""


class _AIExportConverter(MarkdownConverter):
    """在 markdownify 基础上补几件 AI 对话页常见的事。"""

    def convert_pre(self, el, text, parent_tags):  # noqa: ANN001
        lang = _code_lang(el)
        code = el.get_text()
        code = code.replace("\r\n", "\n").rstrip("\n")
        # 防止代码里出现 ``` 把围栏截断
        fence = "```"
        while fence in code:
            fence += "`"
        return "\n\n%s%s\n%s\n%s\n\n" % (fence, lang, code, fence)

    def convert_img(self, el, text, parent_tags):  # noqa: ANN001
        alt = el.get("alt") or ""
        src = el.get("src") or ""
        if src.startswith("data:"):
            # 内联的 base64 图片不塞进 Markdown，太大
            return "[图片: %s]" % (alt or "已省略")
        return "![%s](%s)" % (alt, src) if src else ("[图片: %s]" % alt if alt else "")

    def convert_a(self, el, text, parent_tags):  # noqa: ANN001
        href = (el.get("href") or "").strip()
        if not href or href.startswith("javascript:"):
            return text
        return "[%s](%s)" % (text, href)


def html_to_markdown(
    html: str,
    platform_key: str = "generic",
    base_url: str = "",
    take_container: bool = True,
) -> Tuple[str, Dict[str, Tuple[str, bool, str]], int, List[str]]:
    """整条 HTML → Markdown 流程。

    返回 (markdown, 公式表, 公式还原失败数, 提示列表)。
    """
    notes: List[str] = []
    soup = BeautifulSoup(html, "lxml")

    # 先把 math 占位（必须在清理噪声之前，避免 math 被当成装饰删掉）
    math_table, math_failed = protect_math(soup)
    if math_failed:
        notes.append("有 %d 处公式在页面里只有渲染结果、取不到 LaTeX 源码，"
                     "已按可见文字原样保留（没有生成公式对象，避免出现散字公式）。" % math_failed)

    root: Tag = soup
    if take_container:
        root = find_conversation_root(soup, platform_key)

    strip_chrome(root)

    # 图片绝对化
    if base_url:
        try:
            for img in root.find_all("img"):
                src = img.get("src") or ""
                if src.startswith("//"):
                    img["src"] = "https:" + src
                elif src.startswith("/"):
                    from urllib.parse import urljoin

                    img["src"] = urljoin(base_url, src)
        except Exception:  # noqa: BLE001
            pass

    conv = _AIExportConverter(
        heading_style="ATX",
        bullets="-",
        autolinks=False,
        table_infer_header=True,
        escape_asterisks=False,
        escape_underscores=False,
        escape_misc=False,
        strip_comments=True,
        strong_em_symbol="*",
    )
    md = conv.convert_soup(root)
    md = restore_math(md, math_table)
    md = _tidy_markdown(md)
    return md, math_table, math_failed, notes


def _tidy_markdown(md: str) -> str:
    """收尾清理：多余空行、行尾空格、markdownify 留下的小瑕疵。"""
    t = md.replace("\r\n", "\n")
    t = re.sub(r"[ \t]+\n", "\n", t)
    t = re.sub(r"\n{4,}", "\n\n\n", t)
    # markdownify 会把表格前后加很多空行
    t = re.sub(r"\n{3,}(\|)", r"\n\n\1", t)
    # 去掉连续重复的分隔线
    t = re.sub(r"(\n\s*\*\s*\*\s*\*\s*){3,}", "\n\n---\n\n", t)
    return t.strip()
