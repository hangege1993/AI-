# -*- coding: utf-8 -*-
"""抓取层：按"成本从低到高"依次尝试，拿到内容就停。

   1) **HTTP 直取**       —— requests，最快，能应付服务端渲染的页面
   2) **官方/内嵌 JSON**   —— 页面里本来就有对话数据（Claude / ChatGPT 常见）
   3) **浏览器渲染**       —— 用 Playwright 真跑一遍 JS，
                             同时挂网络监听把对话接口的 JSON 响应也截下来

第 3 步是"万能兜底"：绝大多数前端渲染的 AI 网站（Kimi / 豆包 / 通义 / 元宝…）
都会在打开页面时请求一个返回对话数据的接口，我们把它截下来即可，
不需要针对每家网站逆向接口。
"""

from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

import requests

from . import extract as ex
from . import platforms as pf
from .models import Conversation, Message

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)

BASE_HEADERS = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Upgrade-Insecure-Requests": "1",
}

# 浏览器渲染时忽略的请求（埋点/统计），截下来也是噪声
_URL_NOISE = (
    "analytics", "telemetry", "monitor", "track", "sentry", "beacon",
    "sensorsdata", "log.", "/log/", "statistics", "buried", "datareport",
    "hm.baidu", "google-analytics", "gtag", "hotjar", "clarity",
)


class FetchError(RuntimeError):
    """抓取失败，消息面向用户可读。"""


@dataclass
class Page:
    """一次网页抓取的结果。"""

    url: str
    html: str = ""
    json_blobs: List[Any] = field(default_factory=list)
    via: str = ""          # http / render
    notes: List[str] = field(default_factory=list)


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------

def http_get(url: str, timeout: int = 30, headers: Optional[Dict[str, str]] = None) -> requests.Response:
    h = dict(BASE_HEADERS)
    if headers:
        h.update(headers)
    resp = requests.get(url, headers=h, timeout=timeout, allow_redirects=True)
    return resp


def _share_id(url: str, patterns: List[str]) -> str:
    for p in patterns:
        m = re.search(p, url, re.I)
        if m:
            return m.group(1)
    return ""


# --------------------------------------------------------------------------
# DeepSeek 官方分享接口
# --------------------------------------------------------------------------

def fetch_deepseek_api(url: str, timeout: int = 30) -> Tuple[Dict[str, Any], List[str]]:
    """DeepSeek 的分享内容有一个公开 GET 接口，直接拿结构化数据最稳。"""
    notes: List[str] = []
    sid = _share_id(url, [r"/share/([A-Za-z0-9_-]+)", r"share_id=([A-Za-z0-9_-]+)"])
    if not sid:
        raise FetchError("没能从链接里解析出 DeepSeek 的 share_id，请确认链接形如 "
                         "https://chat.deepseek.com/share/xxxx")

    api = "https://chat.deepseek.com/api/v0/share/content"
    resp = http_get(api, timeout=timeout, headers={
        "Accept": "application/json, text/plain, */*",
        "Referer": url,
        "x-app-version": "20241129.1",
        "x-client-platform": "web",
        "x-client-version": "1.0.0-always",
    })
    # 这个接口要求带 share_id 参数，这里用 params 再请求一次以兼容不同版本
    resp = requests.get(api, params={"share_id": sid}, headers=dict(BASE_HEADERS, **{
        "Accept": "application/json, text/plain, */*",
        "Referer": url,
    }), timeout=timeout)

    ctype = resp.headers.get("content-type", "")
    if "json" not in ctype.lower():
        raise FetchError("DeepSeek 接口没有返回 JSON（可能被风控拦截），已改用浏览器渲染。")
    try:
        payload = resp.json()
    except Exception as e:  # noqa: BLE001
        raise FetchError("DeepSeek 接口返回内容不是合法 JSON：%s" % e)

    code = payload.get("code")
    if code not in (0, None):
        msg = payload.get("msg") or payload.get("data") or ""
        raise FetchError("DeepSeek 接口报错：code=%s %s" % (code, str(msg)[:120]))
    if not (((payload.get("data") or {}).get("biz_data")) or {}):
        raise FetchError("DeepSeek 接口返回里没有对话数据（分享可能已失效或被设为私密）。")
    return payload, notes


# --------------------------------------------------------------------------
# 浏览器渲染
# --------------------------------------------------------------------------

def playwright_available() -> bool:
    try:
        import playwright  # noqa: F401
        from playwright.sync_api import sync_playwright
        return True
    except Exception:  # noqa: BLE001
        return False


def render_page(
    url: str,
    wait_ms: int = 6000,
    timeout_ms: int = 45000,
    headless: bool = True,
    scroll: bool = True,
) -> Page:
    """用 Playwright 打开页面，返回渲染后的 HTML + 截获的 JSON 响应。

    注意：这里**不解析内容**，只负责把原始素材搬回来。
    """
    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:  # noqa: BLE001
        raise FetchError("未安装 Playwright，无法使用浏览器渲染。安装方法：\n"
                         "  pip install playwright\n  playwright install chromium\n"
                         "原始错误：%s" % e)

    page_out = Page(url=url, via="render")
    captured: List[Any] = []

    def on_response(resp) -> None:  # noqa: ANN001
        try:
            rurl = resp.url
            low = rurl.lower()
            if any(n in low for n in _URL_NOISE):
                return
            ct = (resp.headers or {}).get("content-type", "")
            if "json" not in ct.lower():
                return
            body = resp.text()
            if not body or len(body) < 120:
                return
            if len(body) > 30 * 1024 * 1024:
                return
            captured.append(json.loads(body))
        except Exception:  # noqa: BLE001
            return

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=headless, args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-dev-shm-usage",
            ])
            ctx = browser.new_context(
                user_agent=UA,
                viewport={"width": 1440, "height": 1000},
                locale="zh-CN",
                timezone_id="Asia/Shanghai",
            )
            page = ctx.new_page()
            page.on("response", on_response)
            page.goto(url, wait_until="domcontentloaded", timeout=timeout_ms)
            # 等首屏异步数据回来
            try:
                page.wait_for_load_state("networkidle", timeout=min(15000, timeout_ms))
            except Exception:  # noqa: BLE001
                pass
            if scroll:
                # 有些页面是懒加载的，滚动几屏把内容勾出来
                try:
                    for _ in range(6):
                        page.mouse.wheel(0, 2400)
                        page.wait_for_timeout(500)
                    page.mouse.wheel(0, -50000)
                    page.wait_for_timeout(600)
                except Exception:  # noqa: BLE001
                    pass
            page.wait_for_timeout(wait_ms)
            page_out.html = page.content()
            try:
                page_out.title_hint = page.title()  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                pass
            browser.close()
    except FetchError:
        raise
    except Exception as e:  # noqa: BLE001
        raise FetchError("浏览器渲染失败：%s: %s" % (type(e).__name__, str(e)[:200]))

    page_out.json_blobs = captured
    if not page_out.html:
        raise FetchError("浏览器渲染完成但没有拿到页面内容。")
    return page_out


# --------------------------------------------------------------------------
# 总入口
# --------------------------------------------------------------------------

def fetch_conversation(
    url: str,
    allow_render: bool = True,
    headless: bool = True,
    wait_ms: int = 6000,
    timeout: int = 30,
    progress=None,
) -> Conversation:
    """把分享链接抓成 Conversation。

    progress: 可选回调 progress(str)，用于 GUI 显示进度。
    """
    def say(msg: str) -> None:
        if progress:
            try:
                progress(msg)
            except Exception:  # noqa: BLE001
                pass

    info = pf.detect(url)
    key = info["key"]
    name = info["name"]
    # 失败尝试的痕迹单独存：只有"所有通路都失败"时才写进文档。
    # 早期版本把每一轮的失败提示都塞进 conv.notes，于是成功导出的文档末尾
    # 会出现"页面里没有提取到任何对话内容"这种与事实矛盾的尾注。
    attempts: List[str] = []
    conv = Conversation(url=url, platform=key, platform_name=name)

    # ---- 通路 1：DeepSeek 官方接口 ----
    if key == "deepseek":
        say("正在调用 DeepSeek 分享接口…")
        try:
            payload, n = fetch_deepseek_api(url, timeout=timeout)
            title, model, msgs, n2 = ex.parse_deepseek_share(payload)
            if msgs:
                conv.title = title or conv.title
                conv.model = model
                conv.messages = msgs
                conv.source = "api"
                conv.notes.extend(n + n2)
                return conv.clean()
            attempts.extend(n2)
            say("接口没有返回消息，改用网页抓取…")
        except FetchError as e:
            attempts.append(str(e))
            say("接口方式不可用，改用网页抓取…")
        except Exception as e:  # noqa: BLE001
            attempts.append("接口抓取异常：%s: %s" % (type(e).__name__, str(e)[:120]))
            say("接口方式异常，改用网页抓取…")

    # ---- 通路 2：HTTP 直取 + 解析 ----
    html = ""
    say("正在直连网页…")
    try:
        resp = http_get(url, timeout=timeout)
        if resp.status_code >= 400:
            attempts.append("网页返回状态码 %d。" % resp.status_code)
        else:
            resp.encoding = resp.encoding or "utf-8"
            html = resp.text
    except Exception as e:  # noqa: BLE001
        attempts.append("直连网页失败：%s: %s" % (type(e).__name__, str(e)[:120]))

    if html:
        title, model, msgs, ns, via = ex.extract_from_html(html, key, url)
        if msgs and _is_meaningful(msgs):
            conv.title = title or conv.title
            conv.model = model
            conv.messages = msgs
            conv.source = via
            conv.notes.extend(ns)
            return conv.clean()
        attempts.extend(ns)
        if via in ("dom-fulltext", "none"):
            say("页面是前端渲染的空壳，改用浏览器渲染…")
        else:
            say("直连页面内容不足，改用浏览器渲染…")

    # ---- 通路 3：浏览器渲染 ----
    if not allow_render:
        conv.notes.extend(attempts + ["已禁用浏览器渲染，直连未取得内容。"])
        return conv.clean()

    if not playwright_available():
        conv.notes.extend(attempts + [
            "直连未取到内容，且本机没有安装 Playwright，无法渲染网页。",
            "安装方法：pip install playwright 然后 playwright install chromium",
        ])
        return conv.clean()

    say("正在用浏览器渲染页面（约 10~20 秒）…")
    try:
        page = render_page(url, wait_ms=wait_ms, headless=headless)
    except FetchError as e:
        conv.notes.extend(attempts + [str(e)])
        return conv.clean()

    rendered_html = page.html

    # 3a：先看截获的接口数据
    if page.json_blobs:
        say("正在解析页面接口数据…")
        adapter = ex.ADAPTERS.get(key)
        for blob in sorted(page.json_blobs, key=_blob_priority):
            if adapter:
                for cand in _candidate_subtrees(blob):
                    try:
                        title, model, msgs, ns = adapter(cand)
                    except Exception:  # noqa: BLE001
                        continue
                    if msgs and _is_meaningful(msgs):
                        conv.title = title or conv.title
                        conv.model = model
                        conv.messages = msgs
                        conv.source = "playwright-json"
                        conv.notes.extend(ns)
                        return conv.clean()
            msgs, ns = ex.extract_from_json(blob)
            if msgs and _is_meaningful(msgs):
                conv.messages = msgs
                conv.source = "playwright-json"
                conv.notes.extend(ns)
                return conv.clean()

    # 3b：再解析渲染后的 DOM
    say("正在解析渲染后的页面内容…")
    title, model, msgs, ns, via = ex.extract_from_html(rendered_html, key, url)
    if msgs and _is_meaningful(msgs):
        conv.title = title or conv.title
        conv.model = model
        conv.messages = msgs
        conv.source = "playwright-" + via
        conv.notes.extend(ns)
        return conv.clean()

    conv.notes.extend(attempts + ns + ["渲染后仍未提取到对话内容。"])
    if msgs:
        # 内容很少但也算有，交给用户判断
        conv.messages = msgs
        conv.source = "playwright-" + via
    return conv.clean()


def _is_meaningful(msgs: List[Message]) -> bool:
    """判断提取结果是不是"真的有内容"，避免把登录页/错误页当成对话。"""
    if not msgs:
        return False
    total = sum(len((m.content or "")) for m in msgs)
    if len(msgs) >= 2 and total >= 60:
        return True
    if total >= 200:
        return True
    return False


def _blob_priority(blob: Any) -> int:
    """越像对话的 JSON 越优先处理（按体积粗略排序，大的通常信息多）。"""
    try:
        return -len(json.dumps(blob, ensure_ascii=False, default=str))
    except Exception:  # noqa: BLE001
        return 0


def _candidate_subtrees(blob: Any, limit: int = 500) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if isinstance(blob, dict):
        out.append(blob)
    for d in ex._iter_dicts(blob):  # noqa: SLF001
        if len(out) >= limit:
            break
        out.append(d)
        for k in ("data", "biz_data", "conversation", "chat", "result", "payload", "props", "pageProps"):
            v = d.get(k) if isinstance(d, dict) else None
            if isinstance(v, dict) and v not in out:
                out.append(v)
            elif isinstance(v, list):
                for item in v[:20]:
                    if isinstance(item, dict):
                        out.append(item)
    return out
