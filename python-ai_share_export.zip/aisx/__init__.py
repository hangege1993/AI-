# -*- coding: utf-8 -*-
"""AI 对话导出助手（aisx）。

把一个 AI 对话平台的分享链接，转成排版干净、**公式可在 Word 里继续编辑**的文档。

快速上手：
    from aisx import convert_url
    r = convert_url("https://chat.deepseek.com/share/xxxx", out_dir="D:/导出")
    print(r.ok, r.files)

命令行：
    python -m aisx.cli "https://chat.deepseek.com/share/xxxx" -o D:/导出 -f docx,md

图形界面：
    双击「启动 AI对话转Word.bat」
"""

__version__ = "1.0.0"
__all__ = [
    "convert_url",
    "convert_many",
    "urls_from_text",
    "Conversation",
    "Message",
    "Result",
    "SUPPORTED_FORMATS",
    "PLATFORM_NAMES",
]

from .convert import Result, convert_many, convert_url, urls_from_text  # noqa: E402
from .exporters import SUPPORTED_FORMATS  # noqa: E402
from .models import Conversation, Message  # noqa: E402
from .platforms import PLATFORMS as _PL  # noqa: E402

#: {平台中文名: 平台标识}，供 GUI 展示用
PLATFORM_NAMES = {p["name"]: p["key"] for p in _PL}
