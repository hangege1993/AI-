# -*- coding: utf-8 -*-
"""Markdown → 结构化中间表示（IR）。

为什么要中间表示：
HTML 里能带样式，Markdown 里只有标记，而 Word 里是"样式 + 公式对象"。
中间隔一层 IR 之后，导出器只管"把 IR 画出来"，
以后要加 PDF/EPUB 导出只要再写一个渲染器，不用动解析。

IR 形状（都是纯 dict，方便调试）：
    块：{"t": "heading|para|code|list|table|quote|hr|math", ...}
    行内：{"t": "text|em|strong|code|link|math|br|image", ...}

公式保护
--------
Markdown 里的 `$` 有歧义（既可能是公式也可能是美元）。
这里用逐字符扫描器：跳过围栏代码块和行内代码，只在其外识别
`$$...$$`、`$...$`、`\\(...\\)`、`\\[...\\]`，
识别到就替换成纯字母数字占位符，交给 markdown-it 解析，
最后再把占位符还原成 math 行内/块。
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from markdown_it import MarkdownIt

from . import mathfix
from .htmlmd import MATHML_SENTINEL

_TOK = "AISXMTK%dZZ"
_TOK_RE = re.compile(r"AISXMTK(\d+)ZZ")

# 行内公式：$ 后不能是空白、$ 前不能是空白、内容里不能再有 $
_INLINE_DOLLAR = re.compile(r"(?<![\\$])\$(?!\s)([^$\n]{1,2000}?)(?<!\s)\$(?!\$)")

# 零宽字符：只有"浏览器渲染结果"才会带（KaTeX 的 vlist-s），
# 真 LaTeX 源码里不可能出现。用它当"这不是源码"的判据见 mathfix。
_ZW_RE = re.compile("[\u200b\u200c\u200d\u2060\ufeff\u00ad]")


def _make_md() -> MarkdownIt:
    md = MarkdownIt("commonmark", {"html": False, "linkify": False, "typographer": False})
    try:
        md.enable(["table", "strikethrough"])
    except Exception:  # noqa: BLE001
        pass
    return md


_MD = _make_md()


# --------------------------------------------------------------------------
# 一、公式保护扫描器
# --------------------------------------------------------------------------

def _protect(text: str) -> Tuple[str, Dict[str, Tuple[str, bool, str]]]:
    """扫描 Markdown，把公式抽成占位符。

    返回 (带占位符的文本, {占位符: (latex, 是否独立公式, mathml)})。
    mathml 非空表示"这段只有 MathML、没有 LaTeX 源码"（上游用哨兵标出来的），
    下游必须走 mathml_to_omml，不能当 LaTeX 喂给 latex2mathml。
    """
    table: Dict[str, Tuple[str, bool, str]] = {}
    out: List[str] = []
    n = len(text)
    i = 0
    counter = 0

    def add(body: str, display: bool) -> None:
        nonlocal counter
        body = body.strip()
        mathml = ""
        if body.startswith(MATHML_SENTINEL):
            mathml = body[len(MATHML_SENTINEL):].strip()
            body = ""
        tok = _TOK % counter
        counter += 1
        table[tok] = (body, display, mathml)
        out.append(tok)

    def absorb(body: str, display: bool) -> bool:
        """这段候选公式该不该收？收下返回 True。

        三道闸门，对应三类"看着像公式其实不是"的输入：
          1. 空内容 —— 不收；
          2. 带 MathML 哨兵 —— 收，但标记成 mathml 而不是 latex；
          3. 含零宽字符 —— 这是 KaTeX 渲染出来的字形串（vlist-s 撑高元素），
             **必须拒收**。它一旦被当成 LaTeX 喂下去，会生成一个"标签合法、
             内容全是散字形"的公式对象，比保留原文更糟：用户既看不懂也改不动。
        """
        b = body.strip()
        if not b:
            return False
        if b.startswith(MATHML_SENTINEL):
            add(b, display)
            return True
        if _ZW_RE.search(b):
            return False
        if display:
            add(b, True)
            return True
        if mathfix.looks_like_math(b):
            add(b, False)
            return True
        return False

    at_line_start = True
    while i < n:
        ch = text[i]

        # --- 围栏代码块：整段原样保留 ---
        if at_line_start and ch in "`~":
            m = re.match(r"^([`~]{3,})[^\n]*\n", text[i:])
            if m:
                fence = m.group(1)
                close = re.search(r"\n[ \t]*%s[ \t]*(?:\n|$)" % re.escape(fence), text[i + len(m.group(0)):])
                if close:
                    end = i + len(m.group(0)) + close.end()
                else:
                    end = n
                out.append(text[i:end])
                i = end
                at_line_start = True
                continue

        # --- 行内代码：原样保留 ---
        if ch == "`":
            m = re.match(r"(`+)", text[i:])
            ticks = m.group(1)
            close = text.find(ticks, i + len(ticks))
            if close != -1:
                end = close + len(ticks)
                out.append(text[i:end])
                i = end
                at_line_start = False
                continue

        # --- 独立公式 $$...$$ ---
        if text.startswith("$$", i):
            close = text.find("$$", i + 2)
            if close != -1 and absorb(text[i + 2:close], True):
                i = close + 2
                at_line_start = False
                continue

        # --- 独立公式 \[...\] ---
        if text.startswith("\\[", i):
            close = text.find("\\]", i + 2)
            if close != -1 and absorb(text[i + 2:close], True):
                i = close + 2
                at_line_start = False
                continue

        # --- 行内公式 \(...\) ---
        if text.startswith("\\(", i):
            close = text.find("\\)", i + 2)
            if close != -1 and absorb(text[i + 2:close], False):
                i = close + 2
                at_line_start = False
                continue

        # --- 行内公式 $...$ ---
        if ch == "$" and (i == 0 or text[i - 1] != "\\"):
            m = _INLINE_DOLLAR.match(text, i)
            if m and absorb(m.group(1), False):
                i = m.end()
                at_line_start = False
                continue

        out.append(ch)
        at_line_start = ch == "\n"
        i += 1

    return "".join(out), table


def _restore_inlines(children: List[Dict[str, Any]], table: Dict[str, Tuple[str, bool, str]]) -> List[Dict[str, Any]]:
    """把行内 token 序列里的占位符拆成真正的 math 行内元素。"""
    if not table:
        return children
    out: List[Dict[str, Any]] = []
    for c in children:
        if c.get("t") == "text" and _TOK_RE.search(c.get("text", "")):
            pos = 0
            txt = c["text"]
            for m in _TOK_RE.finditer(txt):
                if m.start() > pos:
                    piece = txt[pos:m.start()]
                    if piece:
                        out.append({"t": "text", "text": piece})
                item = table.get(m.group(0))
                if item:
                    latex, display, mathml = item
                    out.append({"t": "math", "latex": latex,
                                "display": display, "mathml": mathml})
                pos = m.end()
            if pos < len(txt):
                out.append({"t": "text", "text": txt[pos:]})
        else:
            out.append(c)
    return out


# --------------------------------------------------------------------------
# 二、行内解析
# --------------------------------------------------------------------------

def _parse_inlines(token: Any, table: Dict[str, Tuple[str, bool, str]]) -> List[Dict[str, Any]]:
    """把 markdown-it 的 inline token.children 转成 IR 行内序列。"""
    if token is None or not getattr(token, "children", None):
        return []
    out: List[Dict[str, Any]] = []
    stack: List[Dict[str, Any]] = []  # strong / em / link / s 容器
    pending_link: Optional[Dict[str, Any]] = None

    def push(item: Dict[str, Any]) -> None:
        if stack:
            stack[-1]["children"].append(item)
        else:
            out.append(item)

    for child in token.children:
        t = child.type
        if t == "text":
            push({"t": "text", "text": child.content})
            continue
        if t == "code_inline":
            push({"t": "code", "text": child.content})
            continue
        if t == "softbreak":
            push({"t": "text", "text": "\n"})
            continue
        if t == "hardbreak":
            push({"t": "br"})
            continue
        if t == "strong_open":
            node = {"t": "strong", "children": []}
            stack.append(node)
            continue
        if t == "em_open":
            node = {"t": "em", "children": []}
            stack.append(node)
            continue
        if t in ("strong_close", "em_close", "s_close"):
            if stack:
                done = stack.pop()
                push(done)
            continue
        if t == "s_open":
            node = {"t": "s", "children": []}
            stack.append(node)
            continue
        if t == "link_open":
            href = child.attrGet("href") or ""
            node = {"t": "link", "href": href, "children": []}
            stack.append(node)
            continue
        if t == "link_close":
            if stack:
                done = stack.pop()
                push(done)
            continue
        if t == "image":
            src = child.attrGet("src") or ""
            alt = child.content or ""
            push({"t": "image", "src": src, "alt": alt})
            continue
        if t == "html_inline":
            # 去掉标签，保留里面可能的文字
            txt = re.sub(r"<[^>]*>", "", child.content or "")
            if txt:
                push({"t": "text", "text": txt})
            continue

    # 未闭合的容器（容错）
    while stack:
        done = stack.pop()
        if stack:
            stack[-1]["children"].append(done)
        else:
            out.append(done)

    return _restore_inlines(out, table)


# --------------------------------------------------------------------------
# 三、块级解析
# --------------------------------------------------------------------------

def parse_markdown(md_text: str) -> Tuple[List[Dict[str, Any]], List[str]]:
    """Markdown → 块列表。返回 (blocks, notes)。"""
    notes: List[str] = []
    if not md_text or not md_text.strip():
        return [], notes

    protected, table = _protect(md_text)
    tokens = _MD.parse(protected)

    blocks: List[Dict[str, Any]] = []
    i = 0
    n = len(tokens)

    def parse_blocks(stop: str) -> List[Dict[str, Any]]:
        nonlocal i
        res: List[Dict[str, Any]] = []
        while i < n:
            tk = tokens[i]
            if tk.type == stop:
                return res
            res.extend(parse_one())
        return res

    def parse_one() -> List[Dict[str, Any]]:
        nonlocal i
        tk = tokens[i]
        t = tk.type

        if t == "heading_open":
            level = int(tk.tag[1]) if tk.tag[1:].isdigit() else 1
            inline = tokens[i + 1] if i + 1 < n else None
            inl = _parse_inlines(inline, table)
            i += 3
            return [{"t": "heading", "level": level, "inlines": _compact(inl)}]

        if t == "paragraph_open":
            inline = tokens[i + 1] if i + 1 < n else None
            inl = _compact(_parse_inlines(inline, table))
            i += 3
            # 整段只有一个独立公式 → 升级成公式块
            real = [x for x in inl if not (x["t"] == "text" and not x.get("text", "").strip())]
            if len(real) == 1 and real[0]["t"] == "math" and real[0].get("display"):
                return [{"t": "math", "latex": real[0].get("latex", ""),
                         "mathml": real[0].get("mathml", ""), "display": True}]
            if not real:
                return []
            return [{"t": "para", "inlines": inl}]

        if t in ("fence", "code_block"):
            lang = (getattr(tk, "info", "") or "").strip().split()[0] if getattr(tk, "info", "") else ""
            code = tk.content.rstrip("\n")
            i += 1
            return [{"t": "code", "lang": lang, "text": code}]

        if t == "hr":
            i += 1
            return [{"t": "hr"}]

        if t in ("bullet_list_open", "ordered_list_open"):
            ordered = t == "ordered_list_open"
            start = 1
            try:
                start = int(tk.attrGet("start") or 1)
            except Exception:  # noqa: BLE001
                start = 1
            i += 1
            items: List[List[Dict[str, Any]]] = []
            while i < n and tokens[i].type not in ("bullet_list_close", "ordered_list_close"):
                if tokens[i].type == "list_item_open":
                    i += 1
                    item_blocks: List[Dict[str, Any]] = []
                    while i < n and tokens[i].type != "list_item_close":
                        item_blocks.extend(parse_one())
                    i += 1
                    items.append(item_blocks)
                else:
                    i += 1
            i += 1
            return [{"t": "list", "ordered": ordered, "start": start, "items": items}]

        if t == "blockquote_open":
            i += 1
            inner = parse_blocks("blockquote_close")
            i += 1
            return [{"t": "quote", "blocks": inner}]

        if t == "table_open":
            i += 1
            header: List[List[Dict[str, Any]]] = []
            rows: List[List[List[Dict[str, Any]]]] = []
            aligns: List[str] = []
            cur_row: List[List[Dict[str, Any]]] = []
            in_head = False
            while i < n and tokens[i].type != "table_close":
                tt = tokens[i].type
                if tt == "thead_open":
                    in_head = True
                    i += 1
                    continue
                if tt == "thead_close":
                    in_head = False
                    i += 1
                    continue
                if tt in ("tbody_open", "tbody_close"):
                    i += 1
                    continue
                if tt == "tr_open":
                    cur_row = []
                    i += 1
                    continue
                if tt == "tr_close":
                    if in_head:
                        header = cur_row
                    else:
                        rows.append(cur_row)
                    i += 1
                    continue
                if tt in ("th_open", "td_open"):
                    style = tokens[i].attrGet("style") or ""
                    al = "left"
                    if "center" in style:
                        al = "center"
                    elif "right" in style:
                        al = "right"
                    aligns.append(al)
                    inline = tokens[i + 1] if i + 1 < n else None
                    cur_row.append(_compact(_parse_inlines(inline, table)))
                    i += 3
                    continue
                i += 1
            i += 1
            # 上面的三元表达式不好读，这里重新整理一遍表体
            return [{"t": "table", "header": header, "rows": rows, "aligns": aligns}]

        if t in ("html_block",):
            txt = re.sub(r"<[^>]*>", "", tk.content or "").strip()
            i += 1
            if txt:
                return [{"t": "para", "inlines": [{"t": "text", "text": txt}]}]
            return []

        # 未识别的 token 直接跳过，但如果是 inline 就当中文段落收下
        if t == "inline":
            inl = _compact(_parse_inlines(tk, table))
            i += 1
            if inl:
                return [{"t": "para", "inlines": inl}]
            return []

        i += 1
        return []

    blocks = parse_blocks("")
    blocks = _merge_adjacent(blocks)
    return blocks, notes


def _compact(inlines: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """合并相邻纯文本、丢掉空文本，让 IR 干净一点。"""
    out: List[Dict[str, Any]] = []
    for item in inlines:
        if item.get("t") == "text":
            txt = item.get("text", "")
            if not txt:
                continue
            if out and out[-1].get("t") == "text":
                out[-1]["text"] += txt
            else:
                out.append({"t": "text", "text": txt})
        else:
            out.append(item)
    if out and out[0].get("t") == "text":
        out[0]["text"] = out[0]["text"].lstrip("\n")
    if out and out[-1].get("t") == "text":
        out[-1]["text"] = out[-1]["text"].rstrip("\n")
    return [x for x in out if not (x.get("t") == "text" and not x.get("text"))]


def _merge_adjacent(blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """连续的引用块合并成一个，避免 Word 里出现一串碎引用。"""
    out: List[Dict[str, Any]] = []
    for b in blocks:
        if out and b.get("t") == "quote" and out[-1].get("t") == "quote":
            out[-1]["blocks"].extend(b["blocks"])
            continue
        out.append(b)
    return out
