# -*- coding: utf-8 -*-
"""公式保真模块 —— 本项目最核心的一块。

目标：任何来源的数学公式（LaTeX 源码 / KaTeX 的 annotation / MathJax / 原生 MathML）
都变成 Word 里的**原生公式对象（OMML）**，可以在 Word/WPS 里继续编辑，
而不是一张图片、也不是乱码文本。

管线：
    LaTeX  ──sanitize──▶ 合法 LaTeX ──latex2mathml──▶ MathML ──mathml2omml──▶ OMML
    MathML ────────────────────────────────────────▶ mathml2omml ──▶ OMML

已知坑（都在这里堵掉）：
1. latex2mathml 对 `aligned` / `split` / `multline` 这类"带 & 对齐符但不生成表格"
   的环境，会把 `&` 直接输出成 `<mi>&</mi>`，属于非法 XML，解析必炸。
   这里的做法是先把它们改写成能生成 mtable 的 `array` 环境。
2. `\\genfrac` 会抛 IndexError；降级成 `\\frac`。
3. `\\ce{}`（mhchem 化学式）不是标准数学，降级成普通文本。
4. 无论如何失败，都**不抛异常、不丢内容**：退回把 LaTeX 源串原样输出，
   并记录一条提示，保证用户拿到的文档至少能看到公式原文。
"""

from __future__ import annotations

import collections
import re
from typing import Any, List, Optional, Tuple

from latex2mathml.converter import convert as _latex_to_mathml
from mathml2omml import convert as _mathml_to_omml

M_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

# 需要重写为 array 的"对齐型"环境：latex2mathml 对它们处理有缺陷
_ALIGN_ENVS = ("aligned", "split", "multline", "gathered", "alignedat", "alignat")

# ---------------------------------------------------------------------------
# 零宽字符：KaTeX 渲染产物（HTML 套版）的"指纹"
# ---------------------------------------------------------------------------
# KaTeX 的 HTML 输出里，`<span class="vlist-s">` 这类"撑高元素"装的是零宽空格
# U+200B。这些字符的恶劣之处在于：`'\u200b'.isspace()` 是 False、
# `re.match(r'\s', ...)` 也匹配不到 —— 所有靠"空白"做的判断都会被它穿透，
# 于是"渲染后的字形串"会被误当成 LaTeX 源码喂进转换器。
# 因此：只要一段候选公式里出现它们，就说明它来自渲染层，不是源码。
_INVISIBLE_CHARS = "\u200b\u200c\u200d\u2060\ufeff\u00ad"
_INVISIBLE_RE = re.compile("[%s]" % _INVISIBLE_CHARS)

# 判定"这段是 KaTeX/MathJax 渲染出来的字形"而不是 LaTeX 源码：
# 含零宽字符，或含 Unicode 数学字形却没有任何 LaTeX 控制符。
# 注意：数学字母数字符号区是 U+1D400–U+1D7FF，必须写足 6 位十六进制；
# 写成 `\u1d400` 会被 Python 解析成 `\u1d40` + 字面量 '0'，
# 在字符类里拼出 `0-\u1d7f` 这种荒唐区间，把 ASCII 字母数字全部误吞。
_UNICODE_MATH_RE = re.compile(
    "[\u0370-\u03ff\u2190-\u22ff\u27c0-\u27ef\u2980-\u29ff\u2a00-\u2aff"
    "\U0001d400-\U0001d7ff\u00b1\u00d7\u00f7\u221a\u221e]"
)
_LATEX_SIGNAL_RE = re.compile(r"[\\^_{}]")


def strip_invisibles(s: str) -> str:
    """去掉零宽/格式控制字符。它们不该出现在任何数学内容里。"""
    if not s:
        return s
    return _INVISIBLE_RE.sub("", s)


def is_rendered_glyphs(expr: str) -> bool:
    """判断候选公式是不是"浏览器渲染出来的字形串"（而非 LaTeX 源码）。

    两个信号，命中其一即认定：
      1. 含零宽字符 —— 只有渲染层会产出（KaTeX 的 vlist-s 撑高元素）；
      2. 含 Unicode 数学字形，却一个 LaTeX 控制符都没有
         —— 例如 `β 1`、`≤ ; ∣`，这是 DOM 文本，不是源码。
    注意第 2 条只作"降级提示"，不用于拒绝：真有人手写 `$α+β$` 也该能渲染。
    """
    if not expr:
        return False
    if _INVISIBLE_RE.search(expr):
        return True
    return bool(_UNICODE_MATH_RE.search(expr)) and not _LATEX_SIGNAL_RE.search(expr)


# --------------------------------------------------------------------------
# 一、LaTeX 预处理
# --------------------------------------------------------------------------

def _count_cols(body: str) -> int:
    """统计对齐环境里最多有几列（按 & 个数 +1，忽略 \\& 转义）。"""
    rows = re.split(r"(?<!\\)\\\\", body)
    best = 1
    for r in rows:
        n = len(re.findall(r"(?<!\\)&", r)) + 1
        best = max(best, n)
    return best


def _rewrite_align_envs(s: str) -> str:
    """把 aligned / split / multline / gathered 改写成 array，绕开 latex2mathml 的 & 缺陷。"""
    if not re.search(r"\\begin\s*\{", s):
        return s

    def repl(m: "re.Match[str]") -> str:
        env = m.group(1).strip()
        body = m.group(2)
        if env not in _ALIGN_ENVS:
            return m.group(0)
        ncol = _count_cols(body)
        # amsmath 惯例：奇数列右对齐、偶数列左对齐
        spec = "".join("r" if i % 2 == 0 else "l" for i in range(ncol))
        # 行分隔符 \\ 与 latex2mathml 的 array 解析保持兼容
        return "\\begin{array}{%s}%s\\end{array}" % (spec, body)

    # 允许嵌套：先处理最内层，循环几次直到稳定
    pat = re.compile(r"\\begin\s*\{([A-Za-z*]+)\}(.*?)\\end\s*\{\1\}", re.S)
    for _ in range(4):
        new = pat.sub(repl, s)
        if new == s:
            break
        s = new
    return s


def sanitize_latex(s: str) -> str:
    """把各家平台产出的"野生 LaTeX"收拾成 latex2mathml 能吃的形态。

    只做无损或近无损的改写，绝不改变数学含义。
    """
    if not s:
        return ""
    t = s

    # 平台经常用全角/奇怪字符混进来。零宽字符必须最先清掉：
    # KaTeX 的撑高元素带 U+200B，它连 `\s` 都匹配不到，留着会污染后续所有判断。
    t = strip_invisibles(t)
    t = t.replace("\xa0", " ")
    t = t.replace("−", "-").replace("×", r"\times ").replace("÷", r"\div ")

    # 双重转义（JSON 里常见 \\\( 之类）
    t = t.replace("\\\\(", "\\(").replace("\\\\)", "\\)")
    t = t.replace("\\\\[", "\\[").replace("\\\\]", "\\]")

    # LaTeX 常规清洗：这些命令对渲染没有贡献，反而是兼容性雷区
    t = re.sub(r"\\(?:displaystyle|textstyle|scriptstyle|limits|nolimits)\b", "", t)
    t = re.sub(r"\\(?:nonumber|notag)\b", "", t)
    t = re.sub(r"\\label\s*\{[^{}]*\}", "", t)
    t = re.sub(r"\\hspace\*?\s*\{[^{}]*\}", r"\\;", t)
    t = re.sub(r"\\vspace\*?\s*\{[^{}]*\}", "", t)
    t = re.sub(r"\\allowbreak\b", "", t)
    t = re.sub(r"\\displaystyle\s*", "", t)
    # \tag{1} → 保留成行尾文本，latex2mathml 处理不了 tag 时会丢内容
    t = re.sub(r"\\tag\s*\{([^{}]*)\}", lambda m: r"\quad(%s)" % m.group(1).strip(), t)

    # \genfrac{..}{..}{..}{..}{a}{b} → \frac{a}{b}（latex2mathml 会 IndexError）
    t = re.sub(
        r"\\genfrac\s*\{[^{}]*\}\s*\{[^{}]*\}\s*\{[^{}]*\}\s*\{[^{}]*\}\s*\{([^{}]*)\}\s*\{([^{}]*)\}",
        r"\\frac{\1}{\2}",
        t,
    )
    # \ce{H2O} / \pu{..} 化学宏包 → 纯文本
    t = re.sub(r"\\(?:ce|pu|chemfig)\s*\{([^{}]*)\}", r"\\text{\1}", t)
    # \htmlClass{cls}{content} / \htmlId 等 KaTeX 专有宏 → 只要内容
    t = re.sub(r"\\htmlClass\s*\{[^{}]*\}\s*\{([^{}]*)\}", r"\1", t)
    t = re.sub(r"\\htmlId\s*\{[^{}]*\}\s*\{([^{}]*)\}", r"\1", t)
    t = re.sub(r"\\htmlStyle\s*\{[^{}]*\}\s*\{([^{}]*)\}", r"\1", t)
    t = re.sub(r"\\htmlData\s*\{[^{}]*\}\s*\{([^{}]*)\}", r"\1", t)
    # \class{..}{..} \style{..}{..}
    t = re.sub(r"\\(?:class|style|data)\s*\{[^{}]*\}\s*\{([^{}]*)\}", r"\1", t)

    # \substack 在 array 里不受支持，直接展平
    t = re.sub(r"\\substack\s*\{", "{", t)

    # 常见笔误/平台产物
    t = t.replace("\\dfrac", "\\frac").replace("\\tfrac", "\\frac")
    t = t.replace("\\cfrac", "\\frac")
    t = t.replace("\\mathop", "\\operatorname")
    t = t.replace("\\limits", "")
    t = re.sub(r"\\text\s*\{\s*\}", "", t)

    # 对齐环境的缺陷修补
    t = _rewrite_align_envs(t)

    # 括号升级为自动伸缩的定界符（必须放在其它改写之后、收尾之前）
    t = _autosize_delims(t)

    # 收尾：多余空白
    t = t.strip()
    t = re.sub(r"[ \t]{2,}", " ", t)
    return t


# --------------------------------------------------------------------------
# 括号 → \left...\right
# --------------------------------------------------------------------------
# 为什么要在 LaTeX 层做这件事：
#   latex2mathml 只在遇到 `\left(` / `\right)` 时才产出 OMML 的**定界符对象**
#   （<m:d> + begChr/endChr/grow）；普通的 `(` 只是一个字面字符 run，
#   既不会随内容长高，在 Word 里也不是可拉伸的括号。
#   对照程序（走渲染后的 MathML → pandoc/texmath）把普通括号也变成了 <m:d>，
#   所以它的公式"结构更完整"。我们的做法是在**源头**升级括号，
#   这样得到的 <m:d> 内容完整 —— 不会像对方那样把 `p||q` 里的 `‖`
#   变成一个空的 <m:e/>（那是它的真实缺陷，不能照抄）。
#
# 只处理 () [] \{\} 三类；**故意不碰 `|`**，因为竖线成对提升会丢内容。
_OPEN_TO_CLOSE = {"(": ")", "[": "]", "\\{": "\\}"}

# \left \right \big \Big \bigg \Bigg 及其 l/r 变体：紧跟其后的括号已经是定界符
_DELIM_PREFIX = re.compile(
    r"\\(?:biggl|biggr|Biggl|Biggr|bigl|bigr|Bigl|Bigr|bigg|Bigg|big|Big|left|right)\b\s*(?=.)"
)
_ANY_CMD = re.compile(r"\\(?:[A-Za-z]+|.)")

# 这些"文字环境"里的括号是自然语言括号，不该伸缩
_TEXT_ENVS = ("text", "textrm", "textit", "textbf", "textsf", "texttt",
              "textnormal", "mbox", "mathrm", "operatorname", "mathop")


def _mask_text_envs(s: str) -> Tuple[str, List[str]]:
    """把 \\text{...} 一类的整体挖出来换成占位符，避免动到里面的括号。"""
    pat = re.compile(r"\\(?:%s)\s*\{" % "|".join(_TEXT_ENVS))
    out: List[str] = []
    guard: List[str] = []
    i = 0
    n = len(s)
    while i < n:
        m = pat.match(s, i)
        if not m:
            out.append(s[i])
            i += 1
            continue
        depth = 1
        k = m.end()
        while k < n and depth:
            if s[k] == "\\":
                k += 2
                continue
            if s[k] == "{":
                depth += 1
            elif s[k] == "}":
                depth -= 1
                if depth == 0:
                    break
            k += 1
        if depth:                      # 括号不配对，放弃这一处
            out.append(s[i])
            i += 1
            continue
        guard.append(s[m.start():k + 1])
        out.append("\x02TEXENV%d\x02" % (len(guard) - 1))
        i = k + 1
    return "".join(out), guard


# 表格的列/行分隔符。\left...\right 不能跨单元格，所以配对的括号之间
# 一旦出现裸的 & 或 \\，就放弃这一对（宁可不动，也不能生成非法 LaTeX）。
_ROW_BREAK = re.compile(r"(?<!\\)&|(?<!\\)\\\\(?![A-Za-z])")


def _autosize_delims(latex: str) -> str:
    """把成对的 ( ) [ ] \\{ \\} 升级成 \\left...\\right，使其成为可伸缩定界符。

    安全性：
      * 已经带 \\left/\\right/\\big 等的括号跳过（靠 _DELIM_PREFIX 标记）；
      * \\text{} 一类文字环境里的括号跳过；
      * 只做**同类配对**，全局不配对就原样保留 —— 宁可不动，也不破坏语法；
      * 配对跨越表格的 & / \\\\ 时放弃（那样会生成非法 LaTeX）；
      * 只插入 \\left / \\right 两个命令，不删改任何原有内容。
    """
    if not latex:
        return latex
    if "(" not in latex and "[" not in latex and "\\{" not in latex:
        return latex

    masked, guard = _mask_text_envs(latex)
    n = len(masked)

    protected = set()
    for m in _DELIM_PREFIX.finditer(masked):
        protected.add(m.end())

    before: dict = {}                  # 位置 -> 插到该位置之前的文本
    stack: List[Tuple[int, str]] = []  # [(左括号位置, 左括号记号)]

    def _pair(pos: int, close_pos: int, op: str) -> None:
        seg = masked[pos + len(op):close_pos]
        if _ROW_BREAK.search(seg):
            return
        before[pos] = "\\left"
        before[close_pos] = "\\right"

    i = 0
    while i < n:
        ch = masked[i]
        if ch == "\\":
            m = _ANY_CMD.match(masked, i)
            if not m:
                i += 1
                continue
            cmd = m.group(0)
            if cmd in ("\\{", "\\}"):
                if i not in protected:
                    if cmd == "\\{":
                        stack.append((i, cmd))
                    else:
                        for k in range(len(stack) - 1, -1, -1):
                            if stack[k][1] == "\\{":
                                pos, op = stack.pop(k)
                                _pair(pos, i, op)
                                break
            i = m.end()
            continue
        if ch in "([":
            if i not in protected:
                stack.append((i, ch))
            i += 1
            continue
        if ch in ")]":
            if i not in protected:
                for k in range(len(stack) - 1, -1, -1):
                    if _OPEN_TO_CLOSE.get(stack[k][1]) == ch:
                        pos, op = stack.pop(k)
                        _pair(pos, i, op)
                        break
            i += 1
            continue
        i += 1

    if not before:
        return latex

    out: List[str] = []
    for idx in range(n):
        if idx in before:
            out.append(before[idx])
        out.append(masked[idx])
    res = "".join(out)

    # 还原被挖走的文字环境
    for gi, original in enumerate(guard):
        res = res.replace("\x02TEXENV%d\x02" % gi, original)
    return res


# --------------------------------------------------------------------------
# 二、转换
# --------------------------------------------------------------------------

_STRAY_AMP = re.compile(r"&(?![A-Za-z][A-Za-z0-9]*;|#\d+;|#x[0-9A-Fa-f]+;)")


def _escape_stray_amp(mathml: str) -> str:
    """MathML 里出现未被转义的裸 & 会让 XML 解析失败，这里补转义。"""
    if "&" not in mathml:
        return mathml
    return _STRAY_AMP.sub("&amp;", mathml)


def _omml_has_content(omml: Optional[str]) -> bool:
    if not omml:
        return False
    return bool(re.search(r"<m:t[ >]", omml)) or "<m:f>" in omml or "<m:rad>" in omml


# ---------------------------------------------------------------------------
# mathml2omml 的已知缺陷修补
# ---------------------------------------------------------------------------
# 库在处理 MathML 的 <mover>/<munder>（对应 LaTeX 的 \vec \bar \overbrace
# \underbrace \overrightarrow ...）时，会把 <m:groupChrPr> 的收尾标签错写成
# </m:groupChr>，产出非法 XML，解析必然失败。
# 由于这些符号在物理公式里出现频率极高，这里统一修掉。
_GROUPCHR_BUG = re.compile(r"(<m:groupChrPr>(?:(?!</?m:groupChr[ >]).)*?)</m:groupChr>", re.S)

_TAG_OPEN = re.compile(r"<(m:[A-Za-z0-9]+)(?:\s[^>]*)?(?<!/)>")
_TAG_SELF = re.compile(r"<(m:[A-Za-z0-9]+)(?:\s[^>]*)?/>")
_TAG_CLOSE = re.compile(r"</(m:[A-Za-z0-9]+)>")


def repair_omml(omml: str) -> Tuple[str, int]:
    """修掉 mathml2omml 产出的已知非法标签写法，返回 (修正后的, 修正次数)。"""
    if not omml:
        return omml, 0
    fixed, n = _GROUPCHR_BUG.subn(r"\1</m:groupChrPr>", omml)
    return fixed, n


def omml_is_balanced(omml: str) -> bool:
    """检查 OMML 的标签是否配对；不配对就说明文档会打不开，必须拦下。"""
    if not omml:
        return False
    opens = collections.Counter(_TAG_OPEN.findall(omml)) - collections.Counter(_TAG_SELF.findall(omml))
    closes = collections.Counter(_TAG_CLOSE.findall(omml))
    return all(opens[k] == closes.get(k, 0) for k in set(opens) | set(closes))


# ---------------------------------------------------------------------------
# OMML 规范化：把 mathml2omml 的"方言"对齐到 Office 原生写法
# ---------------------------------------------------------------------------
# 背景（2026-09-20 实测，对照对象是 pandoc 3.9 / texmath 的输出）：
#   1. mathml2omml 会把 MathML 的每个 <mrow> 都包成 <m:box>。
#      而 <m:box> 在 OMML 里是"给公式套一个可见框"，不是分组。
#      实例：`x` 一个字母也产出 <m:box><m:e><m:r>…</m:r></m:e></m:box>。
#      对照文档里 m:box = 0，我们是一堆 —— 结构上就不干净。
#      这些 box 都没有 <m:boxPr>（即无任何属性），是纯包裹，剥掉是无损的。
#   2. <m:d>（定界符）缺 <m:sepChr> 与 <m:grow>；缺 grow 的括号不会随内容长高。
#   3. 重音：`\vec` / `\bar` / `\hat` 分别被映射成 m:groupChr(→) /
#      m:groupChr(¯) / m:limUpp(^)。Office 与 pandoc 的规范写法是 m:acc
#      （Unicode 组合重音字符），只有"跨多个符号的组字符"（如 \overbrace）
#      才该用 m:groupChr。
#
# 本函数只做结构改写，不改变数学含义；纯字符串处理，可重复执行（幂等）。

_TOKEN_RE = re.compile(r"<(/?)(m:[A-Za-z0-9]+)((?:\s[^>]*?)?)(/?)>", re.S)

# 组字符（m:groupChr 的 chr）→ 组合重音字符（m:acc 的 chr）
_ACCENT_MAP = {
    "→": "\u20d7",   # \vec / \overrightarrow
    "←": "\u20d6",   # \overleftarrow
    "¯": "\u0304",   # \bar（KaTeX 用 spacing macron）
    "‾": "\u0304",
    "^": "\u0302",   # \hat
    "ˆ": "\u0302",
    "~": "\u0303",   # \tilde
    "˜": "\u0303",
    "˙": "\u0307",   # \dot
    ".": "\u0307",
    "¨": "\u0308",   # \ddot
    "\u02d9": "\u0307",
}

# m:limUpp 的 lim 是这些"重音符号"时，说明它其实是重音而不是上极限
_LIMUPP_ACCENT = {
    "^": "\u0302", "ˆ": "\u0302", "~": "\u0303", "˜": "\u0303",
    "¯": "\u0304", "‾": "\u0304", "˙": "\u0307", "\u02d9": "\u0307",
    ".": "\u0307", "¨": "\u0308", "→": "\u20d7", "←": "\u20d6",
}


def _parse_tree(xml: str) -> List[Any]:
    """把 OMML 解析成轻量树，用于安全的原地改写。

    节点形状：["root", "", "", [子节点]]
              ["elem", 标签名, 属性串, [子节点], 是否自闭合]
              ["text", 原始文本]
    属性串保留原始写法（含前导空格），保证回写后与输入逐字节一致。
    """
    root: List[Any] = ["root", "", "", []]
    stack: List[List[Any]] = [root]
    pos = 0
    for m in _TOKEN_RE.finditer(xml):
        if m.start() > pos:
            txt = xml[pos:m.start()]
            if txt:
                stack[-1][3].append(["text", txt])
        pos = m.end()
        closing, name, attrs, selfclose = m.group(1), m.group(2), m.group(3), m.group(4)
        if closing:
            if len(stack) > 1:
                stack.pop()
            continue
        node = ["elem", name, attrs, [], bool(selfclose)]
        stack[-1][3].append(node)
        if not selfclose:
            stack.append(node)
    if pos < len(xml):
        tail = xml[pos:]
        if tail:
            stack[-1][3].append(["text", tail])
    return root


def _serialize(node: List[Any]) -> str:
    kind = node[0]
    if kind == "text":
        return node[1]
    if kind == "root":
        return "".join(_serialize(c) for c in node[3])
    name, attrs, children = node[1], node[2], node[3]
    if not children:
        return "<%s%s/>" % (name, attrs) if node[4] else "<%s%s></%s>" % (name, attrs, name)
    return "<%s%s>%s</%s>" % (name, attrs, "".join(_serialize(c) for c in children), name)


def _elems(node: List[Any], name: str = "") -> List[List[Any]]:
    """按插入序收集后代元素（可选按标签名过滤）。"""
    out: List[List[Any]] = []
    for c in node[3]:
        if c[0] != "elem":
            continue
        if not name or c[1] == name:
            out.append(c)
        out.extend(_elems(c, name))
    return out


def _direct(node: List[Any], name: str) -> Optional[List[Any]]:
    for c in node[3]:
        if c[0] == "elem" and c[1] == name:
            return c
    return None


def _chardata(node: Optional[List[Any]]) -> str:
    """取元素下所有文字（含嵌套），用于读 <m:lim><m:t>^</m:t></m:lim> 这类内容。"""
    if node is None:
        return ""
    out: List[str] = []
    for c in node[3]:
        if c[0] == "text":
            out.append(c[1])
        elif c[0] == "elem":
            out.append(_chardata(c))
    return "".join(out)


def _attr_val(node: List[Any], attr: str) -> str:
    m = re.search(r'%s\s*=\s*"([^"]*)"' % re.escape(attr), node[2] or "")
    return m.group(1) if m else ""


def _mk_elem(name: str, children: List[Any], attrs: str = "") -> List[Any]:
    # 空元素写成自闭合，与 Office/pandoc 的写法一致
    return ["elem", name, attrs, children, not children]


def _tx_sty(node: List[Any], stats: dict) -> None:
    """去掉冗余的 <m:rPr><m:sty m:val="i"/></m:rPr>。

    OOXML 里 m:sty 的**默认值就是 "i"**（数学区内的 run 默认斜体），
    所以显式声明一遍是废话。对照程序（texmath）只在**非斜体**时写 sty
    （正体写 p、粗斜体写 bi），因此它的 sty 总数远小于 run 总数。
    去掉之后渲染结果完全一致，但结构和对方一致、体积也更小。
    """
    for c in node[3]:
        if c[0] == "elem":
            _tx_sty(c, stats)
    out: List[Any] = []
    for c in node[3]:
        if c[0] == "elem" and c[1] == "m:rPr":
            kids = [k for k in c[3] if k[0] == "elem"]
            if len(kids) == 1 and kids[0][1] == "m:sty" and _attr_val(kids[0], "m:val") == "i":
                stats["sty_i"] = stats.get("sty_i", 0) + 1
                continue
        out.append(c)
    node[3] = out


def _tx_box(node: List[Any], stats: dict) -> None:
    """剥掉无属性的 <m:box>（纯包裹），保留有 <m:boxPr> 的。"""
    out: List[Any] = []
    for c in node[3]:
        if c[0] == "elem":
            _tx_box(c, stats)
        if c[0] == "elem" and c[1] == "m:box" and _direct(c, "m:boxPr") is None:
            body = _direct(c, "m:e")
            inner = body[3] if body is not None else [x for x in c[3] if x[0] != "text"]
            out.extend(inner)
            stats["box"] = stats.get("box", 0) + 1
            continue
        out.append(c)
    node[3] = out


def _tx_delims(node: List[Any], stats: dict) -> None:
    """给 <m:d> 的 <m:dPr> 补上 sepChr / grow（否则括号不随内容长高）。"""
    for c in node[3]:
        if c[0] == "elem":
            _tx_delims(c, stats)
    if node[0] != "elem" or node[1] != "m:d":
        return
    pr = _direct(node, "m:dPr")
    if pr is None:
        pr = _mk_elem("m:dPr", [])
        node[3].insert(0, pr)
    have = {c[1] for c in pr[3] if c[0] == "elem"}
    if "m:begChr" not in have:
        pr[3].append(_mk_elem("m:begChr", [], ' m:val="("'))
    if "m:sepChr" not in have:
        pr[3].append(_mk_elem("m:sepChr", [], ' m:val=""'))
    if "m:endChr" not in have:
        pr[3].append(_mk_elem("m:endChr", [], ' m:val=")"'))
    if "m:grow" not in have:
        pr[3].append(["elem", "m:grow", "", [], True])
    # 子元素顺序按 OOXML schema 归位：begChr / sepChr / endChr / grow / shp / ctrlPr
    order = ["m:begChr", "m:sepChr", "m:endChr", "m:grow", "m:shp", "m:ctrlPr"]
    pr[3].sort(key=lambda c: order.index(c[1]) if c[0] == "elem" and c[1] in order else 99)
    stats["d"] = stats.get("d", 0) + 1


def _as_single_run(node: List[Any]) -> bool:
    """m:e 里是不是"恰好一个 m:r"（单符号重音才适合转 m:acc）。"""
    body = _direct(node, "m:e")
    if body is None:
        return False
    kids = [c for c in body[3] if c[0] == "elem"]
    return len(kids) == 1 and kids[0][1] == "m:r"


def _tx_accents(node: List[Any], stats: dict) -> None:
    """把"单符号重音"从 m:groupChr / m:limUpp 改写成规范的 m:acc。"""
    out: List[Any] = []
    for c in node[3]:
        if c[0] != "elem":
            out.append(c)
            continue
        _tx_accents(c, stats)
        if c[1] == "m:groupChr" and _as_single_run(c):
            pr = _direct(c, "m:groupChrPr")
            chr_val = _attr_val(_direct(pr, "m:chr"), "m:val") if pr is not None else ""
            pos = _attr_val(_direct(pr, "m:pos"), "m:val") if pr is not None else "top"
            combining = _ACCENT_MAP.get(chr_val)
            if combining and pos in ("top", ""):
                body = _direct(c, "m:e")
                acc = _mk_elem(
                    "m:acc",
                    [_mk_elem("m:accPr", [_mk_elem("m:chr", [], ' m:val="%s"' % combining)]),
                     _mk_elem("m:e", body[3] if body is not None else [])],
                )
                out.append(acc)
                stats["acc"] = stats.get("acc", 0) + 1
                continue
        if c[1] == "m:limUpp":
            lim = _direct(c, "m:lim")
            lim_txt = _chardata(lim).strip() if lim is not None else ""
            body = _direct(c, "m:e")
            combining = _LIMUPP_ACCENT.get(lim_txt)
            if combining and body is not None and len([x for x in body[3] if x[0] == "elem"]) == 1:
                acc = _mk_elem(
                    "m:acc",
                    [_mk_elem("m:accPr", [_mk_elem("m:chr", [], ' m:val="%s"' % combining)]),
                     _mk_elem("m:e", body[3])],
                )
                out.append(acc)
                stats["acc"] = stats.get("acc", 0) + 1
                continue
        out.append(c)
    node[3] = out


def _tx_nary(node: List[Any], stats: dict) -> None:
    """给 <m:naryPr> 补 subHide / supHide，与 Office 原生写法对齐。"""
    for c in node[3]:
        if c[0] == "elem":
            _tx_nary(c, stats)
    if node[0] != "elem" or node[1] != "m:nary":
        return
    pr = _direct(node, "m:naryPr")
    if pr is None:
        return
    have = {c[1] for c in pr[3] if c[0] == "elem"}
    has_sub = _direct(node, "m:sub") is not None
    has_sup = _direct(node, "m:sup") is not None
    if "m:subHide" not in have:
        pr[3].append(_mk_elem("m:subHide", [], ' m:val="%s"' % ("off" if has_sub else "on")))
    if "m:supHide" not in have:
        pr[3].append(_mk_elem("m:supHide", [], ' m:val="%s"' % ("off" if has_sup else "on")))
    order = ["m:chr", "m:limLoc", "m:grow", "m:subHide", "m:supHide", "m:ctrlPr"]
    pr[3].sort(key=lambda c: order.index(c[1]) if c[0] == "elem" and c[1] in order else 99)
    stats["nary"] = stats.get("nary", 0) + 1


def normalize_omml(omml: str) -> Tuple[str, dict]:
    """把 mathml2omml 的 OMML 方言对齐到 Office 原生写法。返回 (新 OMML, 统计)。

    幂等、无损：只剥"无属性包裹层"、补 schema 要求缺省的元素、把重音换成 m:acc。
    输入必须是标签配对的 OMML；不配对时原样返回，交给上游的 omml_is_balanced 拦截。
    """
    stats: dict = {}
    if not omml or not omml.strip() or not omml_is_balanced(omml):
        return omml, stats
    tree = _parse_tree(omml)
    _tx_box(tree, stats)
    _tx_sty(tree, stats)
    _tx_delims(tree, stats)
    _tx_accents(tree, stats)
    _tx_nary(tree, stats)
    out = _serialize(tree)
    if not omml_is_balanced(out):
        # 理论上不会发生；万一发生就放弃规范化，保住"能打开"这条底线
        return omml, {}
    stats["chars_before"] = len(omml)
    stats["chars_after"] = len(out)
    return out, stats



def latex_to_omml(latex: str, display: bool = False) -> Tuple[Optional[str], List[str]]:
    """LaTeX → OMML。

    返回 (omml_xml, notes)。omml_xml 为 None 表示转换失败，调用方应降级为文本输出。
    返回的 XML 已经带好 m: 命名空间声明，可直接塞进 python-docx 段落。
    """
    notes: List[str] = []
    if not latex or not latex.strip():
        return None, notes

    attempts = [sanitize_latex(latex)]
    # 第二遍：更激进的清洗，只在第一遍失败时执行
    aggressive = attempts[0]
    aggressive = re.sub(r"\\begin\s*\{[A-Za-z*]+\}\s*(?:\{[^{}]*\})?", "", aggressive)
    aggressive = re.sub(r"\\end\s*\{[A-Za-z*]+\}", "", aggressive)
    aggressive = re.sub(r"\\(?:begin|end)\s*\{[^{}]*\}", "", aggressive)
    if aggressive.strip() and aggressive != attempts[0]:
        attempts.append(aggressive)

    last_err = ""
    for idx, expr in enumerate(attempts):
        try:
            mathml = _latex_to_mathml(expr)
        except Exception as e:  # noqa: BLE001
            last_err = "latex2mathml: %s: %s" % (type(e).__name__, e)
            continue
        try:
            mathml = _escape_stray_amp(mathml)
            omml = _mathml_to_omml(mathml)
        except Exception as e:  # noqa: BLE001
            last_err = "mathml2omml: %s: %s" % (type(e).__name__, e)
            continue
        omml, nfix = repair_omml(omml)
        if not omml_is_balanced(omml):
            last_err = "生成的 OMML 标签不配对（已拦下，避免文档损坏）"
            continue
        omml, norm_stats = normalize_omml(omml)
        if not _omml_has_content(omml):
            last_err = "空公式"
            continue
        if idx > 0:
            notes.append("公式含不兼容语法，已简化后渲染：%s" % latex.strip()[:60])
        return omml, notes

    notes.append("公式无法转换，已按原文输出 LaTeX：%s" % (latex.strip()[:60] or "空"))
    if last_err:
        notes.append("转换错误：%s" % last_err[:120])
    return None, notes


def mathml_to_omml(mathml: str) -> Tuple[Optional[str], List[str]]:
    """原生 MathML → OMML（某些平台只给 MathML，不给 LaTeX 源码）。"""
    notes: List[str] = []
    if not mathml or not mathml.strip():
        return None, notes
    try:
        omml = _mathml_to_omml(_escape_stray_amp(mathml))
    except Exception as e:  # noqa: BLE001
        notes.append("MathML 转换失败：%s: %s" % (type(e).__name__, str(e)[:100]))
        return None, notes
    omml, _nfix = repair_omml(omml)
    if not omml_is_balanced(omml):
        notes.append("MathML 转换出的 OMML 标签不配对，已跳过。")
        return None, notes
    omml, _st = normalize_omml(omml)
    if not _omml_has_content(omml):
        return None, notes
    return omml, notes


def wrap_omml(omml_inner: str, display: bool = False) -> str:
    """给 mathml2omml 的输出补命名空间，并按行内/独立公式包装成可插入的 XML。"""
    inner = omml_inner.strip()
    # mathml2omml 返回的是 <m:oMath>...</m:oMath>
    if inner.startswith("<m:oMath>"):
        inner = "<m:oMath xmlns:m=\"%s\">%s" % (M_NS, inner[len("<m:oMath>"):])
    elif "<m:oMath" not in inner:
        inner = "<m:oMath xmlns:m=\"%s\">%s</m:oMath>" % (M_NS, inner)
    elif "xmlns:m=" not in inner:
        inner = inner.replace("<m:oMath", "<m:oMath xmlns:m=\"%s\"" % M_NS, 1)

    if not display:
        return inner

    return (
        '<m:oMathPara xmlns:m="{m}" xmlns:w="{w}">'
        '<m:oMathParaPr><m:jc m:val="center"/></m:oMathParaPr>'
        "{inner}"
        "</m:oMathPara>"
    ).format(m=M_NS, w=W_NS, inner=inner)


# --------------------------------------------------------------------------
# 三、分隔符归一化
# --------------------------------------------------------------------------

# 行内：$ ... $（开 $ 后不能是空白，闭 $ 前不能是空白，内容里不能再有 $）
INLINE_DOLLAR = re.compile(r"(?<![\\$])\$(?!\s)([^$\n]+?)(?<!\s)\$(?!\$)")
# 独立：$$ ... $$
DISPLAY_DOLLAR = re.compile(r"\$\$(.+?)\$\$", re.S)
# LaTeX 原生分隔符
DISPLAY_PAREN = re.compile(r"\\\[(.+?)\\\]", re.S)
INLINE_PAREN = re.compile(r"\\\((.+?)\\\)", re.S)


def normalize_delims(text: str) -> str:
    """把 `\\(...\\)` / `\\[...\\]` 统一成 `$...$` / `$$...$$`，方便后续单一路径处理。

    注意：只在非代码区域做。调用方（mdparse）负责先把代码块摘出去。
    """
    if not text:
        return text
    t = text
    t = DISPLAY_PAREN.sub(lambda m: "\n$$\n%s\n$$\n" % m.group(1).strip(), t)
    t = INLINE_PAREN.sub(lambda m: "$%s$" % m.group(1).strip(), t)
    return t


def looks_like_math(expr: str) -> bool:
    """判断 $...$ 里包的是不是真公式，避免把 "$5 and $10" 这种当公式。

    关键闸门：含零宽字符的候选**一律判否**。KaTeX 的渲染产物（vlist-s 撑高
    元素）会带 U+200B，而 `$β 1 \\u200b$` 这种串一旦被当成 LaTeX 喂下去，
    会变成一个"结构上合法、内容全是散字形"的公式对象 —— 比保留原文更糟。
    判否之后它就留在正文里当普通文字，用户看得见、也删得掉。
    """
    if not expr or not expr.strip():
        return False
    if _INVISIBLE_RE.search(expr):
        return False
    e = expr.strip()
    if len(e) > 3000:
        return False
    # 含 LaTeX 特征 → 是公式
    if re.search(r"[\\^_{}]", e):
        return True
    # 纯中文/纯数字/普通句子 → 不是
    if re.search(r"[\u4e00-\u9fff]", e) and "\\" not in e:
        return False
    if re.fullmatch(r"[\d\s.,%]+", e):
        return False
    # Unicode 数学字形（希腊字母、≤、∑、∫ 等）：这是"真·Unicode 数学"，
    # 不是渲染产物（渲染产物已在上面按零宽字符拦掉），应当渲染。
    if _UNICODE_MATH_RE.search(e):
        return True
    # 含字母且长度合理 → 倾向认定是公式（如 $E=mc^2$ 已被上面命中，这里兜底 $x$）
    if re.fullmatch(r"[A-Za-z]{1,12}", e):
        return True
    if re.search(r"[A-Za-z]", e) and len(e) <= 120:
        return True
    return False
