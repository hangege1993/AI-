# -*- coding: utf-8 -*-
"""除 Word 之外的其它导出格式，以及各种格式之间的公共拼装。

支持：
* **docx** —— 主输出，公式是原生对象
* **md**   —— 带 YAML 元信息的 Markdown，公式保持 LaTeX 原文
* **html** —— 自带样式、**内置 MathJax（离线可渲染公式）** 的单文件网页，可浏览器打印成 PDF
* **txt**  —— 纯文本，公式退化为 LaTeX 原文，方便丢给别的工具
* **json** —— 结构化数据，方便二次处理
"""

from __future__ import annotations

import html as _html
import json
import os
import re
from datetime import datetime
from typing import Any, Dict, List, Optional

from markdown_it import MarkdownIt

from .models import Conversation, Message

# --------------------------------------------------------------------------
# 拼装：把 Conversation 变成一个干净的 Markdown 全文
# --------------------------------------------------------------------------

def conversation_to_markdown(conv: Conversation, *, front_matter: bool = True,
                             include_thinking: bool = False) -> str:
    parts: List[str] = []
    if front_matter:
        parts.append("---")
        parts.append("title: %s" % _yaml_escape(conv.title))
        parts.append("platform: %s" % (conv.platform_name or conv.platform))
        if conv.model:
            parts.append("model: %s" % _yaml_escape(conv.model))
        parts.append("source_url: %s" % conv.url)
        parts.append("fetched_at: %s" % conv.fetched_at)
        parts.append("messages: %d" % len(conv.messages))
        parts.append("---")
        parts.append("")

    parts.append("# %s" % (conv.title or "AI 对话记录"))
    parts.append("")

    meta_bits = []
    if conv.platform_name:
        meta_bits.append("**平台**：%s" % conv.platform_name)
    if conv.model:
        meta_bits.append("**模型**：%s" % conv.model)
    meta_bits.append("**消息数**：%d" % len(conv.messages))
    if conv.url:
        meta_bits.append("**原始链接**：%s" % conv.url)
    parts.append("  \n".join(meta_bits))
    parts.append("")

    for i, m in enumerate(conv.messages):
        label = "用户" if m.role == "user" else ("系统" if m.role == "system" else "AI 回答")
        parts.append("## %s %s" % ("👤" if m.role == "user" else "🤖", label))
        parts.append("")
        parts.append(m.content.strip())
        parts.append("")
        if include_thinking and m.thinking.strip():
            parts.append("<details>\n<summary>思考过程</summary>\n")
            parts.append(m.thinking.strip())
            parts.append("\n</details>\n")

    if conv.notes:
        parts.append("---")
        parts.append("")
        parts.append("### 导出说明")
        parts.append("")
        for n in conv.notes:
            if n and n.strip():
                parts.append("- %s" % n)
        parts.append("")
    return "\n".join(parts)


def _yaml_escape(s: str) -> str:
    s = (s or "").replace("\n", " ").strip()
    if re.search(r"[:#\[\]{}&*!|>'\"%@`]", s):
        return '"%s"' % s.replace('"', '\\"')
    return s


# --------------------------------------------------------------------------
# 公式保护：先把 $...$ / $$...$$ 抽成占位符，再交给 Markdown 渲染器。
#
# 为什么必须这么做：Markdown 把 `_` 当强调符、把 `\` 当转义符。公式里的
# `\boldsymbol{\alpha}_N^{[x_{N-1}]}` 会被拆成
# `\boldsymbol{\alpha}<em>N^{[x</em>{N-1}]}` —— LaTeX 直接被改坏，
# 前端 MathJax 随后解析失败，于是整条公式退化成一行 $$ 原文。
# 只含单个下标的公式不会成对，反而侥幸没事，所以症状是「有些公式正常、
# 有些是原文」。渲染完再把占位符换回原样即可。
# --------------------------------------------------------------------------

_MATH_PH = "AISXMATHPLACEHOLDER%dZZ"
_MATH_PH_RE = re.compile(r"AISXMATHPLACEHOLDER(\d+)ZZ")

_MATH_DISPLAY_RES = (
    re.compile(r"\$\$(.+?)\$\$", re.S),
    re.compile(r"\\\[(.+?)\\\]", re.S),
)
_MATH_INLINE_RES = (
    re.compile(r"(?<!\$)\$(?!\$)(.+?)(?<!\$)\$(?!\$)", re.S),
    re.compile(r"\\\((.+?)\\\)", re.S),
)


def _protect_math(text: str):
    """把公式换成占位符。返回 (受保护的文本, table)。

    table: 占位符 -> (latex 源码, 是否独立公式)
    """
    table: Dict[str, Any] = {}
    counter = [0]

    def _make_repl(display: bool):
        def _repl(m: "re.Match[str]") -> str:
            tok = _MATH_PH % counter[0]
            counter[0] += 1
            table[tok] = (m.group(1), display)
            return tok
        return _repl

    out = text
    for rx in _MATH_DISPLAY_RES:
        out = rx.sub(_make_repl(True), out)
    for rx in _MATH_INLINE_RES:
        out = rx.sub(_make_repl(False), out)
    return out, table


def _restore_math(html_text: str, table: Dict[str, Any]) -> str:
    """把占位符换回带定界符的公式（HTML 转义，交给 MathJax 渲染）。"""
    if not table:
        return html_text

    def _repl(m: "re.Match[str]") -> str:
        item = table.get(m.group(0))
        if not item:
            return ""
        tex, display = item
        body = _html.escape(tex.strip(), quote=False)
        return ("$$%s$$" % body) if display else ("$%s$" % body)

    return _MATH_PH_RE.sub(_repl, html_text)


# --------------------------------------------------------------------------
# MathJax：优先内联随包资源（离线可渲染），缺资源时退回 CDN。
# --------------------------------------------------------------------------

_ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
_MATHJAX_LOCAL = os.path.join(_ASSETS_DIR, "mathjax-tex-svg.js")
_MATHJAX_CDN = "https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"
_MATHJAX_TAG_CACHE: Optional[str] = None


def _mathjax_script_tag() -> str:
    """返回要放进 <head> 的 MathJax <script>。

    默认把 `aisx/assets/mathjax-tex-svg.js`（约 2 MB，TeX→SVG，字体随 SVG
    自带、无需外部字体）整段内联，导出的 HTML 因此**完全自包含、离线可渲染**，
    不再依赖 cdn.jsdelivr.net（国内经常打不开，一旦加载失败公式就退回 $$ 原文）。
    """
    global _MATHJAX_TAG_CACHE
    if _MATHJAX_TAG_CACHE is not None:
        return _MATHJAX_TAG_CACHE

    js = ""
    try:
        with open(_MATHJAX_LOCAL, "r", encoding="utf-8", errors="replace") as fh:
            js = fh.read()
    except Exception:  # noqa: BLE001
        js = ""

    if js:
        # 内联 <script> 里出现 `<!--` 会让浏览器进入「转义脚本」状态、吞掉收尾标签；
        # 这里仅有一处、位于正则 /<!--.*?-->/ 内，把 `!` 转义成 `\!` 语义不变。
        js = js.replace("<!--", "<\\!--").replace("</script", "<\\/script")
        _MATHJAX_TAG_CACHE = "<script>%s</script>" % js
    else:
        _MATHJAX_TAG_CACHE = (
            '<script id="MathJax-script" async src="%s"></script>' % _MATHJAX_CDN
        )
    return _MATHJAX_TAG_CACHE


# --------------------------------------------------------------------------
# HTML
# --------------------------------------------------------------------------

_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
  :root {{ --fg:#222; --muted:#7a7a7a; --line:#e3e6ea; --codebg:#f5f7f9; }}
  * {{ box-sizing: border-box; }}
  body {{ margin:0; background:#f0f2f5; color:var(--fg);
         font-family:"PingFang SC","Microsoft YaHei","Segoe UI",system-ui,sans-serif;
         font-size:15px; line-height:1.75; }}
  .paper {{ max-width:900px; margin:0 auto; background:#fff; padding:48px 56px 64px;
            box-shadow:0 1px 3px rgba(0,0,0,.08); }}
  h1 {{ font-size:28px; margin:0 0 6px; }}
  h2 {{ font-size:19px; margin:38px 0 10px; }}
  h3 {{ font-size:16px; margin:24px 0 8px; }}
  .meta {{ color:var(--muted); font-size:13px; border-bottom:1px solid var(--line);
           padding-bottom:14px; margin-bottom:26px; }}
  .meta a {{ color:#0563c1; }}
  .turn {{ margin:0 0 34px; }}
  .role {{ display:inline-block; font-size:13px; font-weight:700; padding:3px 12px;
           border-radius:4px; margin-bottom:10px; }}
  .role.user {{ background:#eaf1f9; color:#0f4c81; border-left:4px solid #4a7ebb; }}
  .role.ai {{ background:#edf7f1; color:#0b664b; border-left:4px solid #4e9a78; }}
  pre {{ background:var(--codebg); border:1px solid #dce0e5; border-radius:6px;
         padding:12px 14px; overflow-x:auto; font-size:13px; line-height:1.55; }}
  code {{ font-family:Consolas,"Cascadia Mono",Menlo,monospace; }}
  :not(pre) > code {{ background:#f0f2f4; padding:1px 5px; border-radius:4px;
                      color:#b03060; font-size:13.5px; }}
  blockquote {{ margin:10px 0; padding:2px 0 2px 16px; border-left:4px solid #c2c7cf;
                color:#555b66; }}
  table {{ border-collapse:collapse; margin:12px 0; font-size:14px; }}
  th, td {{ border:1px solid #d7dbe0; padding:6px 10px; }}
  th {{ background:#f1f4f7; }}
  hr {{ border:none; border-top:1px solid var(--line); margin:24px 0; }}
  mjx-container[display="true"] {{ margin: 1em 0; overflow-x:auto; overflow-y:hidden; }}
  .notes {{ margin-top:40px; padding-top:16px; border-top:1px solid var(--line);
            color:var(--muted); font-size:12.5px; }}
  @media print {{
    body {{ background:#fff; }}
    .paper {{ box-shadow:none; max-width:none; padding:0; }}
    .noprint {{ display:none; }}
  }}
</style>
<script>
  window.MathJax = {{
    tex: {{ inlineMath: [['$','$'],['\\\\(','\\\\)']], displayMath: [['$$','$$'],['\\\\[','\\\\]']],
           processEscapes: true }},
    options: {{ skipHtmlTags: ['script','noscript','style','textarea','pre','code'] }},
    svg: {{ fontCache: 'global' }}
  }};
</script>
{mathjax_script}
</head>
<body>
<div class="paper">
<h1>{title}</h1>
<div class="meta">{meta}</div>
{body}
<div class="notes noprint">导出时间 {now} · 由「AI 对话导出助手」生成 · 公式由**内置 MathJax** 渲染（无需联网、离线可用）。<br>
需要 PDF？在浏览器里按 Ctrl+P，目标选择「另存为 PDF」即可（勾选"背景图形"效果更好）。</div>
</div>
</body>
</html>
"""


def _render_md_with_math(md: MarkdownIt, text: str) -> str:
    """渲染一段 Markdown，但把公式先保护起来、渲染后原样放回。"""
    protected, table = _protect_math(text)
    return _restore_math(md.render(protected), table)


def conversation_to_html(conv: Conversation, *, include_thinking: bool = False) -> str:
    md = MarkdownIt("commonmark", {"html": False})
    try:
        md.enable(["table", "strikethrough"])
    except Exception:  # noqa: BLE001
        pass

    body_parts: List[str] = []
    for m in conv.messages:
        role_cls = "user" if m.role == "user" else "ai"
        label = "用户" if m.role == "user" else ("系统" if m.role == "system" else "AI 回答")
        inner = _render_md_with_math(md, m.content.strip())
        extra = ""
        if include_thinking and m.thinking.strip():
            extra = ('<details><summary>思考过程</summary>%s</details>'
                     % _render_md_with_math(md, m.thinking.strip()))
        body_parts.append(
            '<div class="turn"><div class="role %s">%s</div>%s%s</div>'
            % (role_cls, label, inner, extra)
        )

    meta_bits = []
    if conv.platform_name:
        meta_bits.append("平台：%s" % _html.escape(conv.platform_name))
    if conv.model:
        meta_bits.append("模型：%s" % _html.escape(conv.model))
    meta_bits.append("消息数：%d" % len(conv.messages))
    if conv.url:
        meta_bits.append('原文：<a href="%s" target="_blank">%s</a>'
                         % (_html.escape(conv.url, quote=True), _html.escape(conv.url)))
    if conv.fetched_at:
        meta_bits.append("抓取于 %s" % conv.fetched_at)

    notes = ""
    if conv.notes:
        items = "".join("<li>%s</li>" % _html.escape(n) for n in conv.notes if n and n.strip())
        if items:
            notes = '<div class="notes"><b>导出说明</b><ul>%s</ul></div>' % items

    return _HTML_TEMPLATE.format(
        title=_html.escape(conv.title or "AI 对话记录"),
        meta=" &nbsp;·&nbsp; ".join(meta_bits),
        body="\n".join(body_parts) + notes,
        now=datetime.now().strftime("%Y-%m-%d %H:%M"),
        mathjax_script=_mathjax_script_tag(),
    )


# --------------------------------------------------------------------------
# 纯文本
# --------------------------------------------------------------------------

def conversation_to_text(conv: Conversation, *, include_thinking: bool = False) -> str:
    lines: List[str] = []
    lines.append(conv.title or "AI 对话记录")
    lines.append("=" * 60)
    if conv.platform_name:
        lines.append("平台：%s" % conv.platform_name)
    if conv.model:
        lines.append("模型：%s" % conv.model)
    if conv.url:
        lines.append("链接：%s" % conv.url)
    lines.append("抓取时间：%s" % conv.fetched_at)
    lines.append("")

    for m in conv.messages:
        label = "用户" if m.role == "user" else ("系统" if m.role == "system" else "AI 回答")
        lines.append("-" * 60)
        lines.append("[%s]" % label)
        lines.append("-" * 60)
        lines.append(m.content.strip())
        if include_thinking and m.thinking.strip():
            lines.append("")
            lines.append("[思考过程]")
            lines.append(m.thinking.strip())
        lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------------
# 各格式的写盘调度
# --------------------------------------------------------------------------

FORMAT_EXT = {
    "docx": ".docx",
    "md": ".md",
    "html": ".html",
    "htm": ".html",
    "txt": ".txt",
    "text": ".txt",
    "json": ".json",
    "markdown": ".md",
}

SUPPORTED_FORMATS = ["docx", "md", "html", "txt", "json"]


def normalize_format(fmt: str) -> str:
    f = (fmt or "").strip().lower().lstrip(".")
    if f in ("markdown",):
        return "md"
    if f in ("htm",):
        return "html"
    if f in ("text",):
        return "txt"
    return f


def safe_filename(name: str, max_len: int = 80) -> str:
    """把标题变成安全的文件名。"""
    s = (name or "AI对话记录").strip()
    s = re.sub(r'[\\/:*?"<>|\r\n\t]', "_", s)
    s = re.sub(r"\s+", " ", s).strip(" .")
    if len(s) > max_len:
        s = s[:max_len].rstrip(" .")
    return s or "AI对话记录"


def write_format(conv: Conversation, fmt: str, out_path: str,
                 options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """按格式写文件。返回统计信息。"""
    options = options or {}
    f = normalize_format(fmt)
    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)

    if f == "docx":
        from .docxwriter import render_docx

        return render_docx(conv, out_path, options)

    if f == "md":
        text = conversation_to_markdown(conv, include_thinking=bool(options.get("include_thinking")))
    elif f == "html":
        text = conversation_to_html(conv, include_thinking=bool(options.get("include_thinking")))
    elif f == "txt":
        text = conversation_to_text(conv, include_thinking=bool(options.get("include_thinking")))
    elif f == "json":
        text = conv.to_json()
    else:
        raise ValueError("不支持的导出格式：%s" % fmt)

    with open(out_path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    return {
        "path": out_path,
        "bytes": len(text.encode("utf-8")),
        "math_rendered": 0,
        "math_failed": 0,
        "notes": [],
    }
