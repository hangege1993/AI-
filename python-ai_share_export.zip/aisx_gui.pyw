# -*- coding: utf-8 -*-
"""AI 对话转 Word 助手 —— 图形界面。

双击「启动 AI对话转Word.bat」或本文件即可运行（.pyw 后缀不会弹黑框）。
界面刻意做得很简单：贴链接 → 点导出 → 拿文件。
"""

from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import traceback

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import tkinter as tk  # noqa: E402
from tkinter import filedialog, messagebox, ttk  # noqa: E402

from aisx import convert as cv  # noqa: E402
from aisx import fetch as fetcher  # noqa: E402
from aisx.exporters import SUPPORTED_FORMATS  # noqa: E402

SETTINGS_PATH = os.path.join(BASE_DIR, "aisx_settings.json")

# ---- 配色（浅色主题）----
BG = "#F4F6F8"
CARD = "#FFFFFF"
BORDER = "#DCE0E5"
FG = "#1F2329"
MUTED = "#7A828C"
ACCENT = "#1F6FEB"
ACCENT_DARK = "#175BC0"
OK_CLR = "#1A7F37"
ERR_CLR = "#C0392B"
LOG_BG = "#FFFFFF"

FONT_UI = ("Microsoft YaHei UI", 10)
FONT_UI_S = ("Microsoft YaHei UI", 9)
FONT_TITLE = ("Microsoft YaHei UI", 16, "bold")
FONT_SUB = ("Microsoft YaHei UI", 9)
FONT_MONO = ("Consolas", 9)

FORMAT_LABELS = [
    ("docx", "Word (.docx)", True),
    ("md", "Markdown", False),
    ("html", "网页 (.html)", False),
    ("txt", "纯文本", False),
    ("json", "JSON", False),
]


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("AI 对话转 Word 助手")
        self.geometry("880x720")
        self.minsize(760, 620)
        self.configure(bg=BG)

        self.msg_q: "queue.Queue[tuple]" = queue.Queue()
        self.worker: threading.Thread | None = None
        self.last_out_dir = ""
        self._style()

        self.cfg = self._load_settings()
        self._build()
        self._poll()

    # ---------------- 设置持久化 ----------------
    def _load_settings(self) -> dict:
        try:
            with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
                d = json.load(f)
                if isinstance(d, dict):
                    return d
        except Exception:  # noqa: BLE001
            pass
        return {}

    def _save_settings(self) -> None:
        try:
            d = {
                "out_dir": self.out_var.get(),
                "formats": [k for k, _, _ in FORMAT_LABELS if self.fmt_vars[k].get()],
                "render": self.render_var.get(),
                "show_browser": self.showbrowser_var.get(),
                "thinking": self.thinking_var.get(),
                "meta": self.meta_var.get(),
                "dialogue": self.dialogue_var.get(),
                "toc": self.toc_var.get(),
                "wait": self.wait_var.get(),
            }
            with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False, indent=1)
        except Exception:  # noqa: BLE001
            pass

    # ---------------- 样式 ----------------
    def _style(self) -> None:
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except Exception:  # noqa: BLE001
            pass
        st.configure(".", background=BG, foreground=FG, font=FONT_UI)
        st.configure("Card.TFrame", background=CARD, relief="flat")
        st.configure("TFrame", background=BG)
        st.configure("TLabel", background=BG, foreground=FG, font=FONT_UI)
        st.configure("Card.TLabel", background=CARD, foreground=FG)
        st.configure("Muted.TLabel", background=BG, foreground=MUTED, font=FONT_SUB)
        st.configure("MutedCard.TLabel", background=CARD, foreground=MUTED, font=FONT_SUB)
        st.configure("Title.TLabel", background=BG, foreground=FG, font=FONT_TITLE)
        st.configure("TCheckbutton", background=BG, foreground=FG, font=FONT_UI_S)
        st.configure("Card.TCheckbutton", background=CARD, foreground=FG, font=FONT_UI_S)
        st.configure("TEntry", fieldbackground="#FFFFFF")
        st.configure("TCombobox", fieldbackground="#FFFFFF")

        st.configure("Accent.TButton", background=ACCENT, foreground="#FFFFFF",
                     font=("Microsoft YaHei UI", 10, "bold"), borderwidth=0, padding=(18, 9))
        st.map("Accent.TButton",
               background=[("active", ACCENT_DARK), ("disabled", "#A9BFE4")],
               foreground=[("disabled", "#EEEEEE")])
        st.configure("Plain.TButton", background="#FFFFFF", foreground=FG,
                     borderwidth=1, padding=(12, 7), font=FONT_UI_S)
        st.map("Plain.TButton", background=[("active", "#EDF2F7")])

    # ---------------- 布局 ----------------
    def _build(self) -> None:
        pad = 16

        head = ttk.Frame(self)
        head.pack(fill="x", padx=pad, pady=(pad, 6))
        ttk.Label(head, text="AI 对话转 Word 助手", style="Title.TLabel").pack(anchor="w")
        ttk.Label(head, text="把 DeepSeek / ChatGPT / Claude / Kimi / 豆包 等平台的分享链接，"
                            "导出成公式可继续编辑的 Word 文档",
                  style="Muted.TLabel").pack(anchor="w", pady=(2, 0))

        # ==== 链接输入 ====
        c1 = tk.Frame(self, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        c1.pack(fill="both", expand=False, padx=pad, pady=(10, 0))
        inner = tk.Frame(c1, bg=CARD)
        inner.pack(fill="both", expand=True, padx=12, pady=10)
        tk.Label(inner, text="① 粘贴分享链接", bg=CARD, fg=FG,
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w")
        tk.Label(inner, text="一行一个，也可以直接把整段分享文案粘进来（会自动挑出链接）",
                 bg=CARD, fg=MUTED, font=FONT_SUB).pack(anchor="w", pady=(1, 6))
        self.txt = tk.Text(inner, height=5, font=FONT_MONO, bg="#FBFCFD", fg=FG,
                           relief="flat", highlightthickness=1,
                           highlightbackground=BORDER, highlightcolor=ACCENT,
                           insertbackground=FG, wrap="word", padx=8, pady=6)
        self.txt.pack(fill="both", expand=True)

        # ==== 选项 ====
        c2 = tk.Frame(self, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        c2.pack(fill="x", padx=pad, pady=(10, 0))
        inner2 = tk.Frame(c2, bg=CARD)
        inner2.pack(fill="x", padx=12, pady=10)

        tk.Label(inner2, text="② 输出设置", bg=CARD, fg=FG,
                 font=("Microsoft YaHei UI", 10, "bold")).grid(row=0, column=0, columnspan=4, sticky="w")

        # 目录
        row = tk.Frame(inner2, bg=CARD)
        row.grid(row=1, column=0, columnspan=4, sticky="ew", pady=(8, 4))
        tk.Label(row, text="输出目录", bg=CARD, fg=MUTED, font=FONT_UI_S).pack(side="left")
        default_dir = self.cfg.get("out_dir") or os.path.join(os.path.expanduser("~"), "Desktop", "AI对话导出")
        self.out_var = tk.StringVar(value=default_dir)
        ttk.Entry(row, textvariable=self.out_var, font=FONT_UI_S).pack(side="left", fill="x",
                                                                      expand=True, padx=8)
        ttk.Button(row, text="浏览", style="Plain.TButton",
                   command=self._pick_dir).pack(side="left")
        ttk.Button(row, text="打开", style="Plain.TButton",
                   command=self._open_out_dir).pack(side="left", padx=(6, 0))

        # 格式
        frow = tk.Frame(inner2, bg=CARD)
        frow.grid(row=2, column=0, columnspan=4, sticky="w", pady=(6, 2))
        tk.Label(frow, text="导出格式", bg=CARD, fg=MUTED, font=FONT_UI_S).pack(side="left", padx=(0, 8))
        saved_fmts = self.cfg.get("formats") or ["docx"]
        self.fmt_vars = {}
        for key, label, default in FORMAT_LABELS:
            v = tk.BooleanVar(value=(key in saved_fmts) if saved_fmts else default)
            self.fmt_vars[key] = v
            tk.Checkbutton(frow, text=label, variable=v, bg=CARD, fg=FG, font=FONT_UI_S,
                           activebackground=CARD, selectcolor="#FFFFFF",
                           highlightthickness=0, bd=0).pack(side="left", padx=(0, 10))

        # 开关
        orow = tk.Frame(inner2, bg=CARD)
        orow.grid(row=3, column=0, columnspan=4, sticky="w", pady=(6, 2))
        self.render_var = tk.BooleanVar(value=bool(self.cfg.get("render", True)))
        self.showbrowser_var = tk.BooleanVar(value=bool(self.cfg.get("show_browser", False)))
        self.thinking_var = tk.BooleanVar(value=bool(self.cfg.get("thinking", False)))
        self.meta_var = tk.BooleanVar(value=bool(self.cfg.get("meta", True)))
        # 大纲组织：默认对话树（每条消息=一级节点，靠导航窗格收缩）
        self.dialogue_var = tk.BooleanVar(value=bool(self.cfg.get("dialogue", True)))
        self.toc_var = tk.BooleanVar(value=bool(self.cfg.get("toc", False)))
        for text, var in [
            ("自动渲染网页（推荐，前端渲染的站点需要）", self.render_var),
            ("渲染时显示浏览器窗口", self.showbrowser_var),
            ("导出思考过程", self.thinking_var),
            ("导出头部信息（平台/模型/链接）", self.meta_var),
            ("对话树大纲（每条消息=一级节点，靠导航窗格收缩）", self.dialogue_var),
            ("插入可见目录页（否则用导航窗格）", self.toc_var),
        ]:
            tk.Checkbutton(orow, text=text, variable=var, bg=CARD, fg=FG, font=FONT_UI_S,
                           activebackground=CARD, selectcolor="#FFFFFF",
                           highlightthickness=0, bd=0).pack(side="left", padx=(0, 12))

        wrow = tk.Frame(inner2, bg=CARD)
        wrow.grid(row=4, column=0, columnspan=4, sticky="w", pady=(6, 0))
        tk.Label(wrow, text="渲染后额外等待（毫秒，网慢可调大）", bg=CARD, fg=MUTED,
                 font=FONT_UI_S).pack(side="left")
        self.wait_var = tk.StringVar(value=str(self.cfg.get("wait", 6000)))
        ttk.Entry(wrow, textvariable=self.wait_var, width=8, font=FONT_UI_S).pack(side="left", padx=8)

        inner2.columnconfigure(3, weight=1)

        # ==== 按钮 ====
        brow = tk.Frame(self, bg=BG)
        brow.pack(fill="x", padx=pad, pady=(12, 0))
        self.run_btn = ttk.Button(brow, text="开始导出", style="Accent.TButton", command=self._start)
        self.run_btn.pack(side="left")
        ttk.Button(brow, text="清空链接", style="Plain.TButton",
                   command=lambda: self.txt.delete("1.0", "end")).pack(side="left", padx=(8, 0))
        ttk.Button(brow, text="清空日志", style="Plain.TButton",
                   command=self._clear_log).pack(side="left", padx=(8, 0))
        self.env_lbl = ttk.Label(brow, text=self._env_text(), style="Muted.TLabel")
        self.env_lbl.pack(side="right")

        # ==== 日志 ====
        c3 = tk.Frame(self, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        c3.pack(fill="both", expand=True, padx=pad, pady=(10, pad))
        inner3 = tk.Frame(c3, bg=CARD)
        inner3.pack(fill="both", expand=True, padx=12, pady=10)
        tk.Label(inner3, text="③ 运行日志", bg=CARD, fg=FG,
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w")
        wrap = tk.Frame(inner3, bg=CARD)
        wrap.pack(fill="both", expand=True, pady=(6, 0))
        self.log = tk.Text(wrap, font=FONT_MONO, bg=LOG_BG, fg=FG, relief="flat",
                           highlightthickness=1, highlightbackground=BORDER,
                           wrap="word", padx=8, pady=6, state="disabled")
        sb = ttk.Scrollbar(wrap, command=self.log.yview)
        self.log.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log.pack(side="left", fill="both", expand=True)
        self.log.tag_configure("ok", foreground=OK_CLR)
        self.log.tag_configure("err", foreground=ERR_CLR)
        self.log.tag_configure("dim", foreground=MUTED)
        self.log.tag_configure("hi", foreground=ACCENT)

        self.status = tk.StringVar(value="就绪")
        tk.Label(self, textvariable=self.status, bg=BG, fg=MUTED, font=FONT_SUB,
                 anchor="w").pack(fill="x", padx=pad, pady=(0, 8))

        self.log_line("AI 对话转 Word 助手已就绪。", "hi")
        self.log_line("把分享链接贴进上面的输入框，点「开始导出」即可。", "dim")
        if not fetcher.playwright_available():
            self.log_line("提示：未检测到浏览器渲染组件，前端渲染的站点可能抓不到内容。", "err")
            self.log_line("      安装方法：pip install playwright  然后  playwright install chromium", "dim")

    def _env_text(self) -> str:
        return "浏览器渲染：%s" % ("可用" if fetcher.playwright_available() else "未安装")

    # ---------------- 日志 ----------------
    def log_line(self, text: str, tag: str = "") -> None:
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n", tag)
        self.log.see("end")
        self.log.configure(state="disabled")

    def _clear_log(self) -> None:
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")

    # ---------------- 事件 ----------------
    def _pick_dir(self) -> None:
        d = filedialog.askdirectory(initialdir=self.out_var.get() or os.path.expanduser("~"))
        if d:
            self.out_var.set(d)

    def _open_out_dir(self) -> None:
        d = self.out_var.get().strip()
        if not os.path.isdir(d):
            messagebox.showinfo("提示", "目录还不存在，导出后会自动创建。")
            return
        try:
            if sys.platform.startswith("win"):
                os.startfile(d)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", d])
            else:
                subprocess.Popen(["xdg-open", d])
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("打开失败", str(e))

    def _start(self) -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("提示", "正在导出中，请等当前任务结束。")
            return

        urls = cv.urls_from_text(self.txt.get("1.0", "end"))
        if not urls:
            messagebox.showwarning("没有链接", "请先在输入框里粘贴至少一个分享链接。")
            return

        formats = [k for k, _, _ in FORMAT_LABELS if self.fmt_vars[k].get()]
        if not formats:
            messagebox.showwarning("没有格式", "请至少勾选一种导出格式。")
            return

        out_dir = self.out_var.get().strip() or "."
        try:
            wait_ms = max(0, int(self.wait_var.get()))
        except Exception:  # noqa: BLE001
            wait_ms = 6000
        options = {
            "include_thinking": bool(self.thinking_var.get()),
            "include_meta": bool(self.meta_var.get()),
            "outline_mode": "dialogue" if self.dialogue_var.get() else "document",
            "toc": bool(self.toc_var.get()),
        }
        self._save_settings()

        self.run_btn.configure(state="disabled")
        self.status.set("正在导出…")
        self.log_line("")
        self.log_line("─" * 60, "dim")
        self.log_line("开始处理 %d 个链接 → %s" % (len(urls), out_dir), "hi")

        args = dict(
            out_dir=out_dir,
            formats=formats,
            allow_render=bool(self.render_var.get()),
            headless=not bool(self.showbrowser_var.get()),
            wait_ms=wait_ms,
            options=options,
            progress=lambda m: self.msg_q.put(("log", m, "dim")),
        )
        self.worker = threading.Thread(target=self._work, args=(urls, args), daemon=True)
        self.worker.start()

    def _work(self, urls, args) -> None:
        try:
            results = cv.convert_many(urls, on_result=self._on_result, **args)
            ok = sum(1 for r in results if r.ok)
            self.msg_q.put(("done", ok, len(results), results))
        except Exception:  # noqa: BLE001
            self.msg_q.put(("crash", traceback.format_exc()))
        finally:
            self.msg_q.put(("enable",))

    def _on_result(self, r) -> None:
        if r.ok:
            self.msg_q.put(("log", "✔ %s" % r.title, "ok"))
            for f in r.files:
                self.msg_q.put(("log", "    %s" % f, ""))
            self.msg_q.put(("log", "    %s" % r.summary(), "dim"))
        else:
            self.msg_q.put(("log", "✘ %s" % r.url, "err"))
            for line in str(r.error).splitlines():
                self.msg_q.put(("log", "    " + line, "err"))
            if r.conv and r.conv.notes:
                for n in r.conv.notes[:3]:
                    self.msg_q.put(("log", "    · " + n, "dim"))

    def _poll(self) -> None:
        try:
            while True:
                item = self.msg_q.get_nowait()
                kind = item[0]
                if kind == "log":
                    _, text, tag = item
                    self.log_line(text, tag)
                elif kind == "done":
                    _, ok, total, results = item
                    self.log_line("─" * 60, "dim")
                    self.log_line("完成：成功 %d / 共 %d" % (ok, total), "ok" if ok else "err")
                    if ok:
                        self.status.set("完成，成功 %d 个" % ok)
                        self.last_out_dir = self.out_var.get().strip()
                    else:
                        self.status.set("全部失败，请看日志")
                        self.log_line("")
                        self.log_line("排查建议：", "hi")
                        self.log_line("  1) 确认用的是「分享链接」，而不是需要登录的会话地址", "dim")
                        self.log_line("  2) 勾选「渲染时显示浏览器窗口」再跑一次，看看浏览器里实际打开了什么", "dim")
                        self.log_line("  3) 安装浏览器组件：pip install playwright && playwright install chromium", "dim")
                elif kind == "crash":
                    self.log_line("发生未预料的错误：", "err")
                    for line in item[1].splitlines()[-12:]:
                        self.log_line("  " + line, "err")
                    self.status.set("出错")
                elif kind == "enable":
                    self.run_btn.configure(state="normal")
        except queue.Empty:
            pass
        self.after(120, self._poll)


def main() -> None:
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
